
import numpy as np
from rknnlite.api import RKNNLite
rknn = RKNNLite()
rknn.load_rknn('/home/hytop/evs/ice_rk3588.rknn')
rknn.init_runtime()
tests = {
  'zeros_f32': np.zeros((1,3,224,224), np.float32),
  'ones255_f32': np.full((1,3,224,224), 255.0, np.float32),
  'rand_f32': (np.random.rand(1,3,224,224)*255).astype(np.float32),
  'rand_u8': (np.random.rand(1,3,224,224)*255).astype(np.uint8),
  'grad_f32': np.tile(np.linspace(0,255,224).astype(np.float32),(1,3,224,1)),
}
for name, inp in tests.items():
    dt = 'uint8' if inp.dtype == np.uint8 else 'float32'
    out = rknn.inference(inputs=[inp], data_type=dt)
    v = out[0].reshape(-1)
    print(name, dt, 'sum=%.4f'%v.sum(), 'argmax=', int(np.argmax(v)), 'vals=', np.round(v,4).tolist())
rknn.release()
