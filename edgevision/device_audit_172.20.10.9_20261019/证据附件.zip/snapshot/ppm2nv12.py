
import struct
f = open("/root/evs/eval_onnx_demo/images/bus.ppm", "rb")
assert f.readline().strip() == b"P6"
w, h = map(int, f.readline().split())
f.readline()
rgb = f.read(w * h * 3)
Y = bytearray(w * h)
U = bytearray((w // 2) * (h // 2))
V = bytearray((w // 2) * (h // 2))
for y in range(h):
    for x in range(w):
        i = (y * w + x) * 3
        r, g, b = rgb[i], rgb[i+1], rgb[i+2]
        yy = ((66*r + 129*g + 25*b + 128) >> 8) + 16
        uu = ((-38*r - 74*g + 112*b + 128) >> 8) + 128
        vv = ((112*r - 94*g - 18*b + 128) >> 8) + 128
        Y[y*w+x] = max(0, min(255, yy))
        if y % 2 == 0 and x % 2 == 0:
            j = (y//2)*(w//2) + x//2
            U[j] = max(0, min(255, uu))
            V[j] = max(0, min(255, vv))
open("/tmp/bus.nv12", "wb").write(bytes(Y) + bytes(U) + bytes(V))
print("wrote /tmp/bus.nv12", w, h)
