#!/bin/sh
# /root/evs/health_check.sh -- RK3576 v4l2_detect 自检（正确解码路径）
# 关键：本模型头为 raw（无 NMS），必须用 v4l2_detect_yolov5raw + eval_rknn_raw.yaml。
# 旧的 v4l2_detect_wstride --task eval_rknn.yaml（yolov8）会输出 40+ 垃圾框，已弃用。
cd /root/evs

echo "=== 1 采集（v4l2-ctl MMAP NV12 1280x720） ==="
v4l2-ctl -d /dev/video0 --set-fmt-video=width=1280,height=720,pixelformat=NV12 >/dev/null 2>&1
rm -f /tmp/live.nv12
v4l2-ctl -d /dev/video0 --stream-mmap=3 --stream-count=1 --stream-to=/tmp/live.nv12 >/dev/null 2>&1
ls -l /tmp/live.nv12

echo "=== 2 RGA 预处理 + NPU 推理（实时画面，yolov5_raw 解码） ==="
./v4l2_detect_yolov5raw --task eval_rknn_raw.yaml --raw /tmp/live.nv12 \
  --raw-width 1280 --raw-height 720 --frames 1 --rga 2>&1 | grep -E "rga_api|version|targets|conf|frame"

echo "=== 3 验收基准 bus.ppm（应有 ~4 框，conf 0.5~0.88，位置对应乘客/车） ==="
./v4l2_detect_yolov5raw --task eval_rknn_raw.yaml --raw /root/evs/bus.nv12 \
  --raw-width 640 --raw-height 640 --frames 1 --rga 2>&1 | grep -E "targets|conf|box"

echo "=== 4 模型输出规格（确认 raw 头 [1,255,N,N]） ==="
strings /root/cameras/yolov5s-640-640_rk3576.rknn | grep -i "shape" | head -3
