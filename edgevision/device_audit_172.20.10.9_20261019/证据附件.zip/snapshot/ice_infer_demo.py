
import sys, time, argparse
import numpy as np
import cv2
from rknnlite.api import RKNNLite

MODEL = '/home/hytop/evs/ice_rk3588.rknn'
IN_H, IN_W = 224, 224
DEFAULT_LABELS = ['class_0','class_1','class_2','class_3','class_4','class_5']

def preprocess(img, norm):
    img = cv2.cvtColor(img, cv2.COLOR_BGR2RGB)
    img = cv2.resize(img, (IN_W, IN_H))
    arr = img.astype(np.float32)
    if norm == 'imagenet':
        mean = np.array([0.485,0.456,0.406], dtype=np.float32)
        std = np.array([0.229,0.224,0.225], dtype=np.float32)
        arr = arr / 255.0
        arr = (arr - mean) / std
    elif norm == 'none':
        arr = arr / 255.0
    arr = arr.transpose(2,0,1)
    return np.expand_dims(arr, axis=0)

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('image', nargs='?', help='input image path')
    ap.add_argument('--norm', default='raw', choices=['raw','uint8','imagenet','none'])
    ap.add_argument('--labels', default='', help='comma separated labels')
    ap.add_argument('--loops', type=int, default=1)
    args = ap.parse_args()
    labels = args.labels.split(',') if args.labels else DEFAULT_LABELS
    rknn = RKNNLite()
    rknn.load_rknn(MODEL)
    rknn.init_runtime()
    if args.image:
        img = cv2.imread(args.image)
        if img is None:
            print('cannot read', args.image); sys.exit(1)
        inp = preprocess(img, args.norm)
        dtype = 'uint8' if args.norm == 'uint8' else 'float32'
        if dtype == 'uint8':
            inp = inp.astype(np.uint8)
        print('image', args.image, 'norm=', args.norm, 'dtype', dtype)
    else:
        print('no image -> zeros (mechanism test)')
        inp = np.zeros((1,3,IN_H,IN_W), dtype=np.float32)
        dtype = 'float32'
    out = rknn.inference(inputs=[inp], data_type=dtype)
    t0 = time.time()
    for _ in range(args.loops):
        out = rknn.inference(inputs=[inp], data_type=dtype)
    dt = (time.time()-t0)/args.loops*1000
    prob = out[0].reshape(-1).astype(np.float32)
    print('output shape', list(prob.shape), 'sum=%.4f' % prob.sum())
    print('probabilities:', np.round(prob,4).tolist())
    order = np.argsort(-prob)
    print('--- top ---')
    for i in order:
        lab = labels[i] if i < len(labels) else ('class_%d' % i)
        print('  %-12s %.4f' % (lab, prob[i]))
    print('=> argmax', int(order[0]))
    print('avg infer %.2f ms' % dt)
    rknn.release()

if __name__ == '__main__':
    main()
