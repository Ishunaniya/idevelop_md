#!/bin/sh
# evs_clean.sh — yolov5raw 长跑每帧编号写 /tmp/y5_*.ppm（~47MB/s），
# 不清理会把 tmpfs 撑爆。此循环：
#   1) 把最新帧原子软链到 /tmp/evs_latest.ppm 供 PC 端拉取
#   2) 只保留最近 3 个帧文件，其余删除
while :; do
  l=$(ls -t /tmp/y5_*.ppm 2>/dev/null | head -n 1)
  if [ -n "$l" ]; then
    ln -sf "$l" /tmp/evs_latest.ppm 2>/dev/null
    ls -t /tmp/y5_*.ppm 2>/dev/null | tail -n +4 | xargs -r rm -f
  fi
  sleep 0.2
done
