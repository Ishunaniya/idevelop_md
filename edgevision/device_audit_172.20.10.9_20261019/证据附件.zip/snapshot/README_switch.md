# RK3576 实时检测：YOLOv5 / YOLOv11 切换 与 实时预览

板端二进制：`/root/evs/`；板 IP `192.168.11.1`（root，空密码）。
摄像头：`/dev/video0`（1280×720@25，见 `camera_config.json` channel 0）。

> **单二进制切换已落地**：`v4l2_detect_merged` 已把 `yolov5_raw` 解码器合入，
> 通过 `--task` 的 yaml 里 `output_format`（`yolo11` / `yolov5_raw`）自动选解码器，
> **一个二进制 + 只换 yaml 即可切换**，无需换二进制。
> （老的 `v4l2_detect_evs_rga2` / `v4l2_detect_yolov5raw` 仍保留作 oracle 对照。）

---

## 1. 模型切换指令（单二进制）

### → YOLO11
```bash
cd /root/evs
./v4l2_detect_merged --task eval_yolo11.yaml \
  --config camera_config.json --channel 0 --rga --frames 50 --stats
# 常驻版（无 --frames，加 --daemon）：
./v4l2_detect_merged --task eval_yolo11.yaml \
  --config camera_config.json --channel 0 --rga --daemon --stats
# 常驻 + 对外发检测框（接 HMI/算法）：加 --shm-write 0
```

### → YOLOv5s（raw 模型，yolov5_raw 解码器）
```bash
cd /root/evs
./v4l2_detect_merged --task eval_rknn_raw.yaml \
  --config camera_config.json --channel 0 --rga --frames 50
# 持续运行（用大 --frames 顶替 --daemon）：
./v4l2_detect_merged --task eval_rknn_raw.yaml \
  --config camera_config.json --channel 0 --rga --frames 999999
```

### 一键切换（脱离 SSH 会话、可常驻，供 UI / 脚本调用）
```bash
# YOLO11
cd /root/evs && setsid bash -c 'nohup ./v4l2_detect_merged \
  --task eval_yolo11.yaml --config camera_config.json --channel 0 \
  --rga --daemon --save /tmp/evs_shot.ppm > /tmp/evs_view.log 2>&1 &'
# YOLOv5s（PPM 输出，每帧编号文件 → 必须配套 evs_clean.sh 清理）
cd /root/evs && setsid bash -c 'nohup ./v4l2_detect_merged \
  --task eval_rknn_raw.yaml --config camera_config.json --channel 0 \
  --rga --frames 999999 --save /tmp/y5.ppm > /tmp/evs_view.log 2>&1 &' ; \
  setsid bash -c 'nohup /root/evs/evs_clean.sh > /dev/null 2>&1 &'
# 停止（模式用 [t] 方括号写，防 pkill -f 误杀执行 shell 自身）
pkill -f 'v4l2_detec[t]'; pkill -f 'evs_clea[n]'
```

> ⚠️ **pkill 与启动命令不要拼在同一条 SSH 命令里**：启动部分的
> `./v4l2_detect_merged` 字样会出现在执行 shell 的 cmdline 中，
> `pkill -f` 会把 shell 自己杀掉，导致后面的启动永远不执行。

---

## 2. 性能对比（板端实测，各 50 帧，RGA 预处理，1280×720→640×640 letterbox）

| 模型 | NPU infer | 端到端 total | 实际帧率 | 备注 |
|---|---|---|---|---|
| YOLO11 | 75.25 ms | 79.19 ms | 12.6 fps | 相机 25fps 超发，必有丢帧 |
| YOLOv5s | 30.82 ms | 33.84 ms | 29.5 fps | 29.5 > 25，**零丢帧** |

**结论：YOLOv5s 推理快约 2.4 倍，且吞吐已超过相机输入，不再丢帧。**

---

## 3. 单二进制切换是怎么合进去的

- `yolov5s-640-640_rk3576.rknn` 是**导出头无 NMS 的 raw 模型**（输出 `[1,255,80,80]/[1,255,40,40]/[1,255,20,20]`），用 `yolov5_raw` 解码器（grid/anchor + NMS）。
- `yolo11.rknn` 是 **DFL + score 分支导出**（每尺度三元组 `box[1,64,H,W] / cls[1,80,H,W] / score[1,1,H,W]`），用 `yolo11` DFL 解码（4×16 softmax 距离 + 网格中心 → 框，置信度 = 最优类概率 × score）。
- `rknn_backend.cpp` 在 `infer()` 里按输出张量形状自动判别：
  - 检测到 `box(c==64) + cls + score(c==1)` 三元组 → 走 `decode_yolo11_scale`；
  - 否则若 `raw_concat`（yolov5_raw）→ 拼接张量交 `yolov5_raw` 解码器；
  - 否则走通用 `decode_heads`（255 头）。
- 两个解码器共用 `yolo_decode.h` 里的 `Det / nms / emit_rows`，保证 x86 离线评测与板端一致。

### 与 oracle 对照（bus.nv12，640×640）
| 项 | 结果 |
|---|---|
| GATE B（yolov5_raw） | `v4l2_detect_merged` 输出与 `v4l2_detect_yolov5raw` **逐位一致**（4 框 conf 0.879/0.861/0.771/0.628，坐标完全相同） |
| GATE A（yolo11） | 4 框类别/坐标与 `v4l2_detect_evs_rga2` **一致（误差 ≤1px / 0.003 norm）**；置信度偏差 ≤5%（见下） |

> **置信度偏差说明（GATE A）**：rga2 oracle 的置信度来自其内置标定，未包含在并入的
> 源码里。合并版默认 `conf = best_class_prob × score`（标准 YOLOv11 公式），
> 与 oracle 在 box4 完全一致、其余 ≤5%。如需逐位对齐置信度，提供 rga2 的置信度公式或
> 用 `EVS_YOLO11_CONF=cls|score|product` 调整置信度来源、`EVS_YOLO11_SIGMOID` 调整是否对
> cls/score 加 sigmoid。检测几何不受影响。

---

## 4. 实时预览 UI（PC 端 `detect_view.py`）

PC 上运行（依赖：`paramiko` + 标准库 `tkinter/threading`）：
```bash
python detect_view.py
```
- 选「模型：YOLO11 / YOLOv5s」→ 点 **▶ 启动检测**：UI 自动清理旧实例并在板端拉起对应检测器。
- 图像面板**每 250 ms 自动刷新**，直观看到检测效果（人/车出现时框会实时画出）。
- **■ 停止** 杀板端检测进程与清理脚本；**💾 存图** 把当前帧存为 `evs_snap_*.ppm`。

### 原理（v3：PNG → PPM，关键修复）
- 检测器 `--save xxx.png` 是**边编码边写、写完立即被下一帧截断**的模式，磁盘上几乎不存在完整 PNG，PC 拉到的永远是半截 → UI 一直解码失败（已实测 12 秒 1338 次轮询抓不到一帧完整 PNG）。
- 改用 **PPM（P6 裸 RGB）**：写盘快、完整窗口大，且**截断帧可补黑显示**，彻底消除竞争。
  - YOLO11 daemon 模式固定写 `/tmp/evs_shot.ppm`。
  - YOLOv5s 长跑**每帧编号写** `/tmp/y5_N.ppm`（实测 ~47MB/s，会撑爆 tmpfs！）——配套板端 `/root/evs/evs_clean.sh` 软链最新帧到 `/tmp/evs_latest.ppm` 并只保留最近 3 个文件。
- UI 每 250 ms `cat` 拉取 PPM → 解析 P6 头 → 不足补黑 → Tk 直接显示（Tk 原生支持 PPM，无需编码）。

### ⚠️ 注意
- `--save` 会降低流水线吞吐（实测 YOLO11 常驻 + `--save` 掉到 ~3.2 fps、丢帧 87%，PPM 略好但仍有开销）。该 UI 仅用于**可视化演示**；要满速运行请去掉 `--save`、改走 `--shm-write 0` 对外发布检测框。
- YOLOv5s 的 `evs_clean.sh` 必须与检测器**同时运行**（UI 启动命令已自动拉起），否则 tmpfs 约 40 秒撑满 → 系统卡死。

---

## 5. 复测检测正确性
两次 bench 的 `targets=0`（板端摄像头对空场景），仅为**推理耗时**对比。换模型后请对真实场景复测：把摄像头对准有人/车，看 `[stats] targets>0`（或 UI 里出现框）。
