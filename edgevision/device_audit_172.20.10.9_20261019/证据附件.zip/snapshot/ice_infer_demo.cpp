#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <vector>
#include <string>
#include <algorithm>
#include <fstream>
#include "rknn_api.h"
#include <opencv2/opencv.hpp>

static std::vector<uint8_t> read_file(const char* path) {
    std::ifstream f(path, std::ios::binary);
    if (!f) { fprintf(stderr, "cannot open %s\n", path); exit(1); }
    f.seekg(0, std::ios::end); size_t n = (size_t)f.tellg(); f.seekg(0, std::ios::beg);
    std::vector<uint8_t> buf(n); f.read((char*)buf.data(), (std::streamsize)n); return buf;
}
int main(int argc, char** argv) {
    if (argc < 2) { fprintf(stderr, "usage: %s <image> [label0 ... label5]\n", argv[0]); return 1; }
    const char* image_path = argv[1];
    const char* env_m = getenv("ICE_MODEL");
    const char* model_path = env_m ? env_m : "/home/hytop/evs/ice_rk3588.rknn";
    const char* def_labels[6] = {"dry_road","fully_snowy","icy","snow_blowing","snow_melting","wet_road"};
    std::vector<std::string> labels;
    for (int i = 2; i < argc; i++) labels.emplace_back(argv[i]);
    while ((int)labels.size() < 6) labels.push_back(def_labels[labels.size()]);
    std::vector<uint8_t> model = read_file(model_path);
    rknn_context ctx; int ret = rknn_init(&ctx, model.data(), (uint32_t)model.size(), 0, NULL);
    if (ret < 0) { fprintf(stderr, "rknn_init failed %d\n", ret); return 1; }
    rknn_input_output_num io_num; memset(&io_num, 0, sizeof(io_num));
    rknn_query(ctx, RKNN_QUERY_IN_OUT_NUM, &io_num, sizeof(io_num));
    rknn_tensor_attr in_attr; memset(&in_attr, 0, sizeof(in_attr)); in_attr.index = 0;
    rknn_query(ctx, RKNN_QUERY_INPUT_ATTR, &in_attr, sizeof(in_attr));
    int N = in_attr.dims[0], H = in_attr.dims[1], W = in_attr.dims[2], C = in_attr.dims[3];
    cv::Mat img = cv::imread(image_path);
    if (img.empty()) { fprintf(stderr, "cannot read %s\n", image_path); return 1; }
    cv::Mat rgb; cv::cvtColor(img, rgb, cv::COLOR_BGR2RGB);
    cv::Mat resized; cv::resize(rgb, resized, cv::Size(W, H));
    cv::Mat fmat; resized.convertTo(fmat, CV_32F);
    size_t total = (size_t)N * H * W * C;
    std::vector<float> input_data(total);
    if (in_attr.fmt == RKNN_TENSOR_NCHW) {
        for (int c=0;c<C;c++) for (int h=0;h<H;h++) for (int w=0;w<W;w++)
            input_data[(size_t)c*H*W+(size_t)h*W+w] = fmat.at<cv::Vec3f>(h,w)[c];
    } else {
        for (int h=0;h<H;h++) for (int w=0;w<W;w++) for (int c=0;c<C;c++)
            input_data[((size_t)h*W+w)*C+c] = fmat.at<cv::Vec3f>(h,w)[c];
    }
    rknn_input input; memset(&input, 0, sizeof(input)); input.index = 0;
    input.buf = input_data.data(); input.size = (uint32_t)(total*sizeof(float));
    input.type = RKNN_TENSOR_FLOAT32; input.fmt = in_attr.fmt;
    ret = rknn_inputs_set(ctx, 1, &input); if (ret < 0) { fprintf(stderr, "inputs_set failed %d\n", ret); return 1; }
    ret = rknn_run(ctx, NULL); if (ret < 0) { fprintf(stderr, "rknn_run failed %d\n", ret); return 1; }
    rknn_output output; memset(&output, 0, sizeof(output)); output.index = 0; output.want_float = 1;
    rknn_outputs_get(ctx, 1, &output, NULL);
    float* prob = (float*)output.buf; int nout = (int)(output.size/sizeof(float));
    int am = 0; float mx = prob[0]; float sum = 0.0f;
    for (int i=0;i<nout;i++) { sum += prob[i]; if (prob[i] > mx) { mx = prob[i]; am = i; } }
    std::vector<int> order(nout); for (int i=0;i<nout;i++) order[i]=i;
    std::sort(order.begin(), order.end(), [&](int a,int b){ return prob[a]>prob[b]; });
    for (int i : order) { const char* lab = (i<(int)labels.size())?labels[i].c_str():"?"; printf("  %-12s %.4f\n", lab, prob[i]); }
    printf("=> argmax %d (%s) conf=%.4f\n", am, (am<(int)labels.size()?labels[am].c_str():"?"), mx);
    rknn_outputs_release(ctx, 1, &output); rknn_destroy(ctx); return 0;
}
