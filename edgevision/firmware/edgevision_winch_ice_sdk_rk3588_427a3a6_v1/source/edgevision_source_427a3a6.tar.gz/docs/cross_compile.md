# 交叉编译说明

在 x86_64 编译机上编出 RK3576 板子用的 aarch64 程序。算法库和宿主分开编。

工具链是本机的 `g++-aarch64-linux-gnu`。没有时先安装：

```bash
sudo apt-get install -y g++-aarch64-linux-gnu
```

链接用的运行库在编译机上要有一份，板子上运行时用板子自己的同名库。

| 用途 | 编译机路径 |
|---|---|
| RKNN 运行库 | `/home/xp/rknn_sdk/lib/librknnrt.so` |
| RKNN 头文件 | `/home/xp/rknn_sdk/include/rknn_api.h` |
| GStreamer、glib、libdrm | `/home/xp/rk3576/rk3576_linux6.1_release/ubuntu/sysroots/armv8a-linux` |
| RGA 库（约 201 KB，2.1.0） | `/home/xp/evs_build_aarch64/third_party/rga/lib/librga.so` |
| RGA 头文件（同时有 `rga.h` 和 `im2d.h`） | 上面 sysroot 的 `usr/include/rga` |

`librknnrt.so` 要从板子 `/usr/lib/librknnrt.so` 拉下来。SDK sysroot 里那份是 2.0.0b0，和板端 2.3.0 不一致。RGA 不要用 `/home/xp/rknn_sdk/lib/librga.so`，那是精简版，缩放会失败。

## 1. 算法库

在 `edgevision` 目录执行。只编库，不编 GStreamer 和 RGA。取流和 RGA 属于宿主。

```bash
cd /home/xp/rk3576/new_qt5_qml/edgevision

cmake -S . -B build_board \
  -DCMAKE_TOOLCHAIN_FILE=cmake/aarch64-linux-gnu.toolchain.cmake \
  -DEVS_BACKEND=rknn \
  -DRKNN_API_LIB=/home/xp/rknn_sdk/lib/librknnrt.so \
  -DRKNN_API_INCLUDE_DIR=/home/xp/rknn_sdk/include \
  -DEVS_WITH_GSTREAMER=OFF \
  -DEVS_WITH_RGA=OFF

cmake --build build_board -j4 --target evs evs_shared evs_person_shared evs_height_limit_shared evs_ice_shared
```

`build_board` 已经配置过时，再传 `-DCMAKE_TOOLCHAIN_FILE` 不会生效。源码改完后直接：

```bash
cmake --build build_board -j4 --target evs evs_shared evs_person_shared evs_height_limit_shared evs_ice_shared
```

产物：

| 文件 | 用途 |
|---|---|
| `build_board/libevs_core.so.1` | 公共库。`VisionTask`、推理、解码、地面映射。SONAME 是 `libevs_core.so.1` |
| `build_board/libevs_core.so` | 指向 `libevs_core.so.1`，宿主链接时用 |
| `build_board/libevs_person.so.1` | 人员检测，`0x0004` / `0x0005` / `0x0006` |
| `build_board/libevs_height_limit.so.1` | 高度限位 `0x0007` |
| `build_board/libevs_ice.so.1` | 卷扬冰雪 `0x0008` |
| `build_board/libevs.a` 及 `libevs_person.a`、`libevs_height_limit.a`、`libevs_ice.a` | 静态库。`evs_task_cam` 整库链接它们 |

每个动态库旁边还有同名的无版本号符号链接，链接宿主时用那个链接。插件库在加载时向 `libevs_core.so` 登记自己的 `module_id`。

确认是板子能跑的文件：

```bash
file build_board/libevs_core.so.1 build_board/libevs_person.so.1
```

应显示 `ARM aarch64`。这个目录在 `.gitignore` 里，不要提交。

板上把用到的 `libevs_core.so.1` 和插件库放到程序同目录，或者放到 `/usr/lib`。只跑人员检测时带 `libevs_person.so.1`，只跑高度限位时带 `libevs_height_limit.so.1`。`librknnrt.so` 板子上已经有，不用再带。

## 2. 宿主参考程序

`user_evs_demo` 链接上一节的 `libevs_core.so` 和三个插件库，并默认打开 RGA。先编完算法库，再在宿主目录执行：

```bash
cd /home/xp/rk3576/new_qt5_qml/user_evs_demo

cmake -S . -B build \
  -DCMAKE_TOOLCHAIN_FILE=../edgevision/cmake/aarch64-linux-gnu.toolchain.cmake

cmake --build build -j4
```

`build` 已经配置过时，同样只执行第二条。只要 CPU 预处理时，第一次配置加上 `-DEVS_WITH_RGA=OFF`。1080p 下 CPU 缩放大约 75 ms，帧率会到 10 以下。

产物是 `build/user_evs_demo`。运行时在程序同目录找 `libevs_core.so.1` 和它链接的插件库。这个参考程序三个功能库都链了。日志里 `preprocess=rga` 表示硬件预处理已启用。

板上同一个目录需要：

- `user_evs_demo`
- `libevs_core.so.1`
- `libevs_person.so.1`、`libevs_height_limit.so.1`、`libevs_ice.so.1`
- 任务 YAML、`camera_config.json`、`yolox.rknn`

`librga.so.2` 使用板子系统里已有的库。

```bash
./user_evs_demo --task eval_yolox.yaml --config camera_config.json --channel 0 --frames 5
```

只改了库的内部实现、头文件布局没变时，宿主不用重编，换掉旁边的 `libevs_core.so.1` 和对应插件库即可。`Target` 字段或 `VisionTask` 接口变了，宿主必须用新头文件重新编译。
