# tools/linux_source —— Linux 联调取帧宿主（不链进算法库）

本目录是**库外宿主**示例：负责打开相机、把像素喂给 `evs::Frame`、调用 `evs::VisionTask::detect`、执行声光/主控联锁。它**不属于算法库**，CMake 默认不编译进 `evs` 目标。

阶段 4 落地时，复用 `qt5_qml_c001` 的取帧能力：

- `camera_shm_multi` 的 `start_camera` / `CameraConfig` / `CameraManager`：产出 raw 帧（v4l2src / AHD 解码 / rtspsrc）。
- 把 `Frame.data`（或导出 dma_fd）指向取到的 1080p NV12/RGB 缓冲，调用 `detect`。
- 会话对象按 `camera_id` 把臂头帧分发给 0x0004/0x0005/0x0007，长焦×2→0x0006，卷扬×2→0x0008。
- 可选录像：按 `h264_enc_worker` 模式挂 H.264 编码进程，同环消费 raw 帧，不进算法库。

算法库 CMake **不查找 GStreamer / Qt / mpp**，宿主程序单独链接这些。
