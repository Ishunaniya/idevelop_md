#pragma once
#include "ui_support.h"
#include <QObject>
#include <QQuickPaintedItem>
#include <QTimer>

namespace ice_ui {
struct UiOptions {
    QString taskPath, cameraPath, snapshotDirectory;
    int channel = 0, frameLimit = 0, quitAfterMs = 0;
    bool snapshotOnFinish = false, logJson = false;
};

class IceController : public QObject {
    Q_OBJECT
    Q_PROPERTY(bool active READ active NOTIFY changed)
    Q_PROPERTY(bool stopping READ stopping NOTIFY changed)
    Q_PROPERTY(bool canSnapshot READ canSnapshot NOTIFY changed)
    Q_PROPERTY(int channel READ channel NOTIFY changed)
    Q_PROPERTY(QString channelText READ channelText NOTIFY changed)
    Q_PROPERTY(QString statusText READ statusText NOTIFY changed)
    Q_PROPERTY(QString statusColor READ statusColor NOTIFY changed)
    Q_PROPERTY(QString infoText READ infoText NOTIFY changed)
    Q_PROPERTY(QString message READ message NOTIFY changed)
public:
    explicit IceController(UiOptions options, QObject* parent = nullptr);
    ~IceController() override;
    bool active() const { return bool(session_); }
    bool stopping() const;
    bool canSnapshot() const { return bool(observation()); }
    int channel() const { return options_.channel; }
    QString channelText() const;
    QString statusText() const { return statusText_; }
    QString statusColor() const { return statusColor_; }
    QString infoText() const { return infoText_; }
    QString message() const { return message_; }
    int exitCode() const { return exitCode_; }
    std::shared_ptr<const Observation> observation() const;
    Q_INVOKABLE void start();
    Q_INVOKABLE void stop();
    Q_INVOKABLE void nextChannel();
    Q_INVOKABLE void snapshot();
    Q_INVOKABLE void quitApp();
signals:
    void changed();
    void frameChanged();
    void finished();
private:
    struct Session;
    void poll();
    void clearObservation();
    UiOptions options_;
    std::vector<CameraConfig> cameras_;
    std::unique_ptr<Session> session_;
    QTimer timer_;
    mutable std::mutex displayMutex_;
    std::shared_ptr<const Observation> observation_;
    uint64_t generation_ = 0, lastSequence_ = 0;
    qint64 rateStartedMs_ = 0;
    uint64_t rateCaptured_ = 0, rateProcessed_ = 0;
    double captureFps_ = -1, detectFps_ = -1;
    bool explicitStop_ = false, quitting_ = false, stale_ = false;
    int exitCode_ = 0;
    QString statusText_ = QStringLiteral("已停止"), statusColor_ = QStringLiteral("#8AA0B8");
    QString infoText_, message_;
};

class IceView : public QQuickPaintedItem {
    Q_OBJECT
    Q_PROPERTY(ice_ui::IceController* controller READ controller WRITE setController NOTIFY controllerChanged)
public:
    explicit IceView(QQuickItem* parent = nullptr);
    IceController* controller() const { return controller_; }
    void setController(IceController* controller);
    void paint(QPainter* painter) override;
signals:
    void controllerChanged();
private:
    IceController* controller_ = nullptr;
    QMetaObject::Connection updateConnection_;
};
} // namespace ice_ui
