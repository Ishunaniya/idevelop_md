import QtQuick 2.9
import QtQuick.Window 2.2
import EVS.Ice 1.0

Window {
    id: root
    width: 1280
    height: 800
    minimumWidth: 800
    minimumHeight: 480
    visibility: Window.Maximized
    visible: true
    color: "#0E1726"
    title: "卷扬冰雪实时检测"
    onClosing: {
        close.accepted = false
        ice.quitApp()
    }

    Rectangle {
        id: header
        anchors { top: parent.top; left: parent.left; right: parent.right }
        height: 86
        color: "#16233A"
        Text {
            anchors { left: parent.left; leftMargin: 24; top: parent.top; topMargin: 12 }
            text: "EVS · 卷扬冰雪"
            color: "#22D3EE"
            font { pixelSize: 26; bold: true }
        }
        Text {
            anchors { left: parent.left; leftMargin: 24; bottom: parent.bottom; bottomMargin: 12 }
            width: 232
            text: ice.channelText
            textFormat: Text.PlainText
            elide: Text.ElideMiddle
            color: "#A9BCD1"
            font.pixelSize: 16
        }
        Text {
            anchors { right: parent.right; rightMargin: 24; verticalCenter: parent.verticalCenter }
            width: parent.width - 288
            horizontalAlignment: Text.AlignRight
            text: ice.statusText
            textFormat: Text.PlainText
            color: ice.statusColor
            wrapMode: Text.WrapAnywhere
            maximumLineCount: 2
            elide: Text.ElideRight
            font { pixelSize: 23; bold: true }
        }
    }
    IceView {
        id: view
        anchors { top: header.bottom; left: parent.left; right: parent.right; bottom: footer.top }
        controller: ice
    }
    Rectangle {
        id: footer
        anchors { left: parent.left; right: parent.right; bottom: parent.bottom }
        height: 178
        color: "#16233A"
        Text {
            anchors { top: parent.top; topMargin: 10; horizontalCenter: parent.horizontalCenter }
            width: parent.width - 32
            horizontalAlignment: Text.AlignHCenter
            elide: Text.ElideRight
            text: ice.infoText.length ? ice.infoText : "等待相机与检测结果"
            textFormat: Text.PlainText
            color: "#A9BCD1"
            font.pixelSize: 15
        }
        Text {
            anchors { top: parent.top; topMargin: 50; horizontalCenter: parent.horizontalCenter }
            width: parent.width - 32
            text: "框内冰雪估算（非定位置信度） · 绿色＜阈值 / 红色≥阈值 / 黄色 N/A"
            horizontalAlignment: Text.AlignHCenter
            color: "#CBD5E1"
            font.pixelSize: 14
            elide: Text.ElideRight
        }
        Row {
            anchors { horizontalCenter: parent.horizontalCenter; top: parent.top; topMargin: 72 }
            spacing: 16
            Repeater {
                model: [
                    {label: "开始检测", action: "toggle"},
                    {label: "切换通道", action: "channel"},
                    {label: "保存快照", action: "snapshot"},
                    {label: "退出", action: "quit"}
                ]
                delegate: Rectangle {
                    property bool available: modelData.action === "channel" ? !ice.active
                        : modelData.action === "snapshot" ? ice.canSnapshot
                        : modelData.action === "toggle" ? !ice.stopping : true
                    width: Math.min(172, (root.width - 80) / 4); height: 58; radius: 9
                    opacity: available ? 1 : 0.35
                    color: mouse.pressed ? "#22607C" : "#20334D"
                    border { color: "#22D3EE"; width: 1 }
                    Text {
                        anchors.centerIn: parent
                        text: modelData.action === "toggle" && ice.stopping ? "正在停止…"
                            : modelData.action === "toggle" && ice.active ? "停止检测" : modelData.label
                        color: "#E5EDF5"
                        font.pixelSize: 21
                    }
                    MouseArea {
                        id: mouse
                        anchors.fill: parent
                        enabled: parent.available
                        onClicked: {
                            if (modelData.action === "toggle") ice.active ? ice.stop() : ice.start()
                            else if (modelData.action === "channel") ice.nextChannel()
                            else if (modelData.action === "snapshot") ice.snapshot()
                            else ice.quitApp()
                        }
                    }
                }
            }
        }
        Text {
            anchors { bottom: parent.bottom; bottomMargin: 10; left: parent.left; right: parent.right; margins: 16 }
            text: ice.message.length ? ice.message : "按检测框面积估算，背景和反光可能计入；编号仅本帧有效。切换通道前请停止。"
            textFormat: Text.PlainText
            color: "#A9BCD1"
            elide: Text.ElideMiddle
            horizontalAlignment: Text.AlignHCenter
            font.pixelSize: 14
        }
    }
}
