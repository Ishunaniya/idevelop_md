#pragma once
#include "ui_support.h"
#include <gst/gst.h>
#include <gst/app/gstappsink.h>

namespace ice_ui {
// Only used by the capture thread. No Qt GUI or algorithm calls here.
class CameraSource {
public:
    CameraSource() = default;
    ~CameraSource();
    CameraSource(const CameraSource&) = delete;
    CameraSource& operator=(const CameraSource&) = delete;
    void open(const CameraConfig& camera);
    std::shared_ptr<RgbFrame> grab(int timeoutMs);
    static std::shared_ptr<RgbFrame> fromSample(GstSample* sample);
private:
    void checkBus();
    GstElement* pipeline_ = nullptr;
    GstAppSink* sink_ = nullptr; // borrowed from pipeline_
};
} // namespace ice_ui
