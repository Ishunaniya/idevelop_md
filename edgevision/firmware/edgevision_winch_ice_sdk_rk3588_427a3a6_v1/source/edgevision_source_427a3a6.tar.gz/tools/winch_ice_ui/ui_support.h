#pragma once

#include <QImage>
#include <QJsonObject>
#include <QPainter>
#include <QString>
#include <chrono>
#include <condition_variable>
#include <cstdint>
#include <memory>
#include <mutex>
#include <vector>
#include "evs/winch_ice.h"

namespace ice_ui {

struct CameraConfig {
    int channel = 0;
    QString device;
    bool enabled = false;
    int width = 1920, height = 1080, fps = 25;
};

std::vector<CameraConfig> loadCameras(const QString& path);
const CameraConfig& selectCamera(const std::vector<CameraConfig>& cameras, int channel);
qint64 monotonicMs();
std::vector<uint8_t> packRgb(const uint8_t* source, size_t sourceBytes,
                             int width, int height, int stride);

// One slot also bounds the GUI delivery path: no per-frame queued image signals.
template <class T> class LatestMailbox {
public:
    bool put(std::shared_ptr<T> value) {
        std::lock_guard<std::mutex> lock(mutex_);
        if (closed_) return false;
        value_ = std::move(value);
        ready_.notify_one();
        return true;
    }
    std::shared_ptr<T> take(int waitMs = 0) {
        std::unique_lock<std::mutex> lock(mutex_);
        if (waitMs > 0)
            ready_.wait_for(lock, std::chrono::milliseconds(waitMs),
                            [&] { return closed_ || bool(value_); });
        auto value = std::move(value_);
        return value;
    }
    void close() {
        std::lock_guard<std::mutex> lock(mutex_);
        closed_ = true;
        ready_.notify_all();
    }
private:
    std::mutex mutex_;
    std::condition_variable ready_;
    bool closed_ = false;
    std::shared_ptr<T> value_;
};

struct RgbFrame {
    uint64_t session = 0, sequence = 0;
    int channel = 0, width = 0, height = 0;
    qint64 capturedMs = 0;
    std::vector<uint8_t> pixels;
};

struct Observation {
    uint64_t session = 0, sequence = 0;
    int channel = 0;
    qint64 capturedMs = 0, completedMs = 0;
    double detectMs = 0;
    float threshold = .5f;
    uint32_t status = 0;
    QString error;
    QImage image; // Owns its storage; never aliases a mapped GstBuffer.
    evs::winch_ice::WinchSnowResult result;
};

QString resultText(const Observation& frame);
QString resultColor(const Observation& frame);
QString objectLabel(size_t index, const evs::winch_ice::WinchObjectResult& object);
QJsonObject observationJson(const Observation& frame);
QRectF fittedRect(const QRectF& area, const QSize& image);
void paintObservation(QPainter& painter, const QRectF& area, const Observation& frame);
QString saveSnapshot(const QString& directory, const Observation& frame);

} // namespace ice_ui
