#include "ice_controller.h"
#include <QCommandLineParser>
#include <QCoreApplication>
#include <QFileInfo>
#include <QGuiApplication>
#include <QJsonDocument>
#include <QQmlApplicationEngine>
#include <QQmlContext>
#include <cstdio>
#include <csignal>
#include <gst/gst.h>
#include <stdexcept>

namespace {
volatile std::sig_atomic_t pendingSignal = 0;
void requestTermination(int signal) { pendingSignal = signal; }
// Signal handlers only set a flag. Qt calls and worker shutdown run in the GUI thread.
class TerminationSignals {
public:
    TerminationSignals() {
        struct sigaction action {};
        action.sa_handler = requestTermination;
        sigemptyset(&action.sa_mask);
        for (; installed_ < 3; ++installed_) {
            if (sigaction(signals_[installed_], &action, &previous_[installed_]) != 0) {
                restore();
                throw std::runtime_error("cannot install termination signal handler");
            }
        }
    }
    ~TerminationSignals() { restore(); }
private:
    void restore() {
        while (installed_ > 0) {
            --installed_;
            sigaction(signals_[installed_], &previous_[installed_], nullptr);
        }
    }
    const int signals_[3] = {SIGINT, SIGTERM, SIGHUP};
    struct sigaction previous_[3] {};
    int installed_ = 0;
};
int nonnegative(const QCommandLineParser& parser, const char* name) {
    bool valid = false;
    const int value = parser.value(QLatin1String(name)).toInt(&valid);
    if (!valid || value < 0) throw std::runtime_error(std::string("invalid --") + name);
    return value;
}
}

int main(int argc, char** argv) {
    QGuiApplication app(argc, argv);
    app.setApplicationName("winch_ice_ui");
    app.setApplicationVersion("1.1");
    QCommandLineParser parser;
    parser.setApplicationDescription(QStringLiteral("相机 → 卷扬冰雪动态库 → 同帧实时显示"));
    parser.addHelpOption();
    parser.addVersionOption();
    parser.addOptions({
        {{"t", "task"}, "Algorithm YAML (required)", "path"},
        {{"c", "config"}, "Camera JSON array (required)", "path"},
        {"channel", "Strict camera channel selection", "N", "0"},
        {"snapshot-dir", "Snapshot output directory", "path", "ice_snapshots"},
        {"frames", "Stop and exit after N detections; 0 runs until stopped", "N", "0"},
        {"quit-after-ms", "Stop and exit after a time limit (verification)", "ms", "0"},
        {"snapshot-on-finish", "Save the final processed frame when --frames completes"},
        {"log-json", "Log each actual Detector call and its frame sequence"},
        {"no-autostart", "Wait for the Start button"}
    });
    parser.process(app);
    try {
        if (!parser.isSet("task") || !parser.isSet("config")) parser.showHelp(1);
        ice_ui::UiOptions options;
        options.taskPath = QFileInfo(parser.value("task")).absoluteFilePath();
        options.cameraPath = QFileInfo(parser.value("config")).absoluteFilePath();
        options.snapshotDirectory = QFileInfo(parser.value("snapshot-dir")).absoluteFilePath();
        options.channel = nonnegative(parser, "channel");
        options.frameLimit = nonnegative(parser, "frames");
        options.quitAfterMs = nonnegative(parser, "quit-after-ms");
        options.snapshotOnFinish = parser.isSet("snapshot-on-finish");
        options.logJson = parser.isSet("log-json");
        GError* error = nullptr;
        if (!gst_init_check(nullptr, nullptr, &error)) {
            const auto text = error ? std::string(error->message) : "gst_init_check failed";
            if (error) g_error_free(error);
            throw std::runtime_error(text);
        }
        ice_ui::IceController controller(options);
        TerminationSignals terminationSignals;
        QTimer signalTimer;
        signalTimer.setInterval(100);
        QObject::connect(&signalTimer, &QTimer::timeout, &controller, [&] {
            if (pendingSignal) {
                pendingSignal = 0;
                controller.quitApp();
            }
        });
        signalTimer.start();
        qmlRegisterType<ice_ui::IceView>("EVS.Ice", 1, 0, "IceView");
        qmlRegisterUncreatableType<ice_ui::IceController>("EVS.Ice", 1, 0, "IceController", "Created by host");
        QQmlApplicationEngine engine;
        engine.rootContext()->setContextProperty("ice", &controller);
        engine.load(QUrl("qrc:/ice/Main.qml"));
        if (engine.rootObjects().isEmpty()) return 2;
        const QJsonObject ready{{"event", "ready"}, {"version", app.applicationVersion()},
            {"qt_version", qVersion()}, {"gstreamer_version", gst_version_string()},
            {"platform", QGuiApplication::platformName()}, {"camera_config", options.cameraPath},
            {"task_config", options.taskPath}};
        std::printf("%s\n", QJsonDocument(ready).toJson(QJsonDocument::Compact).constData());
        std::fflush(stdout);
        QObject::connect(&controller, &ice_ui::IceController::finished, &app, [&] {
            if (options.frameLimit > 0 || options.quitAfterMs > 0) app.exit(controller.exitCode());
        });
        if (!parser.isSet("no-autostart")) QTimer::singleShot(0, &controller, &ice_ui::IceController::start);
        if (options.quitAfterMs > 0) QTimer::singleShot(options.quitAfterMs, &controller,
                                                     &ice_ui::IceController::quitApp);
        return app.exec();
    } catch (const std::exception& ex) {
        std::fprintf(stderr, "winch_ice_ui: %s\n", ex.what());
        return 2;
    }
}
