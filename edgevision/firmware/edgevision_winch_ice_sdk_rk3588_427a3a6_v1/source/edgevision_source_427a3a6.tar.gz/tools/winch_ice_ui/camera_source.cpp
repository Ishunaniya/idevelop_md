#include "camera_source.h"
#include <gst/video/video.h>
#include <stdexcept>

namespace ice_ui {
namespace {
[[noreturn]] void fail(const QString& message) { throw std::runtime_error(message.toStdString()); }
}
CameraSource::~CameraSource() {
    if (pipeline_) {
        gst_element_set_state(pipeline_, GST_STATE_NULL);
        gst_object_unref(pipeline_);
    }
}

void CameraSource::open(const CameraConfig& camera) {
    if (pipeline_) fail(QStringLiteral("相机已经打开"));
    // Device is assigned as a property, never interpolated into a pipeline command.
    GError* error = nullptr;
    pipeline_ = gst_parse_launch(
        "v4l2src name=source io-mode=mmap ! capsfilter name=input_caps ! "
        "videoconvert ! video/x-raw,format=RGB ! "
        "appsink name=frames drop=true max-buffers=1 sync=false wait-on-eos=false enable-last-sample=false", &error);
    if (error) {
        const QString message = QString::fromUtf8(error->message);
        g_error_free(error);
        fail(QStringLiteral("GStreamer 管线创建失败：%1").arg(message));
    }
    if (!pipeline_) fail(QStringLiteral("GStreamer 管线为空"));
    auto* source = gst_bin_get_by_name(GST_BIN(pipeline_), "source");
    auto* filter = gst_bin_get_by_name(GST_BIN(pipeline_), "input_caps");
    auto* sink = gst_bin_get_by_name(GST_BIN(pipeline_), "frames");
    if (!source || !filter || !sink) {
        if (source) gst_object_unref(source);
        if (filter) gst_object_unref(filter);
        if (sink) gst_object_unref(sink);
        fail(QStringLiteral("缺少 GStreamer 采集元件"));
    }
    const auto device = camera.device.toUtf8();
    g_object_set(source, "device", device.constData(), nullptr);
    auto* caps = gst_caps_new_simple("video/x-raw", "width", G_TYPE_INT, camera.width,
        "height", G_TYPE_INT, camera.height, "framerate", GST_TYPE_FRACTION, camera.fps, 1, nullptr);
    g_object_set(filter, "caps", caps, nullptr);
    gst_caps_unref(caps);
    sink_ = GST_APP_SINK(sink);
    gst_object_unref(source);
    gst_object_unref(filter);
    gst_object_unref(sink);
    if (gst_element_set_state(pipeline_, GST_STATE_PLAYING) == GST_STATE_CHANGE_FAILURE) {
        checkBus();
        fail(QStringLiteral("相机管线无法启动：%1").arg(camera.device));
    }
}

void CameraSource::checkBus() {
    auto* bus = gst_element_get_bus(pipeline_);
    auto* message = gst_bus_pop_filtered(bus, GstMessageType(GST_MESSAGE_ERROR | GST_MESSAGE_EOS));
    gst_object_unref(bus);
    if (!message) return;
    QString description;
    if (GST_MESSAGE_TYPE(message) == GST_MESSAGE_ERROR) {
        GError* error = nullptr;
        gchar* debug = nullptr;
        gst_message_parse_error(message, &error, &debug);
        description = QString::fromUtf8(error ? error->message : "unknown GStreamer error");
        if (debug) description += " (" + QString::fromUtf8(debug) + ")";
        if (error) g_error_free(error);
        g_free(debug);
    } else description = QStringLiteral("相机流已结束");
    gst_message_unref(message);
    fail(description);
}

std::shared_ptr<RgbFrame> CameraSource::grab(int timeoutMs) {
    checkBus();
    auto* sample = gst_app_sink_try_pull_sample(sink_, GstClockTime(timeoutMs) * GST_MSECOND);
    if (!sample) { checkBus(); return {}; }
    try {
        auto frame = fromSample(sample);
        gst_sample_unref(sample);
        return frame;
    } catch (...) {
        gst_sample_unref(sample);
        throw;
    }
}

std::shared_ptr<RgbFrame> CameraSource::fromSample(GstSample* sample) {
    if (!sample) fail(QStringLiteral("相机样本为空"));
    GstVideoInfo info;
    gst_video_info_init(&info);
    if (!gst_sample_get_caps(sample) ||
        !gst_video_info_from_caps(&info, gst_sample_get_caps(sample)) ||
        GST_VIDEO_INFO_FORMAT(&info) != GST_VIDEO_FORMAT_RGB)
        fail(QStringLiteral("相机协商格式不是 RGB"));
    auto* buffer = gst_sample_get_buffer(sample);
    GstVideoFrame mapped;
    if (!buffer || !gst_video_frame_map(&mapped, &info, buffer, GST_MAP_READ))
        fail(QStringLiteral("无法映射相机 RGB 帧"));
    try {
        auto frame = std::make_shared<RgbFrame>();
        frame->capturedMs = monotonicMs();
        frame->width = GST_VIDEO_INFO_WIDTH(&info);
        frame->height = GST_VIDEO_INFO_HEIGHT(&info);
        const auto* data = static_cast<const uint8_t*>(GST_VIDEO_FRAME_PLANE_DATA(&mapped, 0));
        const auto* begin = mapped.map[0].data;
        if (!begin || data < begin || size_t(data - begin) > mapped.map[0].size)
            fail(QStringLiteral("RGB 平面偏移超出缓冲范围"));
        frame->pixels = packRgb(data, mapped.map[0].size - size_t(data - begin),
            frame->width, frame->height, GST_VIDEO_FRAME_PLANE_STRIDE(&mapped, 0));
        gst_video_frame_unmap(&mapped);
        return frame;
    } catch (...) {
        gst_video_frame_unmap(&mapped);
        throw;
    }
}
} // namespace ice_ui
