#!/bin/sh
set -eu

# Resolve the install prefix instead of inheriting a caller's working directory.
script_dir=$(CDPATH= cd -- "$(dirname -- "$0")" && pwd)
prefix_dir=$(CDPATH= cd -- "$script_dir/.." && pwd)
task_path=${EVS_ICE_TASK:-"$prefix_dir/share/edgevision/configs/winch_ice.yaml"}
camera_path=${EVS_ICE_CAMERAS:-"$prefix_dir/share/edgevision/configs/camera_config.json"}
snapshot_dir=${EVS_ICE_SNAPSHOTS:-"$prefix_dir/snapshots"}
QT_QUICK_BACKEND=${QT_QUICK_BACKEND:-software}
export QT_QUICK_BACKEND

# Inherit the user's graphical session. Over SSH these can be supplied explicitly.
# Do not guess another user's Xauthority, kill other detectors, or change system libraries.
exec "$script_dir/winch_ice_ui" --task "$task_path" --config "$camera_path" \
    --snapshot-dir "$snapshot_dir" "$@"
