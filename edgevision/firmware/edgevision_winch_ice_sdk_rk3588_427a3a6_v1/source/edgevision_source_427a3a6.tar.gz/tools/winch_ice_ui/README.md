# 卷扬冰雪实时 UI

这是调用卷扬冰雪动态库的单路 Qt Quick 宿主，负责相机采集、图像和结果配对、实时显示及快照保存。

```text
camera_config.json 选择通道和设备
  → GStreamer / V4L2 采集并转换为 RGB
  → 配套 libevs_ice + libevs_core / Detector / RKNN
  → 同一帧的图像、对象、比例、报警和帧号
  → Qt Quick 显示
```

算法接口、输入内存约定、计量规则及库兼容要求见[卷扬冰雪接入说明](../../docs/winch_ice.md)。本目录不是独立 CMake 工程，需要从仓库根目录构建。

## 1. 功能和显示含义

- 开始/停止检测；停止后切换 JSON 中已启用的通道；保存快照；正常退出。
- 图像等比例显示，框坐标来自算法返回的原图像素坐标。
- `#1 框内冰雪估算 13.2%`：`#1` 是本帧序号；百分比是 `ice_ratio × 100%`。
- 有效比例低于阈值显示绿色，达到或超过阈值显示红色；无效对象显示黄色虚线框和 `N/A`；没有目标显示 `NO RESULT`。
- 默认报警阈值 `area_ratio: 0.5`，即50%；整体报警读取库的 `alert_level`。

**百分比的分母是整个检测矩形框面积。**它是框内冰雪候选像素占比估算，不是模型置信度，也不是经过分割和标定的真实卷扬表面覆盖率。背景、白色物体和反光可能误计，暗雪和透明冰可能漏计。当前模型在室内地面场景存在卷扬误检，链路正常不表示精度合格。

## 2. 运行环境与依赖

已验证环境为 RK3588、AArch64 Ubuntu、Qt 5.15.3、GStreamer 1.22.9、OpenCV 4.5.4及设备配套的RKNN运行库。构建要求CMake≥3.14、C++17、Qt5≥5.12、GStreamer≥1.16；这些下限不表示已逐版本实测。

需要以下开发和运行组件，Ubuntu对应包名可作为准备清单：

```sh
sudo apt-get install build-essential cmake pkg-config python3 \
  qtbase5-dev qtdeclarative5-dev qml-module-qtquick2 qml-module-qtquick-window2 \
  libopencv-dev libgstreamer1.0-dev libgstreamer-plugins-base1.0-dev \
  gstreamer1.0-tools gstreamer1.0-plugins-base gstreamer1.0-plugins-good
```

还需单独准备匹配的RKNN SDK头文件、RKNN运行库及卷扬模型。程序需要相机设备的访问权限；显示窗口需要可用的Qt平台/QML插件、字体及用户桌面会话。

## 3. 从源码构建

以下命令在**RK3588 Ubuntu构建机的仓库根目录**运行。将两处RKNN路径替换为实际路径：

```sh
cmake -S . -B build_ice_ui \
  -DCMAKE_BUILD_TYPE=RelWithDebInfo \
  -DCMAKE_INSTALL_PREFIX="$PWD/package_ice" \
  -DEVS_BACKEND=rknn \
  -DEVS_WITH_OPENCV=ON \
  -DEVS_BUILD_SHARED=ON \
  -DEVS_BUILD_ICE_UI=ON \
  -DEVS_BUILD_TESTS=ON \
  -DEVS_BUILD_TOOLS=OFF \
  -DEVS_BUILD_LEGACY_TOOLS=OFF \
  -DRKNN_API_INCLUDE_DIR=/path/to/rknn/include \
  -DRKNN_API_LIB=/path/to/librknnrt.so
cmake --build build_ice_ui -j2
ctest --test-dir build_ice_ui --output-on-failure
cmake --install build_ice_ui
cp winch_model.rknn package_ice/share/edgevision/winch_model.rknn
```

`EVS_BUILD_ICE_UI`默认OFF。开启它才检查Qt及UI所需的GStreamer组件，不会让普通算法库构建强制依赖Qt。

`EVS_BUILD_TOOLS=OFF`关闭其他冰雪命令行demo，不影响显式开启的UI。若需要`ice_replay`、`winch_ice_demo`，设为ON；相机CLI还需`EVS_WITH_GSTREAMER=ON`。UI自身始终需要GStreamer，不能用`EVS_WITH_GSTREAMER=OFF`关闭UI内部的取流依赖。

不运行测试时可设`EVS_BUILD_TESTS=OFF`。开启UI要求Linux、`EVS_BUILD_SHARED=ON`和`EVS_WITH_OPENCV=ON`。依赖不满足会明确配置失败。

## 4. 安装包与部署

默认安装目录如下，实际库目录由`CMAKE_INSTALL_LIBDIR`决定，可能是`lib`、`lib64`或多架构目录：

```text
package_ice/
  bin/winch_ice_ui
  bin/run_winch_ice_ui.sh
  lib/...libevs_ice.so.1、libevs_core.so.1及链接名
  include/evs/
  share/edgevision/
    configs/camera_config.json
    configs/winch_ice.yaml
    winch_model.rknn                 手动复制；CMake不安装模型
    docs/winch_ice.md
    docs/plugin_architecture.md
    tools/winch_ice_ui/README.md
```

`Model_path: ../winch_model.rknn`相对于算法YAML所在目录解析。不要把相机JSON中的1920×1080改成模型输入640×640；它们分别是采集分辨率和算法输入尺寸，库负责模型预处理。

运行包依赖目标设备的Qt、GStreamer、OpenCV和RKNN环境，并非自包含系统镜像。PC原生x86_64产物不能直接在ARM板运行；交叉编译时需要目标架构的完整工具链、sysroot和依赖。本README的构建命令采用板端原生构建。

需要转移到另一台匹配设备时，在构建机打包整个安装目录，保留动态库符号链接：

```sh
tar -czf winch_ice_ui_package.tar.gz package_ice
scp winch_ice_ui_package.tar.gz hytop@192.168.2.127:/home/hytop/l_evs/
```

在目标设备解压到独立目录：

```sh
mkdir -p /home/hytop/l_evs/ice_ui_release
tar -xzf /home/hytop/l_evs/winch_ice_ui_package.tar.gz \
  -C /home/hytop/l_evs/ice_ui_release
ldd /home/hytop/l_evs/ice_ui_release/package_ice/bin/winch_ice_ui
```

确认没有`not found`，并且`libevs_ice.so.1`和`libevs_core.so.1`来自该安装包的库目录。核心库、冰雪库和模型应配套部署。默认`bin`布局可整体搬迁；自定义嵌套可执行文件目录时，需另外核对启动脚本的默认配置和快照路径。

## 5. 启动与操作

在设备已登录桌面的终端运行：

```sh
/home/hytop/l_evs/ice_ui_release/package_ice/bin/run_winch_ice_ui.sh --channel 0
```

从SSH显示到设备屏幕时，应使用该用户实际图形会话的环境。下面是本轮在192.168.2.127上核对过的X11会话：

```sh
DISPLAY=:0 \
XAUTHORITY=/run/user/1000/gdm/Xauthority \
XDG_RUNTIME_DIR=/run/user/1000 \
/home/hytop/l_evs/ice_ui_release/package_ice/bin/run_winch_ice_ui.sh --channel 0
```

会话路径可能随登录方式改变，不要在其他设备上盲目照抄。运行前退出占用同一相机的旧窗口。

本轮已经部署的实际入口是下面这个路径，直接运行它即可，无需再解压示例目录：

```sh
/home/hytop/l_evs/winch_ice_ui_demo_20261021/package/bin/run_winch_ice_ui.sh --channel 0
```

程序默认自动开始。停止后才能切换通道；修改配置后停止/开始会重新读取。退出按钮、窗口关闭、SIGINT、SIGTERM和SIGHUP会请求正常停止。同步NPU调用和驱动状态切换没有硬取消接口，退出仍可能需要等待当前调用返回。

启动脚本默认`QT_QUICK_BACKEND=software`，可通过同名环境变量覆盖。桌面SSH会话退出可能触发SIGHUP；需要跨SSH会话持续运行时，应由部署方明确配置进程管理方式，本工具没有自动安装开机服务。

## 6. 配置、参数与快照

相机配置见[示例JSON](../../configs/camera_config.json)。UI读取`channel`、`device`、`enable`、`width`、`height`、`framerate`；`pos_x/pos_y`等旧界面位置字段不控制本窗口布局。

```json
[
  {"channel": 0, "device": "/dev/video0", "enable": true,
   "width": 1920, "height": 1080, "framerate": 25}
]
```

`device`必须是绝对路径。通道重复、禁用、缺失、字段类型错误会报错，不按数组下标选择，也不静默回退到其他相机。请求尺寸或帧率不受相机支持时可能协商失败。当前管线处理原始V4L2视频，不含MJPEG/H.264解码。

算法配置见[示例YAML](../../configs/winch_ice.yaml)，其中`confidence_threshold`是定位置信度阈值，`area_ratio`是冰雪估算占比报警阈值。两者含义不同。界面目前没有在线阈值编辑控件。

| 参数 | 用途 |
| --- | --- |
| `--channel N` | 选择JSON通道，默认0 |
| `--task PATH` / `--config PATH` | 覆盖算法YAML/相机JSON |
| `--snapshot-dir PATH` | 快照目录，脚本默认安装前缀下的`snapshots/` |
| `--no-autostart` | 等待点击开始 |
| `--frames N` | 完成N次检测后退出，0表示持续运行 |
| `--snapshot-on-finish` | 正常检测结束时保存最终帧，通常与`--frames`配合 |
| `--quit-after-ms N` | 验证用限时停止；不保证驱动/NPU阻塞时准点退出 |
| `--log-json` | 输出逐帧检测和界面交付记录，长期使用需控制日志容量 |

环境变量`EVS_ICE_TASK`、`EVS_ICE_CAMERAS`、`EVS_ICE_SNAPSHOTS`也可覆盖脚本默认路径。参数路径相对于调用者当前目录解析，脚本的默认配置不依赖当前工作目录。

快照保存同一帧的`_original.png`、`_overlay.png`和`_result.json`。JSON包含通道、会话、帧号、对象框、定位置信度、有效性、冰雪估算占比、报警及占比口径。每个文件分别原子写入，整组文件不是事务写入；JSON最后保存。默认不逐帧落图，手动PNG保存仍可能短时影响GUI响应。

无桌面验证链路时可运行以下命令；它不会在设备屏幕创建可见窗口：

```sh
QT_QPA_PLATFORM=offscreen \
/home/hytop/l_evs/winch_ice_ui_demo_20261021/package/bin/run_winch_ice_ui.sh \
  --channel 0 --frames 10 --snapshot-on-finish --log-json \
  --snapshot-dir /tmp/winch_ice_ui_check
```

## 7. 排障与验证边界

| 现象 | 先检查 |
| --- | --- |
| 无法连接显示器/认证失败 | 当前用户桌面是否登录，DISPLAY、XAUTHORITY、XDG_RUNTIME_DIR是否属于实际会话 |
| Qt平台/QML模块加载失败 | 目标设备的Qt平台插件、Qt Quick及Window模块是否安装；默认软件渲染不替代平台插件 |
| 相机打不开、协商失败或首帧超时 | JSON设备路径、访问权限、设备占用、相机支持的尺寸/帧率及V4L2/GStreamer插件 |
| 算法初始化失败 | RKNN模型路径、芯片与模型匹配、RKNN运行库、配套so版本；查看错误码和初始化日志 |
| `NO RESULT`或`N/A` | 不等于覆盖率0%；分别是未检测到卷扬或结果不可有效计量 |
| 有画面但框/比例不合理 | 保存原图和JSON，分别核对模型定位与颜色计量，不能靠改UI掩盖误检 |
| 启动后读取旧配置 | 确认启动的是哪份安装包，查看`ready`事件中的配置绝对路径，修改后停止/开始 |

UI启用时，`ctest -R evs_ice_ui_tests`覆盖通道选择、RGB行跨度/偏移、缓冲生命周期、最新帧交付、无效结果和快照等契约。2026-10-21版本1.1已完成7/7回归、53项UI契约检查、16项真实桌面检查、最终帧检查及1000帧真实相机检测（API错误0）。这些是当时结果，不替代后续修改后的验证。

实际物理相机验证为通道0。其他通道、其他板卡/显示后端、8～24小时稳定性和真实冰雪精度仍需分别验收。当前没有多相机并行、目标跟踪、自动重连、进程看门狗、报警锁存或PLC联锁。

## 8. 源码和CMake职责

- `camera_source.*`：GStreamer采集和RGB整理。
- `ice_controller.*`：采集/算法线程、单槽最新帧、会话生命周期和UI状态。
- `ui_support.*`：配置校验、结果显示、绘框及快照。
- `Main.qml`、`main.cpp`、`resources.qrc`：界面、命令行和资源入口。
- `tests.cpp`：UI宿主契约测试。
- `CMakeLists.txt`：Qt/GStreamer依赖、UI目标、AUTOMOC/AUTORCC、链接、RPATH、安装和测试。

根CMake只提供`EVS_BUILD_ICE_UI`开关、前置条件检查及`add_subdirectory`入口。根目录其余冰雪库、OpenCV、测试和通用安装规则服务于整个冰雪功能，不应与UI入口一起随意删除。
