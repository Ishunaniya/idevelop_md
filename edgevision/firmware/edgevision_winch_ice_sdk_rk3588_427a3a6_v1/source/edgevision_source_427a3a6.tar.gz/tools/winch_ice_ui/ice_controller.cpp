#include "ice_controller.h"
#include "camera_source.h"
#include <QCoreApplication>
#include <QDir>
#include <QJsonDocument>
#include <atomic>
#include <cstdio>
#include <stdexcept>
#include <thread>

namespace ice_ui {
struct IceController::Session {
    CameraConfig camera;
    UiOptions options;
    uint64_t generation;
    std::atomic<bool> stopRequested{false}, captureDone{true}, detectionDone{true};
    std::atomic<uint64_t> captured{0}, processed{0}, apiErrors{0};
    LatestMailbox<RgbFrame> frames;
    LatestMailbox<Observation> completed;
    std::thread captureThread, detectionThread;
    std::mutex errorMutex;
    QString error;

    Session(CameraConfig cameraConfig, UiOptions settings, uint64_t epoch)
        : camera(std::move(cameraConfig)), options(std::move(settings)), generation(epoch) {}
    void requestStop() { stopRequested = true; frames.close(); }
    void fail(const QString& message) {
        { std::lock_guard<std::mutex> lock(errorMutex); if (error.isEmpty()) error = message; }
        requestStop();
    }
    QString failure() {
        std::lock_guard<std::mutex> lock(errorMutex);
        return error;
    }
    void capture() noexcept {
        try {
            CameraSource source;
            source.open(camera);
            auto lastFrameMs = monotonicMs();
            bool first = true;
            while (!stopRequested) {
                auto frame = source.grab(200);
                if (!frame) {
                    if (monotonicMs() - lastFrameMs > (first ? 8000 : 3000))
                        throw std::runtime_error(first ? "相机首帧超时（8秒）" : "相机无新帧（3秒）");
                    continue;
                }
                first = false;
                lastFrameMs = frame->capturedMs;
                frame->session = generation;
                frame->sequence = ++captured;
                frame->channel = camera.channel;
                if (!stopRequested) frames.put(std::move(frame));
            }
        } catch (const std::exception& ex) {
            if (!stopRequested) fail(QString::fromUtf8(ex.what()));
        } catch (...) { fail(QStringLiteral("相机线程发生未知错误")); }
        frames.close();
        captureDone = true;
    }
    void detect() noexcept {
        try {
            using namespace evs::winch_ice;
            WinchSnowConfig config;
            auto status = load_config(options.taskPath.toStdString(), config);
            if (status)
                throw std::runtime_error(QStringLiteral("算法配置错误 0x%1").arg(status, 8, 16, QLatin1Char('0')).toStdString());
            // Reinitializing this session binds the selected physical input to this instance.
            config.camera_channel = uint32_t(camera.channel);
            Detector detector;
            if (!stopRequested) status = detector.initialize(config);
            if (status)
                throw std::runtime_error(QStringLiteral("算法初始化失败 0x%1").arg(status, 8, 16, QLatin1Char('0')).toStdString());
            while (!stopRequested) {
                const auto frame = frames.take(200);
                if (!frame || stopRequested) continue;
                auto result = std::make_shared<Observation>();
                result->session = frame->session;
                result->sequence = frame->sequence;
                result->channel = frame->channel;
                result->capturedMs = frame->capturedMs;
                result->threshold = config.detect_config.area_ratio;
                ImageData image;
                image.data = frame->pixels.data();
                image.width = uint32_t(frame->width);
                image.height = uint32_t(frame->height);
                image.channels = 3;
                image.timestamp_ms = uint32_t(frame->capturedMs);
                const auto begin = std::chrono::steady_clock::now();
                result->status = detector.detect(image, result->result);
                result->detectMs = std::chrono::duration<double, std::milli>(
                    std::chrono::steady_clock::now() - begin).count();
                result->completedMs = monotonicMs();
                result->image = QImage(frame->pixels.data(), frame->width, frame->height,
                                       frame->width * 3, QImage::Format_RGB888).copy();
                if (result->image.isNull()) throw std::runtime_error("无法分配显示图像");
                if (stopRequested) break;
                const auto done = ++processed;
                if (options.logJson) {
                    auto record = observationJson(*result);
                    record.insert("event", "detection");
                    const auto bytes = QJsonDocument(record).toJson(QJsonDocument::Compact);
                    std::printf("%s\n", bytes.constData());
                    std::fflush(stdout);
                }
                if (result->status) ++apiErrors;
                completed.put(std::move(result));
                // Per-frame API failures are observations too. A later good frame
                // may recover; only initialization/capture failures end a session.
                if (options.frameLimit > 0 && done >= uint64_t(options.frameLimit)) requestStop();
            }
            detector.release();
        } catch (const std::exception& ex) { fail(QString::fromUtf8(ex.what())); }
          catch (...) { fail(QStringLiteral("算法线程发生未知错误")); }
        detectionDone = true;
    }
    void launch() {
        captureDone = false;
        try { captureThread = std::thread([this] { capture(); }); }
        catch (...) { captureDone = true; throw; }
        detectionDone = false;
        try { detectionThread = std::thread([this] { detect(); }); }
        catch (...) { detectionDone = true; requestStop(); throw; }
    }
    ~Session() {
        requestStop();
        if (captureThread.joinable()) captureThread.join();
        if (detectionThread.joinable()) detectionThread.join();
    }
};

IceController::IceController(UiOptions options, QObject* parent)
    : QObject(parent), options_(std::move(options)), cameras_(loadCameras(options_.cameraPath)) {
    selectCamera(cameras_, options_.channel);
    timer_.setInterval(33);
    connect(&timer_, &QTimer::timeout, this, &IceController::poll);
    timer_.start();
}
IceController::~IceController() = default;

bool IceController::stopping() const { return session_ && session_->stopRequested; }

QString IceController::channelText() const {
    for (const auto& camera : cameras_)
        if (camera.channel == options_.channel)
            return QStringLiteral("通道 %1 · %2").arg(camera.channel).arg(camera.device);
    return QStringLiteral("通道 %1 · 配置已移除").arg(options_.channel);
}
std::shared_ptr<const Observation> IceController::observation() const {
    std::lock_guard<std::mutex> lock(displayMutex_);
    return observation_;
}
void IceController::clearObservation() {
    { std::lock_guard<std::mutex> lock(displayMutex_); observation_.reset(); }
    emit frameChanged();
}
void IceController::start() {
    if (session_) return;
    clearObservation();
    explicitStop_ = false;
    stale_ = false;
    exitCode_ = 0;
    lastSequence_ = 0;
    rateStartedMs_ = 0;
    captureFps_ = detectFps_ = -1;
    message_.clear();
    infoText_.clear();
    statusText_ = QStringLiteral("启动相机与算法中…");
    statusColor_ = "#22D3EE";
    try {
        auto cameras = loadCameras(options_.cameraPath);
        const auto camera = selectCamera(cameras, options_.channel);
        cameras_ = std::move(cameras);
        session_ = std::make_unique<Session>(camera, options_, ++generation_);
        session_->launch();
    } catch (const std::exception& ex) {
        exitCode_ = 2;
        statusText_ = QString::fromUtf8(ex.what());
        statusColor_ = "#EF4444";
        if (session_) session_->fail(statusText_);
        else QTimer::singleShot(0, this, [this] { emit finished(); });
    }
    emit changed();
}
void IceController::stop() {
    if (!session_) return;
    explicitStop_ = true;
    session_->requestStop();
    statusText_ = QStringLiteral("正在停止…");
    statusColor_ = "#8AA0B8";
    clearObservation();
    infoText_.clear();
    emit changed();
}
void IceController::nextChannel() {
    if (session_) return;
    try {
        auto cameras = loadCameras(options_.cameraPath);
        std::vector<int> enabled;
        for (const auto& camera : cameras) if (camera.enabled) enabled.push_back(camera.channel);
        if (enabled.empty()) throw std::runtime_error("没有已启用的相机通道");
        int selected = enabled.front();
        for (size_t i = 0; i < enabled.size(); ++i)
            if (enabled[i] == options_.channel) selected = enabled[(i + 1) % enabled.size()];
        cameras_ = std::move(cameras);
        options_.channel = selected;
    } catch (const std::exception& ex) {
        message_ = QString::fromUtf8(ex.what());
        emit changed();
        return;
    }
    clearObservation();
    infoText_.clear();
    message_ = QStringLiteral("已选择新通道，点击开始检测");
    statusText_ = QStringLiteral("已停止");
    statusColor_ = "#8AA0B8";
    emit changed();
}
void IceController::snapshot() {
    try {
        auto frame = observation();
        if (!frame) throw std::runtime_error("没有可保存的检测帧");
        const auto prefix = saveSnapshot(options_.snapshotDirectory, *frame);
        message_ = QStringLiteral("快照已保存：%1").arg(prefix);
        const auto json = QJsonDocument(QJsonObject{{"event", "snapshot"}, {"prefix", prefix}})
                              .toJson(QJsonDocument::Compact);
        std::printf("%s\n", json.constData());
        std::fflush(stdout);
    } catch (const std::exception& ex) {
        message_ = QString::fromUtf8(ex.what());
        if (options_.snapshotOnFinish) exitCode_ = 2;
    }
    emit changed();
}
void IceController::quitApp() {
    quitting_ = true;
    if (session_) stop();
    else QCoreApplication::exit(exitCode_);
}

void IceController::poll() {
    if (!session_) return;
    auto& session = *session_;
    // Snapshot completion BEFORE consuming the mailbox. If a worker completes
    // after this point, drain its final observation on the next poll before join.
    const bool workersFinished = session.captureDone.load() && session.detectionDone.load();
    const auto now = monotonicMs();
    if (!rateStartedMs_ && session.captured > 0) {
        rateStartedMs_ = now;
        rateCaptured_ = session.captured;
        rateProcessed_ = session.processed;
    } else if (rateStartedMs_ && now - rateStartedMs_ >= 1000) {
        const auto captured = session.captured.load();
        const auto processed = session.processed.load();
        const auto elapsed = double(now - rateStartedMs_) / 1000.;
        captureFps_ = double(captured - rateCaptured_) / elapsed;
        detectFps_ = double(processed - rateProcessed_) / elapsed;
        rateStartedMs_ = now;
        rateCaptured_ = captured;
        rateProcessed_ = processed;
    }
    const auto error = session.failure();
    if (!error.isEmpty()) {
        exitCode_ = 2;
        statusText_ = error.section(" (", 0, 0).left(150);
        message_ = error.simplified();
        statusColor_ = "#EF4444";
        clearObservation();
        infoText_.clear();
    } else if (auto frame = session.completed.take()) {
        if (!explicitStop_ && frame->session == generation_ && frame->sequence > lastSequence_) {
            lastSequence_ = frame->sequence;
            stale_ = false;
            statusText_ = resultText(*frame);
            statusColor_ = resultColor(*frame);
            if (frame->status) exitCode_ = 2;
            infoText_ = QStringLiteral("%1×%2  采集 %3 fps  检测 %4 fps  NPU %5 ms\n算法调用 %6 ms  报警阈值 %7%  帧 %8")
                .arg(frame->image.width()).arg(frame->image.height())
                .arg(captureFps_ < 0 ? QStringLiteral("--") : QString::number(captureFps_, 'f', 1))
                .arg(detectFps_ < 0 ? QStringLiteral("--") : QString::number(detectFps_, 'f', 1))
                .arg(frame->result.inference_time_ms).arg(frame->detectMs, 0, 'f', 1)
                .arg(frame->threshold * 100, 0, 'f', 1)
                .arg(qulonglong(frame->sequence));
            if (options_.logJson) {
                const QJsonObject display{{"event", "display"},
                    {"session", QString::number(frame->session)},
                    {"frame_seq", QString::number(frame->sequence)},
                    {"camera_channel", frame->channel}, {"status", double(frame->status)}};
                std::printf("%s\n", QJsonDocument(display).toJson(QJsonDocument::Compact).constData());
                std::fflush(stdout);
            }
            { std::lock_guard<std::mutex> lock(displayMutex_); observation_ = std::move(frame); }
            emit frameChanged();
        }
    }
    const auto frame = observation();
    if (!explicitStop_ && error.isEmpty() && frame && !stale_ &&
        monotonicMs() - frame->capturedMs > 3000) {
        stale_ = true;
        statusText_ = QStringLiteral("结果已过期，等待新检测帧");
        statusColor_ = "#FBBF24";
        clearObservation();
        infoText_.clear();
    }
    if (workersFinished) {
        if (session.apiErrors > 0) exitCode_ = 2;
        if (options_.snapshotOnFinish && error.isEmpty() && !explicitStop_) snapshot();
        const QJsonObject summary{{"event", "session_finished"}, {"camera_channel", options_.channel},
            {"captured", double(session.captured)}, {"processed", double(session.processed)},
            {"api_errors", double(session.apiErrors)},
            {"error", error}, {"exit_code", exitCode_}};
        std::printf("%s\n", QJsonDocument(summary).toJson(QJsonDocument::Compact).constData());
        std::fflush(stdout);
        session_.reset(); // Both workers have completed; joins do not wait for capture/inference.
        if (error.isEmpty()) {
            statusText_ = explicitStop_ ? QStringLiteral("已停止") : QStringLiteral("检测已完成");
            statusColor_ = "#8AA0B8";
        }
        emit changed();
        emit finished();
        if (quitting_) QCoreApplication::exit(exitCode_);
        return;
    }
    emit changed();
}

IceView::IceView(QQuickItem* parent) : QQuickPaintedItem(parent) { setAntialiasing(true); }
void IceView::setController(IceController* controller) {
    if (controller_ == controller) return;
    QObject::disconnect(updateConnection_);
    controller_ = controller;
    if (controller_) updateConnection_ = connect(controller_, &IceController::frameChanged,
        this, [this] { update(); });
    emit controllerChanged();
    update();
}
void IceView::paint(QPainter* painter) {
    painter->fillRect(boundingRect(), QColor("#0E1726"));
    if (controller_) {
        if (const auto frame = controller_->observation())
            paintObservation(*painter, boundingRect(), *frame);
    }
}
} // namespace ice_ui
