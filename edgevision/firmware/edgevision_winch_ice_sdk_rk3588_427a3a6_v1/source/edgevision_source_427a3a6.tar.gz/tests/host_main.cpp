/* ============================================================================
 * host_main.cpp  —  宿主侧：异步缓冲回调 demo（方案一，推荐）
 *
 * 完整 zlog 落盘版见 docs/算法库日志接入说明.docx。本目标在无 zlog 时用
 * stderr 代替，验证「回调只入队、worker 落盘」链路。
 *
 * 编译：见 CMake 目标 evs_host_log_async
 * ==========================================================================*/
#include "evs/alg_api.h"

#include <cstdio>
#include <cstring>
#include <mutex>
#include <queue>
#include <thread>

#define QUEUE_MAX 1024 /* 队列上限，满时丢弃最旧 */

struct LogItem {
    int level;
    char tag[16];
    char text[1024];
};

static std::queue<LogItem> g_q;
static std::mutex g_mtx;
static bool g_exit = false;

/* 回调：算法库线程中执行，只做深拷贝入队 */
static void host_alg_log_cb(int level, const char* tag, const char* file, int line,
                            const char* msg) {
    LogItem it;
    it.level = level;
    snprintf(it.tag, sizeof(it.tag), "%s", tag ? tag : "algo");
    snprintf(it.text, sizeof(it.text), "[%s:%d] %s", file ? file : "", line, msg ? msg : "");

    std::lock_guard<std::mutex> lk(g_mtx);
    if (static_cast<int>(g_q.size()) >= QUEUE_MAX)
        g_q.pop(); /* 满丢最旧 */
    g_q.push(it);
}

/* 后台线程：批量落盘（此处用 stderr；接 zlog 时按级别映射 zlog_*） */
static void log_worker() {
    while (true) {
        LogItem it;
        {
            std::unique_lock<std::mutex> lk(g_mtx);
            if (g_q.empty()) {
                if (g_exit)
                    break;
                lk.unlock();
                std::this_thread::yield();
                continue;
            }
            it = g_q.front();
            g_q.pop();
        }
        const char* name = "INFO";
        switch (it.level) {
            case ALG_LOG_DEBUG:
                name = "DEBUG";
                break;
            case ALG_LOG_WARN:
                name = "WARN";
                break;
            case ALG_LOG_ERROR:
            case ALG_LOG_FATAL:
                name = "ERROR";
                break;
            default:
                break;
        }
        std::fprintf(stderr, "[zlog:%s][%s] %s\n", name, it.tag, it.text);
    }
}

static void algorithm_run(void) {
    alg_log_emit(ALG_LOG_INFO, "algo", __FILE__, __LINE__, "async demo frame ok");
    alg_log_emit(ALG_LOG_WARN, "algo", __FILE__, __LINE__, "async demo slow");
    alg_log_emit(ALG_LOG_ERROR, "algo", __FILE__, __LINE__, "async demo failed, retry");
}

int main() {
    std::thread worker(log_worker); /* 1. 启动落盘线程 */
    alg_init(host_alg_log_cb); /* 2. 注册异步回调 */
    algorithm_run(); /* 3. 跑算法库 demo */

    { /* 4. 正常退出：置退出标志，冲刷剩余日志后结束线程 */
        std::lock_guard<std::mutex> lk(g_mtx);
        g_exit = true;
    }
    worker.join();
    return 0;
}
