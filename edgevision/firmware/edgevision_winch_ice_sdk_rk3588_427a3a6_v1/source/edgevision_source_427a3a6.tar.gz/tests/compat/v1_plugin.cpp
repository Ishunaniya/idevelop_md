// Compiled with the frozen v1 interfaces, linked against the current core.
#include "evs/function_plugin.h"
#include <cstddef>

namespace evs {
bool register_function_plugin(uint16_t, std::unique_ptr<IFunctionPlugin> (*)());
namespace {
class LegacyPlugin final : public IFunctionPlugin {
public:
    uint16_t module_id() const override { return 0xF001; }
    uint32_t configure(const TaskConfig& c) override {
        return c.module_id == module_id() && c.input_width == 16 ? 0 : 1;
    }
    bool ground_reference(const MachineContext&, GroundReference&) const override { return false; }
    uint32_t decide(const Frame&, const MachineContext&, const std::vector<Target>&, Result& out) override {
        out.limit_state = 42;
        return 0;
    }
    void reset() override {}
};
std::unique_ptr<IFunctionPlugin> make() { return std::make_unique<LegacyPlugin>(); }
const bool registered = register_function_plugin(0xF001, make);
}
}

extern "C" std::size_t legacy_task_config_size() { return sizeof(evs::TaskConfig); }
extern "C" bool legacy_load_config(const char* path) {
    struct Guarded { evs::TaskConfig cfg; uint64_t guard = 0xC0FFEE1234567890ULL; } value;
    uint32_t error = 0;
    return evs::load_task_config(path, value.cfg, error) &&
        value.guard == 0xC0FFEE1234567890ULL && value.cfg.module_id == 0xF001 &&
        value.cfg.input_width == 16;
}
