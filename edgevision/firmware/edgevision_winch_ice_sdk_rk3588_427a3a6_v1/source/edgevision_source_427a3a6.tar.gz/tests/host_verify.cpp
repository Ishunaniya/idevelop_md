/* ============================================================================
 * host_verify.cpp  —  优化验证：宿主回调打印 + 双模块（algo/verify）区分
 * 编译：见 CMake 目标 evs_host_verify
 * ==========================================================================*/
#define ALG_MODULE "verify" /* 本文件作为一个独立模块验证 tag 区分 */
#include "evs/alg_api.h"

#include <cstdio>

/* 宿主回调：模拟收日志（真实宿主这里改为异步缓冲入队） */
static void cb(int level, const char* tag, const char* file, int line, const char* msg) {
    printf("[level=%d][%s][%s:%d] %s\n", level, tag, file, line, msg);
}

static void algorithm_run(void) {
    /* Simulate another TU tagged "algo" (host file itself uses ALG_MODULE=verify). */
    alg_log_emit(ALG_LOG_INFO, "algo", __FILE__, __LINE__, "algorithm_run demo ok");
    alg_log_emit(ALG_LOG_WARN, "algo", __FILE__, __LINE__, "algorithm_run demo warn");
}

int main() {
    alg_init(cb); /* 注册回调（algo.cpp 内部 set_cb） */
    algorithm_run(); /* 算法库模块（tag=algo）产日志 */

    ALOG_DEBUG("verify debug %d", 1);
    ALOG_INFO("verify info ok");
    ALOG_WARN("verify warn");
    printf("== verify done ==\n");
    return 0;
}
