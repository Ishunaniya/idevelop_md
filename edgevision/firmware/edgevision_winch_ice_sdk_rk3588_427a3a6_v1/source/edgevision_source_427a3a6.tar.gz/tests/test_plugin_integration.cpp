#include "evs/vision_task.h"
#include "evs/function_task_hooks.h"
#include "evs/log.h"
#include "evs_register.h"
#include "core/config_internal.h"
#include <chrono>
#include <filesystem>
#include <fstream>
#include <iostream>

extern "C" std::size_t legacy_task_config_size();
extern "C" bool legacy_load_config(const char*);

namespace {
int failures = 0;
void check(bool ok, const char* message) {
    if (!ok) { ++failures; std::cerr << message << '\n'; }
}
class ModernPlugin final : public evs::IFunctionPlugin, public evs::IFunctionTaskHooks {
    int threshold_ = 50;
public:
    uint16_t module_id() const override { return 0xF002; }
    uint32_t configure(const evs::TaskConfig&) override { return 1; } // hooks must be used
    uint32_t validate_task(const evs::TaskConfig&) const override { return 0; }
    uint32_t configure_task(const evs::TaskConfig&, const evs::FunctionOptions& options) override {
        const auto it = options.find("probe_threshold");
        threshold_ = it == options.end() ? 50 : std::stoi(it->second);
        return 0;
    }
    bool require_warmup_success() const noexcept override { return true; }
    void reject_frame(uint32_t status, evs::Result& out) noexcept override {
        out = evs::Result{}; out.status = status; out.limit_state = 99;
    }
    uint32_t decide(const evs::Frame&, const evs::MachineContext&, const std::vector<evs::Target>&,
                    evs::Result& out) override { out.limit_state = threshold_; return 0; }
    void reset() override {}
};
std::unique_ptr<evs::IFunctionPlugin> make() { return std::make_unique<ModernPlugin>(); }
uint32_t options(const evs::detail::ConfigDocument& document, evs::TaskConfig&, evs::FunctionOptions& out) {
    for (const auto& n : document.nodes) {
        if (n.key != "probe_threshold") continue;
        if (n.value != "73" && n.value != "74") return uint32_t(evs::EvsStatus::ConfigParse);
        out[n.key] = n.value;
    }
    return 0;
}
const evs::FunctionPluginRegistration plugin(0xF002, make);
const evs::FunctionConfigRegistration config(0xF002, options);
}

int main() {
    using namespace evs;
    Logger::instance().set_level(LogLevel::Off);
    check(legacy_task_config_size() == sizeof(TaskConfig), "v1 TaskConfig layout changed");
    check(!create_function_plugin(8), "ice was unexpectedly linked into an independent host");
    const auto path = std::filesystem::temp_directory_path() /
        ("evs_plugin_abi_" + std::to_string(std::chrono::steady_clock::now().time_since_epoch().count()) + ".yaml");
    auto write = [&](uint16_t module, const char* value) {
        std::ofstream file(path);
        file << "module_id: " << module << "\nbackend: mock\nModel_path: integration\n"
             << "video_channel: [0]\ninput_width: 16\ninput_height: 16\n"
             << "ground:\n  enabled: false\n";
        if (value) file << "probe_threshold: " << value << '\n';
    };
    write(0xF001, nullptr);
    check(legacy_load_config(path.c_str()), "v1 caller could not load config safely");
    Frame frame; std::vector<uint8_t> pixels(16 * 16 * 3, 60);
    frame.data = pixels.data(); frame.width = frame.height = 16;
    frame.camera_id = 0; frame.format = PixelFormat::RGB;
    MachineContext ctx; Result out;
    VisionTask old;
    check(old.initialize(path.string()) == 0, "v1 plugin initialize failed");
    auto* old_plugin = old.functionPlugin();
    GroundReference reference;
    check(old_plugin && !old_plugin->ground_reference(ctx, reference), "v1 virtual dispatch failed");
    check(old.detect(frame, ctx, out) == 0 && out.limit_state == 42, "v1 decide dispatch failed");
    old.release();

    write(0xF002, "73");
    VisionTask modern;
    check(modern.initialize(path.string()) == 0, "independent extended plugin failed");
    check(modern.detect(frame, ctx, out) == 0 && out.limit_state == 73, "instance options lost");
    write(0xF002, "bad");
    check(modern.updateConfig(path.string()) != 0, "invalid plugin options accepted");
    check(modern.detect(frame, ctx, out) == 0 && out.limit_state == 73, "rejected update changed policy");
    write(0xF002, "74");
    check(modern.updateConfig(path.string()) == 0, "valid plugin update rejected");
    check(modern.detect(frame, ctx, out) == 0 && out.limit_state == 74, "updated options not used");
    frame.camera_id = 1;
    check(modern.detect(frame, ctx, out) != 0 && out.limit_state == 99 && out.status != 0,
          "optional rejected-frame hook not called");
    std::filesystem::remove(path);
    std::cout << "PLUGIN ABI/EXTENSION FAIL=" << failures << '\n';
    return failures ? 1 : 0;
}
