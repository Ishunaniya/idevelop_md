/* ============================================================================
 * algo.cpp  —  算法库侧统一日志实现（对应规范中的 alog.c）
 *
 * 用法见 evs/alog.h / src/core/algo.h。
 * 回调未注册时 emit 直接返回：不格式化、不调用，零开销。
 * ==========================================================================*/
#include "evs/alog.h"

#include <cstdarg>
#include <cstdio>

static alg_log_cb g_cb = nullptr;

extern "C" void alg_log_set_cb(alg_log_cb cb) {
    g_cb = cb;
}

extern "C" void alg_log_set_default_cb(alg_log_cb cb) {
    if (!g_cb)
        g_cb = cb;
}

extern "C" int alg_log_has_cb(void) {
    return g_cb != nullptr ? 1 : 0;
}

extern "C" int alg_init(alg_log_cb log_cb) {
    alg_log_set_cb(log_cb);
    return 0;
}

extern "C" void alg_log_emit(int level, const char* tag, const char* file, int line,
                             const char* fmt, ...) {
    if (!g_cb) /* 回调未注册：不格式化，零开销 */
        return;

    char buf[1024];
    va_list ap;
    va_start(ap, fmt);
    vsnprintf(buf, sizeof(buf), fmt, ap);
    va_end(ap);

    g_cb(level, tag, file, line, buf);
}
