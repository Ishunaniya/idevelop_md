#include "evs/backend_factory.h"
#include "backend_contract.h"

#if defined(EVS_BACKEND_MOCK)
#include "evs/mock_backend.h"
#endif
#if defined(EVS_BACKEND_RKNN)
#include "evs/rknn_backend.h"
#endif
#if defined(EVS_BACKEND_X86)
#include "evs/x86_backend.h"
#endif
#if defined(EVS_BACKEND_ONNX)
#include "evs/x86_backend.h" // ONNX builds reuse the x86 backend (ORT path)
#endif

namespace evs {

std::shared_ptr<IInferBackend> create_backend(const std::string& type) {
#if defined(EVS_BACKEND_MOCK)
    if (type == "mock" || type.empty()) return std::make_shared<MockBackend>();
#endif
#if defined(EVS_BACKEND_RKNN)
    if (type == "rknn") return std::make_shared<RknnBackend>();
#endif
#if defined(EVS_BACKEND_X86)
    if (type == "x86") return std::make_shared<X86Backend>();
#endif
#if defined(EVS_BACKEND_ONNX)
    // "onnx" and "x86" are the same translation unit; the AND build aliases both
    // so task YAMLs stay portable between the reference and ORT configurations.
    if (type == "onnx" || type == "x86") return std::make_shared<X86Backend>();
#endif
    // qnn backend is compiled only with its SDK present (EVS_BACKEND=qnn).
    (void)type;
    return nullptr;
}

namespace detail {
namespace {
#if defined(EVS_BACKEND_RKNN)
bool explicit_detection_rows(const TaskConfig& cfg) {
    // Preserve the established COCO head path. Custom class counts require
    // explicit single-output parsing instead of silently assuming 80 classes.
    return cfg.backend == "rknn" && cfg.decoder_classes != 80 &&
        (cfg.output_format == "flat6" || cfg.output_format == "yolov8" ||
         cfg.output_format == "yolox");
}
#endif
}

uint32_t validate_backend_contract(IInferBackend& backend, const TaskConfig& cfg) {
#if defined(EVS_BACKEND_RKNN)
    if (explicit_detection_rows(cfg)) {
        auto* rknn = dynamic_cast<RknnBackend*>(&backend);
        if (!rknn) return uint32_t(EvsStatus::NotSupported);
        return rknn->validateDetectionModel(cfg.output_format, cfg.decoder_classes,
                                           cfg.input_width, cfg.input_height);
    }
#else
    (void)backend; (void)cfg;
#endif
    return 0;
}

uint32_t infer_backend_contract(IInferBackend& backend, const TaskConfig& cfg,
                                const std::vector<uint8_t>& input, std::vector<float>& output) {
#if defined(EVS_BACKEND_RKNN)
    if (explicit_detection_rows(cfg)) {
        auto* rknn = dynamic_cast<RknnBackend*>(&backend);
        if (!rknn) return uint32_t(EvsStatus::NotSupported);
        return rknn->inferDetectionRows(input, output, cfg.output_format, cfg.decoder_classes,
                                       cfg.input_width, cfg.input_height);
    }
#else
    (void)cfg;
#endif
    return backend.infer(input, output);
}
} // namespace detail

} // namespace evs
