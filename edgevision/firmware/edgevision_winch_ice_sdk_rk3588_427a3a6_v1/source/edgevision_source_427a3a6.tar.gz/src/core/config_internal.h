#pragma once
#include "evs/task_config.h"
#include "evs/function_task_hooks.h"

namespace evs {
namespace detail {
struct ConfigNode {
    int indent;
    std::string key;
    std::string value;
    bool list_start;
};

struct ConfigDocument {
    std::string path;
    std::vector<ConfigNode> nodes;
    bool syntax_error = false;
};

using FunctionConfigLoader = uint32_t (*)(const ConfigDocument&, TaskConfig&, FunctionOptions&);
bool register_function_config_loader(uint16_t module, FunctionConfigLoader);
FunctionConfigLoader function_config_loader(uint16_t module);

// Internal diagnostic metadata; the public loader keeps bare parser errors.
bool load_task_config_with_module(std::string_view path, TaskConfig& cfg, uint32_t& err,
                                  uint16_t& parsed_module, FunctionOptions* options = nullptr);
} // namespace detail

// A function library may validate/normalize its own file settings at load time.
// The loader returns instance settings; it never stores them in global state.
struct FunctionConfigRegistration {
    FunctionConfigRegistration(uint16_t module, detail::FunctionConfigLoader loader) {
        detail::register_function_config_loader(module, loader);
    }
};

} // namespace evs
