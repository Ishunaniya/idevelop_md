#pragma once
#include "evs/iinfer_backend.h"
#include "evs/task_config.h"

namespace evs::detail {
// Backend dispatch is selected by the model contract, never a function id.
uint32_t validate_backend_contract(IInferBackend&, const TaskConfig&);
uint32_t infer_backend_contract(IInferBackend&, const TaskConfig&,
                                const std::vector<uint8_t>&, std::vector<float>&);
} // namespace evs::detail
