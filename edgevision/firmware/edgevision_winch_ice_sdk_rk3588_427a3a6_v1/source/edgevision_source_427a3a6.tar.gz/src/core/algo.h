/* Compatibility path named in the logging integration note.
 * Prefer #include "evs/alog.h" from new code. */
#pragma once
#include "evs/alog.h"
