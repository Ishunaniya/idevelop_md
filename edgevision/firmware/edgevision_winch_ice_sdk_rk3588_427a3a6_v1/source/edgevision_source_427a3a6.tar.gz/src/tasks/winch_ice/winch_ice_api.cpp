#define ALG_MODULE "winch_ice"
#include "evs/log.h"
#include "evs/testing/ice_replay.h"
#include "evs/vision_task.h"
#include "evs/winch_ice.h"
#include "ice_measurement.h"
#include "winch_ice_plugin.h"
#include "core/config_internal.h"
#include <cstdlib>
#include <exception>
#include <new>

namespace evs {
namespace winch_ice {
namespace {
uint32_t ice_status(EvsStatus s) {
    return with_module(0x0008, static_cast<uint32_t>(s));
}

TaskConfig make_task_config(const WinchSnowConfig& config) {
    TaskConfig task_config;
    task_config.task = "winch_ice";
    task_config.module_id = 0x0008;
    task_config.video_channel = {static_cast<int>(config.camera_channel)};
    task_config.ground.enabled = false;
    task_config.backend = "rknn";
    task_config.output_format = "yolox";
    task_config.decoder_classes = 1;
    task_config.person_class_id = 0;
    task_config.input_format = "rgb";
    task_config.letterbox = true;
    task_config.Model_path = config.model_config.Model_path;
    task_config.input_width = config.model_config.input_width;
    task_config.input_height = config.model_config.input_height;
    task_config.warmup = config.model_config.warmup;
    task_config.area_ratio = config.detect_config.area_ratio;
    task_config.confidence_threshold = config.detect_config.confidence_threshold;
    task_config.nms_threshold = config.detect_config.nms_threshold;
    return task_config;
}

bool valid_public_config(const WinchSnowConfig& config) {
    return config.camera_channel < 255;
}

} // namespace

struct Detector::Impl {
    VisionTask task;
    WinchIcePlugin* plugin = nullptr; // borrowed from task, never a second instance
    WinchSnowConfig cfg;
    bool initialized = false;

    uint32_t reject(uint32_t status, WinchSnowResult& result) noexcept {
        Result generic;
        if (plugin) plugin->reject_call(status, generic);
        result = WinchSnowResult{};
        result.camera_channel = cfg.camera_channel;
        return status;
    }

    uint32_t detect(const ImageData& image, WinchSnowResult& result) {
        if (!initialized) {
            EVS_LOGE("detect rejected: detector is not initialized");
            return reject(ice_status(EvsStatus::NotInitialized), result);
        }
        Frame frame;
        std::vector<uint8_t> gray_rgb;
        if (const auto rc = detail::make_frame(image, cfg.camera_channel, frame, gray_rgb)) {
            EVS_LOGE("detect rejected: image conversion/validation failed status=0x%08X size=%ux%u channels=%u",
                     rc, image.width, image.height, image.channels);
            return reject(rc, result);
        }
        MachineContext context;
        // The generic task interface still serves modules that need context.
        // Ice ignores it: the host has already decided to inspect this image.
        Result generic;
        const auto previous_frames = task.debugStats().frames;
        const auto rc = task.detect(frame, context, generic);
        const auto* current = plugin ? plugin->winch_result() : nullptr;
        if (!current) {
            EVS_LOGE("detect failed: plugin did not publish a winch result");
            return reject(ice_status(EvsStatus::PostprocessFailed), result);
        }
        result = *current;
        if (task.debugStats().frames != previous_frames)
            result.inference_time_ms = static_cast<uint32_t>(task.debugStats().infer.last_ms + .5);
        return rc;
    }
};

Detector::Detector() : impl_(std::make_unique<Impl>()) {
}

Detector::~Detector() = default;

ErrorCode Detector::initialize(const WinchSnowConfig& config) {
    try {
        if (impl_->initialized) {
            EVS_LOGW("initialize ignored: detector is already initialized");
            return 0u;
        }
        if (!valid_public_config(config)) {
            EVS_LOGE("initialize rejected: invalid public config camera=%u", config.camera_channel);
            return ice_status(EvsStatus::ConfigInvalid);
        }
        auto next = config;
        if (const auto rc = impl_->task.initialize(make_task_config(next)))
            return rc;
        impl_->plugin = dynamic_cast<WinchIcePlugin*>(impl_->task.functionPlugin());
        if (!impl_->plugin) {
            EVS_LOGE("initialize failed: registered function plugin is not WinchIcePlugin");
            release();
            return ice_status(EvsStatus::NotSupported);
        }
        impl_->cfg = std::move(next);
        impl_->initialized = true;
        return 0u;
    } catch (const std::bad_alloc&) {
        EVS_LOGE("initialize failed: memory allocation");
        release();
        return ice_status(EvsStatus::MemoryAllocation);
    }
}

ErrorCode Detector::detect(const ImageData& image, WinchSnowResult& result) {
    try {
        return impl_->detect(image, result);
    } catch (const std::bad_alloc&) {
        EVS_LOGE("detect failed: memory allocation");
        return impl_->reject(ice_status(EvsStatus::MemoryAllocation), result);
    } catch (const std::exception& ex) {
        EVS_LOGE("detect failed with exception: %s", ex.what());
        return impl_->reject(ice_status(EvsStatus::PostprocessFailed), result);
    }
}

ErrorCode Detector::updateConfig(const DetectConfig& config) {
    if (!impl_->initialized) {
        EVS_LOGE("updateConfig rejected: detector is not initialized");
        return ice_status(EvsStatus::NotInitialized);
    }
    try {
        auto next = impl_->cfg;
        next.detect_config = config;
        const auto rc = impl_->task.updateConfig(make_task_config(next));
        if (!rc)
            impl_->cfg = std::move(next);
        return rc;
    } catch (const std::bad_alloc&) {
        EVS_LOGE("updateConfig failed: memory allocation");
        return ice_status(EvsStatus::MemoryAllocation);
    }
}

void Detector::release() {
    impl_->plugin = nullptr;
    impl_->task.release();
    impl_->initialized = false;
}

ErrorCode load_config(const std::string& path, WinchSnowConfig& out) {
    try {
        TaskConfig t = make_task_config(WinchSnowConfig{});
        uint32_t rc = 0;
        FunctionOptions options;
        uint16_t module = t.module_id;
        if (!evs::detail::load_task_config_with_module(path, t, rc, module, &options)) {
            EVS_LOGE("load_config failed: path=%s status=0x%08X", path.c_str(), rc);
            return with_module(0x0008, rc);
        }
        if (t.module_id != 8 || t.video_channel.size() != 1 || t.video_channel[0] < 0 ||
            t.ground.enabled || t.backend != "rknn" || t.output_format != "yolox" ||
            t.decoder_classes != 1 || t.person_class_id != 0 || t.input_format != "rgb" ||
            !t.letterbox ||
            (options.count("ice_saturation_max") && std::atoi(options.at("ice_saturation_max").c_str()) != 80) ||
            (options.count("ice_value_min") && std::atoi(options.at("ice_value_min").c_str()) != 180)) {
            EVS_LOGE("load_config rejected incompatible ice task: module=%u channels=%zu backend=%s format=%s classes=%d class_id=%d input_format=%s letterbox=%d",
                     t.module_id, t.video_channel.size(), t.backend.c_str(), t.output_format.c_str(),
                     t.decoder_classes, t.person_class_id, t.input_format.c_str(), t.letterbox);
            return ice_status(EvsStatus::ConfigInvalid);
        }
        WinchSnowConfig c;
        c.camera_channel = static_cast<uint32_t>(t.video_channel[0]);
        c.detect_config.area_ratio = t.area_ratio;
        c.detect_config.confidence_threshold = t.confidence_threshold;
        c.detect_config.nms_threshold = t.nms_threshold;
        c.model_config.Model_path = t.Model_path;
        c.model_config.input_width = t.input_width;
        c.model_config.input_height = t.input_height;
        c.model_config.warmup = t.warmup;
        if (!valid_public_config(c)) {
            EVS_LOGE("load_config rejected invalid public config camera=%u", c.camera_channel);
            return ice_status(EvsStatus::ConfigInvalid);
        }
        out = std::move(c);
        EVS_LOGI("configuration loaded: path=%s model=%s camera=%u area_ratio=%.4f confidence=%.4f nms=%.4f",
                 path.c_str(), out.model_config.Model_path.c_str(), out.camera_channel,
                 out.detect_config.area_ratio, out.detect_config.confidence_threshold,
                 out.detect_config.nms_threshold);
        return 0u;
    } catch (const std::bad_alloc&) {
        EVS_LOGE("load_config failed: memory allocation path=%s", path.c_str());
        return ice_status(EvsStatus::MemoryAllocation);
    } catch (const std::exception& ex) {
        EVS_LOGE("load_config failed with exception: path=%s error=%s", path.c_str(), ex.what());
        return ice_status(EvsStatus::ConfigParse);
    }
}
} // namespace winch_ice

namespace testing {
bool IceReplayAccess::copyMasks(const winch_ice::Detector& d, std::vector<IceMaskSnapshot>& out) {
    out.clear();
    return d.impl_->plugin && d.impl_->plugin->copy_ice_masks(out);
}
} // namespace testing
} // namespace evs
