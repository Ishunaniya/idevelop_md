#pragma once
#include "evs/function_plugin.h"
#include "evs/function_task_hooks.h"
#include "evs/winch_ice.h"
#include "ice_measurement.h"
#include <cstdint>

namespace evs {
namespace testing { struct IceMaskSnapshot; }
class WinchIcePlugin : public IFunctionPlugin, public IFunctionTaskHooks,
                       public IUnfilteredDetectionInput {
public:
    uint16_t module_id() const override { return 0x0008; }

    uint32_t configure(const TaskConfig&) override;
    void reject_call(uint32_t status, Result& out) noexcept;
    uint32_t decide(const Frame&, const MachineContext&, const std::vector<Target>&,
                    Result&) override;

    const winch_ice::WinchSnowResult* winch_result() const { return &report_; }

    bool copy_ice_masks(std::vector<testing::IceMaskSnapshot>&) const;
    void reset() override;

    uint32_t validate_task(const TaskConfig&) const override;
    uint32_t configure_task(const TaskConfig&, const FunctionOptions&) override;
    bool require_warmup_success() const noexcept override { return true; }
    void reject_frame(uint32_t status, Result& out) noexcept override;


private:
    struct FrameLogWindow {
        uint64_t frames = 0;
        uint64_t inputs = 0, clipped_empty = 0, other_class = 0, zero_area = 0;
        uint64_t zero_score = 0, below_threshold = 0, selected = 0, nms_suppressed = 0;
        uint64_t candidates = 0, measured = 0, unobservable = 0, measurement_errors = 0;
        uint64_t too_small = 0, overlapping = 0, alert_frames = 0;
    };
    void summarize() noexcept;
    void publish(Result&, uint32_t status = 0) noexcept;
    TaskConfig cfg_;
    IceConfig ice_;
    winch_ice::WinchSnowResult report_;
    bool configured_ = false;
    uint32_t measurement_timestamp_ms_ = 0;
    uint64_t frame_log_counter_ = 0;
    FrameLogWindow frame_log_window_;
#if defined(EVS_WITH_OPENCV)
    std::vector<IceMeasurement> measurements_;
#endif
};
} // namespace evs
