#define ALG_MODULE "winch_ice"
#include "evs/log.h"
#include "winch_ice_plugin.h"
#include "evs/status.h"
#include "evs/testing/ice_replay.h"
#include "evs_register.h"
#include "core/config_internal.h"
#include <algorithm>
#include <cmath>
#include <cstdlib>
#include <cerrno>
#include <filesystem>
#include <limits>
#include <map>
#include <set>
#include <sstream>

namespace evs {
using namespace winch_ice;

namespace {
std::string trim_ice(const std::string& s) {
    const auto a = s.find_first_not_of(" \t\r\n");
    if (a == std::string::npos) return {};
    return s.substr(a, s.find_last_not_of(" \t\r\n") - a + 1);
}
uint32_t load_ice_options(const evs::detail::ConfigDocument& document, TaskConfig& cfg,
                          FunctionOptions& options) {
    bool ice_error = document.syntax_error;
    if (document.syntax_error)
        EVS_LOGE("ice task config syntax error: path=%s", document.path.c_str());
    const auto& nodes = document.nodes;
    std::set<std::string> seen;
    std::map<std::string, std::string> aliases;
    const std::set<std::string> ice_keys{"ice_mode", "ice_saturation_max", "ice_value_min"};
    const std::set<std::string> model_keys{
        "module_id", "video_channel", "backend", "input_width", "input_height",
        "input_format", "letterbox", "warmup", "output_format", "decoder_classes",
        "winch_class_id", "confidence_threshold", "nms_threshold"};
    auto integer = [](const std::string& value, int base = 10) {
        char* end = nullptr;
        errno = 0;
        const long n = std::strtol(value.c_str(), &end, base);
        return !errno && end != value.c_str() && *end == '\0' &&
               n >= std::numeric_limits<int>::min() && n <= std::numeric_limits<int>::max();
    };
    for (const auto& n : nodes) {
        const auto key = n.key == "person_class_id" ? "winch_class_id"
                         : n.key == "camera_ids" ? "video_channel"
                         : n.key == "score_threshold" || n.key == "score"
                             ? "confidence_threshold" : n.key;
        if (n.key.rfind("ice_", 0) == 0 && !ice_keys.count(n.key)) {
            EVS_LOGE("unknown ice config key: %s", n.key.c_str());
            ice_error = true;
        }
        if ((ice_keys.count(key) || model_keys.count(key) || key == "inference_enabled" ||
             key == "area_ratio" || key == "exit_on_alarm") && !seen.insert(key).second) {
            EVS_LOGE("duplicate ice config key or alias: key=%s normalized=%s",
                     n.key.c_str(), key.c_str());
            ice_error = true;
        }
        if ((key == "letterbox" || key == "warmup") &&
            n.value != "true" && n.value != "True" && n.value != "1" &&
            n.value != "false" && n.value != "False" && n.value != "0") {
            EVS_LOGE("invalid boolean config: key=%s value=%s", n.key.c_str(), n.value.c_str());
            ice_error = true;
        }
        if (n.key == "ice_mode" && n.value != "model") {
            EVS_LOGE("unsupported ice_mode: value=%s", n.value.c_str());
            ice_error = true;
        }
        if (n.key == "inference_enabled" && n.value != "true") {
            EVS_LOGE("ice task requires inference_enabled=true, got %s", n.value.c_str());
            ice_error = true;
        }
        if (n.key == "exit_on_alarm" && n.value != "true" && n.value != "false") {
            EVS_LOGE("invalid boolean config: key=%s value=%s", n.key.c_str(), n.value.c_str());
            ice_error = true;
        }
        if (n.key == "module_id" && (!integer(n.value, 0) || n.value.front() == '-' ||
            std::strtoul(n.value.c_str(), nullptr, 0) > 65535)) {
            EVS_LOGE("invalid module_id: value=%s", n.value.c_str());
            ice_error = true;
        }
        if ((n.key == "ice_saturation_max" || n.key == "ice_value_min" ||
             n.key == "input_width" || n.key == "input_height" ||
             n.key == "decoder_classes" || key == "winch_class_id") && !integer(n.value)) {
            EVS_LOGE("invalid integer config: key=%s value=%s", n.key.c_str(), n.value.c_str());
            ice_error = true;
        }
        if (n.key == "model" || n.key == "Model_path") {
            const auto inserted = aliases.emplace("model", n.value);
            if (n.value.empty() || (!inserted.second && inserted.first->second != n.value)) {
                EVS_LOGE("conflicting or empty model path: key=%s value=%s",
                         n.key.c_str(), n.value.c_str());
                ice_error = true;
            }
        }
        if (n.key == "video_channel" || n.key == "camera_ids") {
            if (n.value.size() < 3 || n.value.front() != '[' || n.value.back() != ']' ||
                n.value[n.value.size() - 2] == ',') {
                EVS_LOGE("invalid camera list: key=%s value=%s", n.key.c_str(), n.value.c_str());
                ice_error = true;
            }
            else {
                std::istringstream items(n.value.substr(1, n.value.size() - 2));
                std::string item;
                while (std::getline(items, item, ',')) {
                    if (!integer(trim_ice(item))) {
                        EVS_LOGE("invalid camera id: key=%s value=%s", n.key.c_str(), item.c_str());
                        ice_error = true;
                    }
                }
            }
        }
        if (n.key == "area_ratio" || n.key == "confidence_threshold" ||
            n.key == "score_threshold" || n.key == "score" || n.key == "nms_threshold") {
            char* end = nullptr;
            errno = 0;
            const float value = std::strtof(n.value.c_str(), &end);
            if (errno || end == n.value.c_str() || *end != '\0' || !std::isfinite(value)) {
                EVS_LOGE("invalid numeric config: key=%s value=%s", n.key.c_str(), n.value.c_str());
                ice_error = true;
            }
        }
    }

    if (ice_error) return uint32_t(EvsStatus::ConfigParse);
    std::set<std::string> present;
    for (const auto& n : nodes) {
        present.insert(n.key);
        if (n.key == "winch_class_id") cfg.person_class_id = std::atoi(n.value.c_str());
        if (n.key == "ice_saturation_max" || n.key == "ice_value_min")
            options[n.key] = n.value;
    }
    // Defaults and path semantics belong to this function library. The common
    // parser neither knows these keys nor changes other functions' defaults.
    if (!present.count("backend")) cfg.backend = "rknn";
    if (!present.count("output_format")) cfg.output_format = "yolox";
    if (!present.count("decoder_classes")) cfg.decoder_classes = 1;
    if (!present.count("person_class_id") && !present.count("winch_class_id")) cfg.person_class_id = 0;
    if (!present.count("area_ratio")) cfg.area_ratio = .5f;
    if (!cfg.ground.explicitly_configured) {
        cfg.ground.enabled = false;
        cfg.ground.cameras.clear();
    }
    auto model = std::filesystem::path(cfg.Model_path);
    if (!model.empty() && model.is_relative())
        model = std::filesystem::absolute(std::filesystem::path(document.path)).parent_path() / model;
    cfg.Model_path = model.lexically_normal().string();
    return 0;
}

uint32_t ice_status(EvsStatus s) {
    return with_module(8, static_cast<uint32_t>(s));
}

#if defined(EVS_WITH_OPENCV)
float overlap(const Target& a, const Target& b) {
    const float w = std::max(0.f, std::min(a.x + a.w / 2, b.x + b.w / 2) -
                                      std::max(a.x - a.w / 2, b.x - b.w / 2));
    const float h = std::max(0.f, std::min(a.y + a.h / 2, b.y + b.h / 2) -
                                      std::max(a.y - a.h / 2, b.y - b.h / 2));
    const float intersection = w * h;
    return intersection / (a.w * a.h + b.w * b.h - intersection);
}

Detection pixel_box(const Target& t, int w, int h) {
    // Same rounded half-open endpoints define both the denominator and the overlay.
    const int left = std::clamp(int(std::lround((t.x - t.w / 2) * w)), 0, w);
    const int top = std::clamp(int(std::lround((t.y - t.h / 2) * h)), 0, h);
    const int right = std::clamp(int(std::lround((t.x + t.w / 2) * w)), 0, w);
    const int bottom = std::clamp(int(std::lround((t.y + t.h / 2) * h)), 0, h);
    return {uint32_t(std::max(0, t.class_id)),
            t.confidence,
            uint32_t(left),
            uint32_t(top),
            uint32_t(std::max(0, right - left)),
            uint32_t(std::max(0, bottom - top))};
}

bool intersects(const Detection& a, const Detection& b) {
    return a.x < b.x + b.width && b.x < a.x + a.width && a.y < b.y + b.height &&
           b.y < a.y + a.height;
}
#endif
} // namespace

uint32_t WinchIcePlugin::validate_task(const TaskConfig& cfg) const {
    if (cfg.ground.enabled || cfg.Model_path.empty() ||
        cfg.input_width <= 0 || cfg.input_height <= 0 ||
        cfg.input_width > 8192 || cfg.input_height > 8192 ||
        cfg.decoder_classes < 1 || cfg.decoder_classes > 4096 ||
        cfg.person_class_id < 0 || cfg.person_class_id >= cfg.decoder_classes ||
        (cfg.input_format != "rgb" && cfg.input_format != "bgr")) {
        EVS_LOGE("task validation failed: ground=%d model_empty=%d input=%dx%d classes=%d class_id=%d format=%s",
                 cfg.ground.enabled, cfg.Model_path.empty(), cfg.input_width, cfg.input_height,
                 cfg.decoder_classes, cfg.person_class_id, cfg.input_format.c_str());
        return uint32_t(EvsStatus::ConfigInvalid);
    }
    if (configured_ && (cfg.input_width != cfg_.input_width || cfg.input_height != cfg_.input_height ||
        cfg.input_format != cfg_.input_format || cfg.letterbox != cfg_.letterbox)) {
        EVS_LOGW("task update rejected: input contract changed size=%dx%d->%dx%d format=%s->%s letterbox=%d->%d",
                 cfg_.input_width, cfg_.input_height, cfg.input_width, cfg.input_height,
                 cfg_.input_format.c_str(), cfg.input_format.c_str(), cfg_.letterbox, cfg.letterbox);
        return uint32_t(EvsStatus::NotSupported);
    }
    if (cfg.backend != "rknn" ||
        (cfg.output_format != "flat6" && cfg.output_format != "yolov8" && cfg.output_format != "yolox")) {
        EVS_LOGE("task validation unsupported backend=%s output_format=%s",
                 cfg.backend.c_str(), cfg.output_format.c_str());
        return uint32_t(EvsStatus::NotSupported);
    }
    return 0;
}

void WinchIcePlugin::reject_frame(uint32_t status, Result& out) noexcept {
    out = Result{};
    reject_call(status, out);
}

uint32_t WinchIcePlugin::configure(const TaskConfig& cfg) {
    return configure_task(cfg, {});
}

uint32_t WinchIcePlugin::configure_task(const TaskConfig& cfg, const FunctionOptions& options) {
    IceConfig ice;
    auto read = [&](const char* key, int& value) {
        const auto it = options.find(key);
        if (it == options.end()) return true;
        errno = 0;
        char* end = nullptr;
        const auto n = std::strtol(it->second.c_str(), &end, 10);
        if (errno || end == it->second.c_str() || *end || n < 0 || n > 255) return false;
        value = int(n);
        return true;
    };
    if (!read("ice_saturation_max", ice.saturation_max) || !read("ice_value_min", ice.value_min)) {
        EVS_LOGE("ice option parsing failed: saturation_max/value_min must be integers in [0,255]");
        return uint32_t(EvsStatus::OutOfRange);
    }

    if (!std::isfinite(cfg.confidence_threshold) || cfg.confidence_threshold < 0 ||
        cfg.confidence_threshold > 1 || !std::isfinite(cfg.nms_threshold) ||
        cfg.nms_threshold < 0 || cfg.nms_threshold > 1 || !std::isfinite(cfg.area_ratio) ||
        cfg.area_ratio < 0 || cfg.area_ratio > 1 || ice.saturation_max < 0 ||
        ice.saturation_max > 255 || ice.value_min < 0 || ice.value_min > 255) {
        EVS_LOGE("ice configuration out of range: confidence=%.6f nms=%.6f area=%.6f saturation_max=%d value_min=%d",
                 cfg.confidence_threshold, cfg.nms_threshold, cfg.area_ratio,
                 ice.saturation_max, ice.value_min);
        return static_cast<uint32_t>(EvsStatus::OutOfRange);
    }
#if !defined(EVS_WITH_OPENCV)
    EVS_LOGE("ice plugin unavailable: this build has no OpenCV support");
    return static_cast<uint32_t>(EvsStatus::NotSupported);
#else
    if (cfg.video_channel.size() != 1 || cfg.video_channel[0] < 0 ||
        cfg.video_channel[0] >= kCameraChannelUnused || cfg.ground.enabled) {
        EVS_LOGE("ice configuration invalid: channel_count=%zu channel=%d ground_enabled=%d",
                 cfg.video_channel.size(), cfg.video_channel.empty() ? -1 : cfg.video_channel[0],
                 cfg.ground.enabled);
        return static_cast<uint32_t>(EvsStatus::ConfigInvalid);
    }
    if (configured_ && cfg.video_channel != cfg_.video_channel) {
        EVS_LOGW("ice update rejected: camera channel changed from %d to %d",
                 cfg_.video_channel.empty() ? -1 : cfg_.video_channel[0], cfg.video_channel[0]);
        return static_cast<uint32_t>(EvsStatus::NotSupported);
    }
    auto next = cfg; // Allocate before committing an update.
    using std::swap;
    swap(cfg_, next);
    ice_ = ice;
    configured_ = true;
    EVS_LOGI("ice configuration applied: camera=%d area_ratio=%.4f confidence=%.4f nms=%.4f saturation_max=%d value_min=%d",
             cfg_.video_channel[0], cfg_.area_ratio, cfg_.confidence_threshold,
             cfg_.nms_threshold, ice_.saturation_max, ice_.value_min);
    return 0;
#endif
}

void WinchIcePlugin::summarize() noexcept {
    bool alarm = false;
    for (const auto& r : report_.objects) {
        alarm |= r.valid && r.ice_ratio >= cfg_.area_ratio;
    }
    report_.alert_level = alarm ? AlertLevel::ALERT_WARN : AlertLevel::ALERT_NONE;
    report_.result_code = report_.objects.empty() ? ResultCode::RESULT_NO_RESULT : ResultCode::RESULT_MATCH;
}

void WinchIcePlugin::publish(Result& out, uint32_t status) noexcept {
    summarize();
    out.status = status;
    out.ice_ratio = report_.objects.size() == 1 && report_.objects[0].valid
                        ? report_.objects[0].ice_ratio
                        : kIceRatioUnknown;
    out.alarm =
        report_.alert_level == AlertLevel::ALERT_WARN ? AlarmState::Alarm : AlarmState::None;
    out.targets.clear();
    out.camera_channel = pack_camera_channel(static_cast<uint8_t>(report_.camera_channel));
}

void WinchIcePlugin::reject_call(uint32_t status, Result& out) noexcept {
    report_ = WinchSnowResult{};
    measurement_timestamp_ms_ = 0;
    report_.camera_channel = configured_ ? uint32_t(cfg_.video_channel[0]) : 0xFFFFFFFFu;
#if defined(EVS_WITH_OPENCV)
    measurements_.clear();
#endif
    publish(out, status);
}

uint32_t WinchIcePlugin::decide(const Frame& frame, const MachineContext&,
                                const std::vector<Target>& targets, Result& out) {
    report_ = WinchSnowResult{};
    measurement_timestamp_ms_ = 0;
    report_.camera_channel = configured_ ? uint32_t(cfg_.video_channel[0]) : 0xFFFFFFFFu;
#if defined(EVS_WITH_OPENCV)
    measurements_.clear();
#endif
    if (!configured_) {
        EVS_LOGE("frame rejected: plugin is not configured");
        publish(out, ice_status(EvsStatus::NotInitialized));
        return out.status;
    }
    if (frame.camera_id != cfg_.video_channel[0]) {
        EVS_LOGW("frame rejected: camera mismatch actual=%d configured=%d",
                 frame.camera_id, cfg_.video_channel[0]);
        publish(out, ice_status(EvsStatus::InvalidCameraIndex));
        return out.status;
    }
#if !defined(EVS_WITH_OPENCV)
    (void)targets;
    EVS_LOGE("frame rejected: OpenCV support is not compiled in");
    publish(out, ice_status(EvsStatus::NotSupported));
    return out.status;
#else
    auto fail = [&](EvsStatus status) {
        reject_call(ice_status(status), out);
        return out.status;
    };
    // Model coordinates have already been mapped back. Clip here because the
    // rectangle is the ice measurement surface, not a generic task policy.
    std::vector<Target> selected;
    size_t clipped_empty = 0, other_class = 0, zero_area_boxes = 0;
    size_t zero_score = 0, below_threshold = 0;
    size_t nms_suppressed = 0, too_small = 0, overlapping = 0;
    size_t measured = 0, unobservable = 0, other_measurement_errors = 0;
    auto log_frame_summary = [&]() {
        const float ratio0 = !report_.objects.empty() && report_.objects[0].valid
                                 ? report_.objects[0].ice_ratio : -1.f;
        const float ratio1 = report_.objects.size() > 1 && report_.objects[1].valid
                                 ? report_.objects[1].ice_ratio : -1.f;
        const auto sequence = ++frame_log_counter_;
        auto& window = frame_log_window_;
        ++window.frames;
        window.inputs += targets.size();
        window.clipped_empty += clipped_empty;
        window.other_class += other_class;
        window.zero_area += zero_area_boxes;
        window.zero_score += zero_score;
        window.below_threshold += below_threshold;
        window.selected += selected.size();
        window.nms_suppressed += nms_suppressed;
        window.candidates += report_.snow_detections.size();
        window.measured += measured;
        window.unobservable += unobservable;
        window.measurement_errors += other_measurement_errors;
        window.too_small += too_small;
        window.overlapping += overlapping;
        window.alert_frames += report_.alert_level == AlertLevel::ALERT_WARN;
        if (sequence == 1 || sequence % 100 == 0) {
            EVS_LOGI("frame window: frames=%llu last_frame=%llu inputs=%llu clipped_empty=%llu other_class=%llu zero_area=%llu zero_score=%llu below_threshold=%llu selected=%llu nms_suppressed=%llu candidates=%llu measured=%llu unobservable=%llu measurement_errors=%llu too_small=%llu overlapping=%llu alert_frames=%llu last_camera=%d format=%d ratio0=%.4f ratio1=%.4f area_threshold=%.4f last_alert=%d last_result=%d",
                     static_cast<unsigned long long>(window.frames),
                     static_cast<unsigned long long>(sequence),
                     static_cast<unsigned long long>(window.inputs),
                     static_cast<unsigned long long>(window.clipped_empty),
                     static_cast<unsigned long long>(window.other_class),
                     static_cast<unsigned long long>(window.zero_area),
                     static_cast<unsigned long long>(window.zero_score),
                     static_cast<unsigned long long>(window.below_threshold),
                     static_cast<unsigned long long>(window.selected),
                     static_cast<unsigned long long>(window.nms_suppressed),
                     static_cast<unsigned long long>(window.candidates),
                     static_cast<unsigned long long>(window.measured),
                     static_cast<unsigned long long>(window.unobservable),
                     static_cast<unsigned long long>(window.measurement_errors),
                     static_cast<unsigned long long>(window.too_small),
                     static_cast<unsigned long long>(window.overlapping),
                     static_cast<unsigned long long>(window.alert_frames), frame.camera_id,
                     static_cast<int>(frame.format), ratio0, ratio1, cfg_.area_ratio,
                     static_cast<int>(report_.alert_level),
                     static_cast<int>(report_.result_code));
            window = FrameLogWindow{};
        } else {
            EVS_LOGD("frame=%llu camera=%d format=%d input=%zu clipped_empty=%zu other_class=%zu zero_area=%zu zero_score=%zu below_threshold=%zu selected=%zu nms_suppressed=%zu candidates=%zu measured=%zu unobservable=%zu measurement_errors=%zu too_small=%zu overlapping=%zu ratio0=%.4f ratio1=%.4f area_threshold=%.4f alert=%d result=%d",
                     static_cast<unsigned long long>(sequence), frame.camera_id,
                     static_cast<int>(frame.format), targets.size(), clipped_empty, other_class,
                     zero_area_boxes, zero_score, below_threshold, selected.size(),
                     nms_suppressed, report_.snow_detections.size(), measured, unobservable,
                     other_measurement_errors, too_small, overlapping, ratio0, ratio1,
                     cfg_.area_ratio, static_cast<int>(report_.alert_level),
                     static_cast<int>(report_.result_code));
        }
    };
    for (auto t : targets) {
        if (!std::isfinite(t.x) || !std::isfinite(t.y) || !std::isfinite(t.w) ||
            !std::isfinite(t.h) || t.w < 0 || t.h < 0) {
            EVS_LOGE("invalid target geometry: class=%d x=%.6f y=%.6f w=%.6f h=%.6f",
                     t.class_id, t.x, t.y, t.w, t.h);
            return fail(EvsStatus::ModelInvalidFormat);
        }
        const float left = std::clamp(t.x - t.w / 2, 0.f, 1.f);
        const float top = std::clamp(t.y - t.h / 2, 0.f, 1.f);
        const float right = std::clamp(t.x + t.w / 2, 0.f, 1.f);
        const float bottom = std::clamp(t.y + t.h / 2, 0.f, 1.f);
        t.x = (left + right) / 2; t.y = (top + bottom) / 2;
        t.w = right - left; t.h = bottom - top;
        if (t.w <= 0 || t.h <= 0) {
            ++clipped_empty;
            continue;
        }
        if (!std::isfinite(t.confidence) || t.confidence < 0 || t.confidence > 1) {
            EVS_LOGE("invalid target confidence: class=%d confidence=%.6f",
                     t.class_id, t.confidence);
            return fail(EvsStatus::ModelInvalidFormat);
        }
        if (t.class_id != cfg_.person_class_id) {
            ++other_class;
            continue;
        }
        const auto box = pixel_box(t, frame.width, frame.height);
        // Temporary contract: these are winch candidates, not snow targets.
        // Preserve model order, low scores and duplicates for the shadow consumer.
        if (box.width && box.height)
            report_.snow_detections.push_back(box);
        else
            ++zero_area_boxes;
        // Retain zero scores above, but keep them out of the business branch.
        if (t.confidence <= 0) {
            ++zero_score;
        } else if (t.confidence >= cfg_.confidence_threshold) {
            selected.push_back(t);
        } else {
            ++below_threshold;
        }
    }
    std::sort(selected.begin(), selected.end(),
              [](const auto& a, const auto& b) { return a.confidence > b.confidence; });
    std::vector<Target> kept;
    for (const auto& t : selected) {
        if (std::none_of(kept.begin(), kept.end(),
                         [&](const auto& other) { return overlap(t, other) > cfg_.nms_threshold; })) {
            kept.push_back(t);
        } else {
            ++nms_suppressed;
        }
        if (kept.size() > 2) {
            EVS_LOGE("too many winch objects after NMS: kept=%zu limit=2 threshold=%.4f",
                     kept.size(), cfg_.nms_threshold);
            fail(EvsStatus::OutOfRange);
            return out.status;
        }
    }
    selected.swap(kept);
    std::sort(selected.begin(), selected.end(),
              [](const auto& a, const auto& b) { return a.x != b.x ? a.x < b.x : a.y < b.y; });
    IceFramePixels pixels;
    if (const auto rc = prepare_ice_pixels(frame, ice_, pixels)) {
        reject_call(with_module(8, rc), out);
        return out.status;
    }
    measurement_timestamp_ms_ = static_cast<uint32_t>(frame.timestamp_us / 1000);
    if (selected.empty()) {
        publish(out);
        log_frame_summary();
        return 0;
    }
    const auto count = selected.size();
    report_.objects.resize(count);
    measurements_.resize(count);
    for (size_t i = 0; i < count; ++i) {
        auto& r = report_.objects[i];
        r.box = pixel_box(selected[i], frame.width, frame.height);
        if (r.box.width < 3 || r.box.height < 3) {
            ++too_small;
            continue;
        }
        bool ambiguous = false;
        for (size_t j = 0; j < selected.size(); ++j)
            if (i != j && intersects(r.box, pixel_box(selected[j], frame.width, frame.height)))
                ambiguous = true;
        if (ambiguous) {
            ++overlapping;
            continue;
        }
        const cv::Rect rect(int(r.box.x), int(r.box.y), int(r.box.width), int(r.box.height));
        const auto rc = measure_ice_pixels(pixels, rect, measurements_[i]);
        if (rc == uint32_t(EvsStatus::MemoryAllocation) ||
            rc == uint32_t(EvsStatus::PostprocessFailed)) {
            reject_call(with_module(8, rc), out);
            return out.status;
        }
        if (!rc) {
            r.valid = true;
            r.ice_ratio = measurements_[i].ratio;
            ++measured;
        } else if (rc == kIceUnobservable) {
            ++unobservable;
        } else {
            ++other_measurement_errors;
        }
    }
    publish(out);
    log_frame_summary();
    return 0;
#endif
}

bool WinchIcePlugin::copy_ice_masks(std::vector<testing::IceMaskSnapshot>& out) const {
    out.clear();
#if defined(EVS_WITH_OPENCV)
    for (size_t i = 0; i < measurements_.size(); ++i) {
        const auto& m = measurements_[i];
        if (m.surface.empty())
            continue;
        testing::IceMaskSnapshot s;
        s.winch_id = static_cast<uint32_t>(i);
        s.timestamp_ms = measurement_timestamp_ms_;
        s.width = m.surface.cols;
        s.height = m.surface.rows;
        s.surface.assign(m.surface.datastart, m.surface.dataend);
        if (!m.snow.empty())
            s.snow.assign(m.snow.datastart, m.snow.dataend);
        out.push_back(std::move(s));
    }
    return true;
#else
    EVS_LOGW("ice mask snapshots unavailable: OpenCV support is not compiled in");
    return false;
#endif
}

void WinchIcePlugin::reset() {
    const auto& window = frame_log_window_;
    if (window.frames != 0) {
        EVS_LOGI("partial frame window: frames=%llu inputs=%llu clipped_empty=%llu other_class=%llu zero_area=%llu zero_score=%llu below_threshold=%llu selected=%llu nms_suppressed=%llu candidates=%llu measured=%llu unobservable=%llu measurement_errors=%llu too_small=%llu overlapping=%llu alert_frames=%llu",
                 static_cast<unsigned long long>(window.frames),
                 static_cast<unsigned long long>(window.inputs),
                 static_cast<unsigned long long>(window.clipped_empty),
                 static_cast<unsigned long long>(window.other_class),
                 static_cast<unsigned long long>(window.zero_area),
                 static_cast<unsigned long long>(window.zero_score),
                 static_cast<unsigned long long>(window.below_threshold),
                 static_cast<unsigned long long>(window.selected),
                 static_cast<unsigned long long>(window.nms_suppressed),
                 static_cast<unsigned long long>(window.candidates),
                 static_cast<unsigned long long>(window.measured),
                 static_cast<unsigned long long>(window.unobservable),
                 static_cast<unsigned long long>(window.measurement_errors),
                 static_cast<unsigned long long>(window.too_small),
                 static_cast<unsigned long long>(window.overlapping),
                 static_cast<unsigned long long>(window.alert_frames));
    }
    configured_ = false;
    measurement_timestamp_ms_ = 0;
    frame_log_counter_ = 0;
    frame_log_window_ = FrameLogWindow{};
    report_ = WinchSnowResult{};
#if defined(EVS_WITH_OPENCV)
    measurements_.clear();
#endif
}

namespace {
std::unique_ptr<IFunctionPlugin> make_winch_ice_plugin() {
    return std::make_unique<WinchIcePlugin>();
}

const FunctionPluginRegistration kWinchIce(0x0008, make_winch_ice_plugin);
const FunctionConfigRegistration kIceConfig(0x0008, load_ice_options);
} // namespace
} // namespace evs
