#pragma once

#include "evs/frame.h"
#include "evs/status.h"
#include "evs/task_config.h"
#include "evs/winch_ice.h"
#include <limits>

#if defined(EVS_WITH_OPENCV)
#include <opencv2/core.hpp>
#endif

namespace evs {

// Private HSV settings; not part of the common task ABI or customer API.
struct IceConfig {
    int saturation_max = 80;
    int value_min = 180;
};

// Pixel threshold validation does not depend on OpenCV.
bool valid_ice_config(const IceConfig& cfg);

#if defined(EVS_WITH_OPENCV)
struct IceMeasurement {
    cv::Mat surface; // full-resolution mask for this frame's model rectangle
    cv::Mat snow;
    float ratio = -1.f;
    uint64_t surface_pixels = 0, snow_pixels = 0;
};

struct IceFramePixels {
    cv::Mat bgr, gray, candidate;
};

uint32_t prepare_ice_pixels(const Frame&, const IceConfig&, IceFramePixels&);
uint32_t measure_ice_pixels(const IceFramePixels&, const cv::Rect&, IceMeasurement&);

#endif

} // namespace evs

namespace evs::winch_ice::detail {
inline uint32_t ice_status(EvsStatus s) {
    return with_module(8, static_cast<uint32_t>(s));
}

// gray_rgb owns grayscale expansion for the duration of the synchronous call.
inline uint32_t make_frame(const ImageData& image, uint32_t camera_id, Frame& frame,
                           std::vector<uint8_t>& gray_rgb) {
    if (!image.data)
        return ice_status(EvsStatus::NullPointer);
    if (!image.width || !image.height ||
        image.width > uint32_t(std::numeric_limits<int>::max() / 3) ||
        image.height > uint32_t(std::numeric_limits<int>::max() / 2) ||
        uint64_t(image.width) * image.height > uint64_t(std::numeric_limits<int>::max()))
        return ice_status(EvsStatus::InvalidImageSize);
    if (image.channels != 1 && image.channels != 3)
        return ice_status(EvsStatus::InvalidImageData);
    frame.data = image.data;
    if (image.channels == 1) {
        const size_t count = size_t(image.width) * image.height;
        gray_rgb.resize(count * 3);
        for (size_t i = 0; i < count; ++i)
            gray_rgb[i * 3] = gray_rgb[i * 3 + 1] = gray_rgb[i * 3 + 2] = image.data[i];
        frame.data = gray_rgb.data();
    }
    frame.width = static_cast<int>(image.width);
    frame.height = static_cast<int>(image.height);
    frame.stride = static_cast<int>(image.width * 3);
    frame.camera_id = static_cast<int>(camera_id);
    frame.format = PixelFormat::RGB;
    frame.timestamp_us = int64_t(image.timestamp_ms) * 1000;
    return 0u;
}
} // namespace evs::winch_ice::detail
