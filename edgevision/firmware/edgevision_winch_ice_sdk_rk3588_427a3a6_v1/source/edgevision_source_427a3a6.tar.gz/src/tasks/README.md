# 任务插件

五个功能插件分阶段落地。阶段 3 已完成**人员三插件**的核心策略引擎。

## 实现方式

人员在 `libevs_person.so`，高度限位在 `libevs_height_limit.so`，卷扬冰雪在 `libevs_ice.so`。公共库 `libevs_core.so` 不含这三份业务代码。
三个人员插件（0x0004 / 0x0005 / 0x0006）共用同一份检测权重（经 `ModelRegistry` 引用计数只加载一份），
也共用同一套决策引擎（`src/tasks/person/person_plugin.cpp` + `include/evs/person_plugin.h`）。
`VisionTask` 在解码后通过 `IFunctionPlugin::decide` 执行规则。高度插件已接入模型开关检测，安装姿态规则尚未实现；卷扬冰雪在自己的插件中完成模型框裁剪、HSV面积计量及逐帧报警。冰雪专用结果和掩码不放入公共插件接口。
三者差异只体现在
`PersonPolicyConfig` 上，由 `make_person_config(module_id, cfg, out)` 按模块号构造：

| 模块 | 参考点 | 区域 | 无工况策略 | 关键字段 |
|---|---|---|---|---|
| `load_near` 0x0004 | 吊钩地面投影 | 圆 r=10m | 检测到人立即报警 | `missing_context=alarm` |
| `load_under` 0x0005 | 吊钩地面投影 | 圆 r=10m − 载荷遮挡扇区 | 只记录 | `has_occlusion`, `occ_axis_deg=90`, `occ_half_deg=25` |
| `boom_under` 0x0006 | 大臂根部 | 扇形 半径=`hoist_radius`(≥50) / 半角 40° | 只记录 | `dynamic_radius`, `sector_axis_deg=0` |

策略规则（见 `person_decide`）：
1. `context_valid == false`：0x0004 检测到人→立即 `Alarm`（不计数）；0x0005/0x0006→`LogOnly`，不报警。
2. 工况有效但**静止**（回转/变幅/起落钩/伸缩均不动）：有人→`LogOnly`，不报警。
3. **作业**中：区内有人则连续帧计数，达到 `consecutive_frames` 转 `Alarm`；未稳前为 `LogOnly`。

## 检测 / 解码（已与模型输出解耦）

模型输出张量的解析**不再硬编码**，改为可插拔解码器，由 `configs/*.yaml` 的 `output_format` 选择：

- `flat6`（默认）：每检测 6 个 float = `[class_id, conf, x, y, w, h]`（0..1 图像坐标），
  单类 person 检测器约定，由 `Flat6Decoder` 包装原 `decode_person`。
- `yolov8`：行布局 `[N, 4 + num_classes]` = `[x_c, y_c, w, h, s0, s1, ...]`，
  取 argmax 类作为 `class_id`/置信度；`person_class_id >= 0` 时只保留该类（默认 COCO 80 类，
  非 COCO 用 `decoder_classes` 指定行宽）。
- `yolox`：一份 `[8400, 85]`（stride 8/16/32，尺度内 y 在外、x 在内），或按尺度拆开的
  `[1, 85, S, S]` / `[1, S, S, 85]`。后端按 `(raw+grid)*stride`、`exp(raw)*stride` 解码，
  NMS 不分类别、IoU 0.5。解码器看到的行与 `yolov8` 相同。

接口：`evs/detection_decoder.h` 的 `IDetectionDecoder` + `create_decoder(format, person_class_id, num_classes)`。
未知格式在 `VisionTask::initialize` 时直接返回 `NotSupported`（fail-fast）；运行时 `updateConfig` 也禁止改
`output_format` / `person_class_id` / `decoder_classes`（与 backend/model 同属模型契约，需重新初始化）。

`distance_m` / `angle_deg` 由 **Phase 4 工况适配**根据参考点（吊钩投影 / 大臂根部）换算为地面极坐标，
本阶段留 0；`boom_under` 的半径在决策时取 `MachineContext.hoist_radius` 并夹到 ≥50m。

## 配置

- `configs/load_near.yaml`、`configs/load_under.yaml`、`configs/boom_under.yaml`

## 待办（后续）

- 0x0007 高度限位的安装姿态几何规则及角度、连续帧、静止超时状态机；卷扬冰雪的真机精度与质量策略仍待现场验收，库内不保持跨帧报警。
- 公共地面映射已接入距离和角度计算，标定质量及多相机结果合并仍需宿主验证。
- RKNN后端已有实现；QNN后端及对应张量对接仍待实现。

## 开发者新增一个算法的标准动作

写 `xxx_plugin.cpp`：`class Xxx : public IFunctionPlugin` + `make_xxx()` 返回 `unique_ptr`。
文件尾部加 `const FunctionPluginRegistration kXxx(0x0009, make_xxx);`
在 `CMakeLists.txt` 里用 `evs_add_plugin` 把该 `.cpp` 编成单独的动态库，不要放进 `EVS_SRC`。
宿主链接 `libevs_core.so` 和这个新库。链静态库时走 `evs_link_whole`，并把新的静态库加进那个函数。

需要专属文件参数的功能可登记 `FunctionConfigRegistration`；任务生命周期扩展可选用独立的 `IFunctionTaskHooks`。原 `IFunctionPlugin` 和 `TaskConfig` 布局保持基线不变。新功能不必实现这些可选扩展。详见[插件架构说明](../../docs/plugin_architecture.md)。
