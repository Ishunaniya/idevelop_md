#include "evs/vision_task.h"
#include "core/config_internal.h"
#include "core/backend_contract.h"
#include "evs/function_task_hooks.h"

#include <algorithm>
#include <chrono>
#include <map>
#include <sstream>
#include <utility>
#include <type_traits>
#include <vector>

#include "evs/geom.h"
#include "evs/backend_factory.h"
#include "evs/model_registry.h"
#include "evs/task_config.h"
#include "evs/function_plugin.h"
#include "evs/ground_mapper.h"
#include "evs/ground_metrics.h"
#include "evs/detection_decoder.h"
#include "evs/preprocess.h"
#include "evs/log.h"
#include "evs/debug.h"

namespace evs {

namespace {
using Clock = std::chrono::steady_clock;

double ms_since(const Clock::time_point& t0) {
    return std::chrono::duration<double, std::milli>(Clock::now() - t0).count();
}

using GroundMapperMap = std::map<int, std::unique_ptr<IGroundMapper>>;

uint32_t build_ground_mappers(const GroundConfig& cfg, GroundMapperMap& out) {
    out.clear();
    if (!cfg.enabled) return 0u;
    for (const CameraGroundConfig& camera : cfg.cameras) {
        if (camera.id < 0 || out.find(camera.id) != out.end()) {
            EVS_LOGE("invalid/duplicate ground camera id=%d", camera.id);
            return static_cast<uint32_t>(EvsStatus::InvalidParameter);
        }
        uint32_t map_err = 0;
        auto mapper = create_ground_mapper(camera, &map_err);
        if (!mapper) {
            EVS_LOGE("ground mapper configure failed: camera=%d type=%s status=0x%08X",
                     camera.id, camera.mapper.c_str(), map_err);
            return map_err ? map_err
                           : static_cast<uint32_t>(EvsStatus::ConfigInvalid);
        }
        out.emplace(camera.id, std::move(mapper));
    }
    return 0u;
}

void warn_missing_ground_mappers(const TaskConfig& cfg,
                                 const GroundMapperMap& mappers) {
    if (!cfg.ground.enabled) return;
    for (int camera_id : cfg.video_channel) {
        if (mappers.find(camera_id) == mappers.end()) {
            EVS_LOGW("camera %d is accepted by video_channel but has no ground mapper; "
                     "distance will stay unknown", camera_id);
        }
    }
}

std::string jstr(const std::string& v) {
    std::string out = "\"";
    for (char c : v) {
        if (c == '"' || c == '\\') { out += '\\'; out += c; }
        else out += c;
    }
    out += '"';
    return out;
}
} // anonymous namespace

struct VisionTask::Impl {
    TaskConfig cfg;
    bool initialized = false;
    std::shared_ptr<IInferBackend> backend;
    std::unique_ptr<IDetectionDecoder> decoder; // model-output parser
    std::unique_ptr<IFunctionPlugin> plugin;    // independently registered function
    IFunctionTaskHooks* hooks = nullptr;        // optional; owned by plugin
    FunctionOptions options;
    GroundMapperMap ground_mappers;             // camera id -> image/ground projection
    Preprocessor pre;                           // frame -> model input
    TaskDebug dbg;                              // counters + dump policy

    // Last preprocessed tensor; cached only while debugging is enabled.
    std::vector<uint8_t> last_input;
    int last_in_w = 0;
    int last_in_h = 0;
};

VisionTask::VisionTask() : impl_(std::make_unique<Impl>()) {}
VisionTask::~VisionTask() { release(); }

uint32_t VisionTask::initialize(std::string_view config_path) {
    if (impl_->initialized) return 0u; // idempotent: never reload / leak

    const std::string cfp(config_path);
    TaskConfig cfg;
    uint32_t err = 0;
    EVS_LOGI("initializing from %s", cfp.c_str());
    FunctionOptions options;
    uint16_t parsed_module = cfg.module_id;
    if (!detail::load_task_config_with_module(config_path, cfg, err, parsed_module, &options)) {
        EVS_LOGE("config parse failed: %s", cfp.c_str());
        // rollback: nothing allocated yet
        const uint32_t code = err ? err : static_cast<uint32_t>(EvsStatus::ConfigParse);
        return with_module(parsed_module, code);
    }

    return initializeTask(cfg, options);
}

uint32_t VisionTask::initialize(const TaskConfig& config) {
    return initializeTask(config, {});
}

uint32_t VisionTask::initializeTask(const TaskConfig& config, const FunctionOptions& options) {
    if (impl_->initialized) return 0u;
    TaskConfig cfg = config;
    auto next_options = options;
    auto plugin = create_function_plugin(cfg.module_id);
    if (!plugin)
        return with_module(cfg.module_id, uint32_t(EvsStatus::NotSupported));
    auto* hooks = dynamic_cast<IFunctionTaskHooks*>(plugin.get());
    if (hooks) {
        if (const auto rc = hooks->validate_task(cfg)) return with_module(cfg.module_id, rc);
    }

    auto& reg = global_registry();
    if (!create_backend(cfg.backend)) {
        EVS_LOGE("backend '%s' is not compiled into this build", cfg.backend.c_str());
        return with_module(cfg.module_id, static_cast<uint32_t>(EvsStatus::NotSupported));
    }
    auto be = reg.acquire(cfg.backend, cfg.Model_path, cfg.init_timeout_s);
    if (!be) {
        EVS_LOGE("model load failed: backend=%s model=%s",
                 cfg.backend.c_str(), cfg.Model_path.c_str());
        return with_module(cfg.module_id, static_cast<uint32_t>(EvsStatus::ModelLoadFailed));
    }
    // Pair the registry reference with every exit, including allocation failure
    // before the task becomes initialized. config outlives this guard and is
    // not the local cfg that is moved into impl_ below.
    struct ModelLease {
        VisionTask& task;
        const TaskConfig& config;
        bool committed = false;
        ~ModelLease() {
            if (!committed) {
                task.release();
                global_registry().release(config.backend, config.Model_path);
            }
        }
    } lease{*this, config};
    if (const auto rc = detail::validate_backend_contract(*be, cfg))
        return with_module(cfg.module_id, rc);
    be->configure_input(cfg.input_width, cfg.input_height);
    auto dec = create_decoder(cfg.output_format, cfg.person_class_id, cfg.decoder_classes,
                         cfg.input_width, cfg.input_height);
    if (!dec) {
        EVS_LOGE("unknown output_format=%s", cfg.output_format.c_str());
        return with_module(cfg.module_id, static_cast<uint32_t>(EvsStatus::ModelInvalidFormat));
    }
    const uint32_t policy_status = hooks ? hooks->configure_task(cfg, next_options) : plugin->configure(cfg);
    if (policy_status) {
        EVS_LOGE("function plugin configure failed (status=0x%08X)", policy_status);
        return with_module(cfg.module_id, policy_status);
    }
    GroundMapperMap ground_mappers;
    if (const uint32_t ge = build_ground_mappers(cfg.ground, ground_mappers)) {
        return with_module(cfg.module_id, ge);
    }
    warn_missing_ground_mappers(cfg, ground_mappers);

    impl_->cfg = std::move(cfg);
    impl_->backend = std::move(be);
    impl_->decoder = std::move(dec);
    impl_->plugin = std::move(plugin);
    impl_->hooks = hooks;
    impl_->options = std::move(next_options);
    impl_->ground_mappers = std::move(ground_mappers);

    // Configure preprocessing (frame -> model input). Invalid input dims leave
    // it unconfigured, which detect() treats as a pass-through (legacy behaviour).
    PreprocessConfig pc;
    pc.input_width = impl_->cfg.input_width;
    pc.input_height = impl_->cfg.input_height;
    pc.letterbox = impl_->cfg.letterbox;
    pc.target_format = (impl_->cfg.input_format == "bgr") ? PixelFormat::BGR
                                                           : PixelFormat::RGB;
    impl_->pre.configure(pc);
    const bool pre_ok = impl_->pre.configured();

    // Optional warmup: one dummy inference so the first real frame stays within
    // the latency budget. An optional task hook may require warmup success.
    if (impl_->cfg.warmup && pre_ok) {
        const Clock::time_point w0 = Clock::now();
        std::vector<uint8_t> dummy(
            static_cast<size_t>(impl_->cfg.input_width) *
                impl_->cfg.input_height * 3,
            0);
        std::vector<float> warm_out;
        const auto wr = detail::infer_backend_contract(*impl_->backend, impl_->cfg, dummy, warm_out);
        if (wr != 0u) {
            EVS_LOGW("warmup inference failed (status=0x%08X)", wr);
            if (impl_->hooks && impl_->hooks->require_warmup_success())
                return with_module(impl_->cfg.module_id, wr);
        } else {
            EVS_LOGI("warmup done in %.1f ms", ms_since(w0));
        }
    }

    impl_->dbg.configure(impl_->cfg.debug);
    impl_->initialized = true;
    lease.committed = true;
    EVS_LOGI("task ready: module=0x%04X backend=%s model=%s input=%dx%d "
             "letterbox=%d debug=%d",
             impl_->cfg.module_id, impl_->cfg.backend.c_str(),
             impl_->cfg.Model_path.c_str(), impl_->cfg.input_width,
             impl_->cfg.input_height, impl_->cfg.letterbox ? 1 : 0,
             impl_->cfg.debug.enabled ? 1 : 0);
    return 0u;
}

uint32_t VisionTask::acceptFrame(const Frame& frame) const {
    if (!impl_->initialized) return static_cast<uint32_t>(EvsStatus::NotInitialized);
    const uint16_t module = impl_->cfg.module_id;
    if (frame.data == nullptr) {
        EVS_LOGW("detect: null frame data");
        return with_module(module, static_cast<uint32_t>(EvsStatus::NullPointer));
    }
    if (frame.width <= 0 || frame.height <= 0)
        return with_module(module, static_cast<uint32_t>(EvsStatus::InvalidParameter));
    for (int id : impl_->cfg.video_channel)
        if (id == frame.camera_id) return 0u;
    EVS_LOGW("frame from camera %d ignored: not in video_channel", frame.camera_id);
    return with_module(module, static_cast<uint32_t>(EvsStatus::InvalidCameraIndex));
}

uint32_t VisionTask::detect(const Frame& frame, const MachineContext& ctx, Result& out) {
    if (const uint32_t ck = acceptFrame(frame)) {
        return rejectFrame(ck, out);
    }

    // Optical blind is judged after preprocessing, before inference.
    // (placeholder: never blind in the scaffold build)
    bool camera_blind = false;
    if (camera_blind) {
        EVS_LOGW("camera %d blind: frame skipped", frame.camera_id);
        out = Result{};
        out.status = with_module(impl_->cfg.module_id,
                                 static_cast<uint32_t>(EvsStatus::HardwareFault));
        out.camera_blind = true;
        return out.status;
    }

    const Clock::time_point t0 = Clock::now();
    std::vector<uint8_t> input;
    PreprocessMap pre_map{};
    if (impl_->pre.configured()) {
        uint32_t pr = impl_->pre.run(frame, input, pre_map);
        if (pr != 0u) {
            pr = with_module(impl_->cfg.module_id, pr);
            EVS_LOGE("preprocess failed (status=0x%08X)", pr);
            impl_->dbg.note(0.0, 0.0, 0.0, ms_since(t0), pr, AlarmState::None,
                            0, frame.timestamp_us);
            return rejectFrame(pr, out);
        }
    } else {
        // Legacy pass-through: identity map (no resize happened).
        pre_map.in_w = frame.width;
        pre_map.in_h = frame.height;
        pre_map.scale_x = 1.f;
        pre_map.scale_y = 1.f;
    }
    return finishDetect(frame, ctx, input, pre_map, ms_since(t0), out);
}

uint32_t VisionTask::detectPrepared(const Frame& frame, const MachineContext& ctx,
                                    std::vector<uint8_t> tensor, const PreprocessMap& map,
                                    double preprocess_ms, Result& out) {
    if (const uint32_t ck = acceptFrame(frame)) {
        return rejectFrame(ck, out);
    }
    const std::size_t need = static_cast<std::size_t>(impl_->cfg.input_width) *
                             static_cast<std::size_t>(impl_->cfg.input_height) * 3u;
    if (tensor.size() != need || map.in_w != impl_->cfg.input_width ||
        map.in_h != impl_->cfg.input_height) {
        EVS_LOGW("detectPrepared: tensor %zu bytes, map %dx%d, model %dx%d",
                 tensor.size(), map.in_w, map.in_h, impl_->cfg.input_width,
                 impl_->cfg.input_height);
        const uint32_t rc =
            with_module(impl_->cfg.module_id, static_cast<uint32_t>(EvsStatus::InvalidImageSize));
        return rejectFrame(rc, out);
    }
    return finishDetect(frame, ctx, tensor, map, preprocess_ms, out);
}

IFunctionPlugin* VisionTask::functionPlugin() const noexcept {
    return impl_->initialized ? impl_->plugin.get() : nullptr;
}

uint32_t VisionTask::rejectFrame(uint32_t status, Result& out) noexcept {
    if (impl_->hooks) {
        status = with_module(impl_->cfg.module_id, status);
        impl_->hooks->reject_frame(status, out);
    }
    return status;
}

int VisionTask::inputWidth() const {
    return impl_->initialized ? impl_->cfg.input_width : 0;
}
int VisionTask::inputHeight() const {
    return impl_->initialized ? impl_->cfg.input_height : 0;
}
bool VisionTask::letterbox() const {
    return impl_->initialized && impl_->cfg.letterbox;
}

uint32_t VisionTask::finishDetect(const Frame& frame, const MachineContext& ctx,
                                  std::vector<uint8_t>& input, const PreprocessMap& pre_map,
                                  double pre_ms, Result& out) {
    const Clock::time_point t_start = Clock::now();

    // Keep the tensor only when debugging is on; copying every frame otherwise
    // would double memory traffic on the slow path.
    if (impl_->cfg.debug.enabled) {
        impl_->last_input = input;
        impl_->last_in_w = pre_map.in_w;
        impl_->last_in_h = pre_map.in_h;
    }

    const Clock::time_point t1 = Clock::now();
    std::vector<float> output;
    uint32_t r = detail::infer_backend_contract(*impl_->backend, impl_->cfg, input, output);
    const double infer_ms = ms_since(t1);
    if (r != 0u) {
        r = with_module(impl_->cfg.module_id, r);
        EVS_LOGE("inference failed (status=0x%08X, input=%zu B)", r, input.size());
        impl_->dbg.note(pre_ms, infer_ms, 0.0, pre_ms + ms_since(t_start), r,
                        AlarmState::None, 0, frame.timestamp_us);
        return rejectFrame(r, out);
    }

    const Clock::time_point t2 = Clock::now();
    std::vector<Target> targets;
    const bool unfiltered = dynamic_cast<IUnfilteredDetectionInput*>(impl_->plugin.get()) != nullptr;
    impl_->decoder->decode(output, unfiltered ? 0.f : impl_->cfg.confidence_threshold, targets);
    // Decode targets are in 0..1 of the model input; undo letterbox/stretch
    // so the policy works in original-frame coordinates.
    for (auto& t : targets)
        map_target_to_original(pre_map, t, frame.width, frame.height);
    for (auto& target : targets) {
        target.ground_ok = false;
        target.ground_x_m = 0.f;
        target.ground_y_m = 0.f;
    }
    const auto mapper_it = impl_->ground_mappers.find(frame.camera_id);
    if (mapper_it != impl_->ground_mappers.end()) {
        for (auto& target : targets) {
            const GroundPoint point = mapper_it->second->map(target, frame, ctx);
            target.ground_ok = point.ok;
            target.ground_x_m = point.x_m;
            target.ground_y_m = point.y_m;
        }
    }
    GroundReference reference;
    if (impl_->cfg.ground.enabled &&
        impl_->plugin && impl_->plugin->ground_reference(ctx, reference)) {
        apply_ground_metrics(reference, impl_->cfg.ground.distance_mode, targets);
    } else {
        clear_ground_metrics(targets);
    }
    const double decode_ms = ms_since(t2);
    out = Result{};
    out.status = 0u;
    out.camera_blind = false;
    if (!impl_->plugin)
        return with_module(impl_->cfg.module_id,
                           static_cast<uint32_t>(EvsStatus::NotInitialized));
    if (const uint32_t dr = impl_->plugin->decide(frame, ctx, targets, out)) {
        const uint32_t stamped = with_module(impl_->cfg.module_id, dr);
        out.status = stamped;
        return stamped;
    }
    const AlarmState alarm = out.alarm;

    out.camera_channel = pack_camera_channel(
        static_cast<uint8_t>(frame.camera_id & 0xFF));

    // Latency watchdog: the operator needs to know when we stop meeting the
    // frame budget before callbacks pile up.
    const double total_ms = pre_ms + ms_since(t_start);
    if (impl_->cfg.latency_budget_ms > 0 &&
        total_ms > static_cast<double>(impl_->cfg.latency_budget_ms)) {
        impl_->dbg.note_budget(true);
        EVS_LOGW("frame %.1f ms > budget %d ms (pre=%.1f infer=%.1f decode=%.1f)",
                 total_ms, impl_->cfg.latency_budget_ms, pre_ms, infer_ms, decode_ms);
    }

    impl_->dbg.note(pre_ms, infer_ms, decode_ms, total_ms, 0u, alarm,
                    out.targets.size(), frame.timestamp_us);
    // Dumping is bounded by the policy in DebugConfig (interval / alarm only).
    impl_->dbg.maybe_dump(frame.width, frame.height, pre_map, input, targets,
                          0u, alarm, frame.timestamp_us);
    EVS_LOGT("frame cam=%d %dx%d -> %zu targets, state=%s, %.1f ms",
             frame.camera_id, frame.width, frame.height, out.targets.size(),
             out.alarm == AlarmState::Alarm ? "alarm" : "ok", total_ms);
    return 0u;
}

uint32_t VisionTask::updateConfig(std::string_view config_path) {
    if (!impl_->initialized) return static_cast<uint32_t>(EvsStatus::NotInitialized);
    const uint16_t module = impl_->cfg.module_id;

    TaskConfig newcfg;
    FunctionOptions options;
    uint32_t err = 0;
    uint16_t parsed_module = newcfg.module_id;
    if (!detail::load_task_config_with_module(config_path, newcfg, err, parsed_module, &options)) {
        const uint32_t code = err ? err : uint32_t(EvsStatus::ConfigParse);
        return with_module(module, code);
    }
    return updateTask(newcfg, options);
}

uint32_t VisionTask::updateConfig(const TaskConfig& config) {
    return updateTask(config, impl_->options);
}

uint32_t VisionTask::updateTask(const TaskConfig& config, const FunctionOptions& options) {
    if (!impl_->initialized) return uint32_t(EvsStatus::NotInitialized);
    const uint16_t module = impl_->cfg.module_id;
    TaskConfig newcfg = config;
    // Backend / model are immutable at runtime.
    if (newcfg.backend != impl_->cfg.backend || newcfg.Model_path != impl_->cfg.Model_path) {
        EVS_LOGW("updateConfig rejected: backend/model change %s -> %s",
                 impl_->cfg.backend.c_str(), newcfg.backend.c_str());
        return with_module(module, static_cast<uint32_t>(EvsStatus::NotSupported));
    }

    // Output layout is bound to the model; changing how its tensor is parsed
    // also requires a re-init, so reject it here.
    if (newcfg.output_format != impl_->cfg.output_format ||
        newcfg.decoder_classes != impl_->cfg.decoder_classes ||
        newcfg.person_class_id != impl_->cfg.person_class_id ||
        newcfg.module_id != impl_->cfg.module_id) {
        EVS_LOGW("updateConfig rejected: decoder bound to the loaded model");
        return with_module(module, static_cast<uint32_t>(EvsStatus::NotSupported));
    }

    // Build ground mapping transactionally. A bad hot update must leave the
    // current camera calibration and mapper instances untouched.
    GroundMapperMap next_ground_mappers;
    if (const uint32_t ge = build_ground_mappers(newcfg.ground, next_ground_mappers)) {
        EVS_LOGW("updateConfig rejected: ground mapper configure failed 0x%08X", ge);
        return with_module(module, ge);
    }
    warn_missing_ground_mappers(newcfg, next_ground_mappers);

    if (!impl_->plugin) return with_module(module, uint32_t(EvsStatus::NotInitialized));
    if (impl_->hooks) {
        if (const auto rc = impl_->hooks->validate_task(newcfg)) return with_module(module, rc);
    }
    // Allocate the entire next state before the function commits its policy.
    // Everything following configure_task/configure is a no-throw swap.
    TaskConfig next = impl_->cfg;
    next.on_missing_context = newcfg.on_missing_context;
    next.work_motion_epsilon = newcfg.work_motion_epsilon;
    next.zone = newcfg.zone;
    next.confidence_threshold = newcfg.confidence_threshold;
    next.nms_threshold = newcfg.nms_threshold;
    next.ground = newcfg.ground;
    next.latency_budget_ms = newcfg.latency_budget_ms;
    next.start_angle_deg = newcfg.start_angle_deg;
    next.stop_angle_deg = newcfg.stop_angle_deg;
    next.min_frames = newcfg.min_frames;
    next.still_timeout_s = newcfg.still_timeout_s;
    next.basic_boom_only = newcfg.basic_boom_only;
    next.area_ratio = newcfg.area_ratio;
    next.exit_on_alarm = newcfg.exit_on_alarm;
    next.debug = newcfg.debug;
    auto next_options = options;
    TaskDebug next_debug = impl_->dbg;
    next_debug.configure(next.debug);
    const auto pc = impl_->hooks ? impl_->hooks->configure_task(newcfg, next_options)
                                : impl_->plugin->configure(newcfg);
    if (pc) return with_module(module, pc);
    using std::swap;
    static_assert(std::is_nothrow_swappable_v<TaskConfig>);
    static_assert(std::is_nothrow_swappable_v<TaskDebug>);
    swap(impl_->cfg, next);
    swap(impl_->options, next_options);
    swap(impl_->dbg, next_debug);
    impl_->ground_mappers.swap(next_ground_mappers);

    if (impl_->cfg.debug.enabled)
        EVS_LOGI("debug updated: enabled=1 dir=%s every_n=%d (frames=%llu)",
                 impl_->cfg.debug.dump_dir.c_str(), impl_->cfg.debug.dump_every_n,
                 static_cast<unsigned long long>(impl_->dbg.stats().frames));

    EVS_LOGI("updateConfig applied: score=%.2f radius=%.1f budget=%d ms",
             impl_->cfg.confidence_threshold, impl_->cfg.zone.radius_m,
             impl_->cfg.latency_budget_ms);
    return 0u;
}

void VisionTask::release() {
    if (!impl_) return;
    if (impl_->initialized && impl_->backend) {
        EVS_LOGI("releasing %s:%s (%llu frames processed)",
                 impl_->cfg.backend.c_str(), impl_->cfg.Model_path.c_str(),
                 static_cast<unsigned long long>(impl_->dbg.stats().frames));
        global_registry().release(impl_->cfg.backend, impl_->cfg.Model_path);
    }
    impl_->hooks = nullptr;
    impl_->options.clear();
    if (impl_->plugin) impl_->plugin->reset();
    impl_->plugin.reset();
    impl_->ground_mappers.clear();
    impl_->decoder.reset();
    impl_->initialized = false;
    impl_->backend.reset();
}

const DebugStats& VisionTask::debugStats() const { return impl_->dbg.stats(); }

std::string VisionTask::debugSnapshot() const {
    const TaskConfig& c = impl_->cfg;
    const DebugStats& s = impl_->dbg.stats();
    std::ostringstream js;
    js << "{\"initialized\":" << (impl_->initialized ? "true" : "false")
       << ",\"task\":" << jstr(c.task)
       << ",\"backend\":" << jstr(c.backend)
       << ",\"Model_path\":" << jstr(c.Model_path)
       << ",\"output_format\":" << jstr(c.output_format)
       << ",\"input\":{\"w\":" << c.input_width << ",\"h\":" << c.input_height
       << ",\"format\":" << jstr(c.input_format)
       << ",\"letterbox\":" << (c.letterbox ? "true" : "false") << "}"
       << ",\"confidence_threshold\":" << c.confidence_threshold
       << ",\"latency_budget_ms\":" << c.latency_budget_ms
       << ",\"frames\":" << s.frames
       << ",\"stats\":" << impl_->dbg.snapshot_json();
    // Append the last few log lines so a remote snapshot carries context.
    js << ",\"log\":[";
    const auto lines = Logger::instance().tail(10);
    for (std::size_t i = 0; i < lines.size(); ++i) {
        if (i) js << ',';
        js << jstr(lines[i]);
    }
    js << "]}";
    return js.str();
}

void VisionTask::setDebugConfig(const DebugConfig& cfg) {
    impl_->cfg.debug = cfg;
    impl_->dbg.configure(cfg);
    EVS_LOGI("debug set: enabled=%d dir=%s every_n=%d alarm_only=%d",
             cfg.enabled ? 1 : 0, cfg.dump_dir.c_str(), cfg.dump_every_n,
             cfg.dump_on_alarm_only ? 1 : 0);
}

bool VisionTask::saveLastInput(const std::string& path) const {
    if (impl_->last_input.empty() || impl_->last_in_w <= 0 || impl_->last_in_h <= 0) {
        EVS_LOGW("saveLastInput: no tensor cached (debug is %s)",
                 impl_->cfg.debug.enabled ? "on" : "off");
        return false;
    }
    return save_rgb_ppm(impl_->last_input.data(), impl_->last_in_w,
                        impl_->last_in_h, path);
}

} // namespace evs
