#pragma once
#include <map>
#include <string>

#include "evs/function_plugin.h"

namespace evs {

// Optional, per-task function settings. Kept outside TaskConfig to preserve
// the layout used by existing hosts and plugins.
using FunctionOptions = std::map<std::string, std::string>;

// Optional task integration, separate from the stable IFunctionPlugin vtable.
// Existing plugins need not implement this interface. Keep this interface
// stable too; add a separate capability instead of reordering its methods.
struct IFunctionTaskHooks {
    virtual ~IFunctionTaskHooks() = default;
    // Validation must not change the active policy. A failed configure_task
    // must leave it intact; allocate the next state before committing it.
    virtual uint32_t validate_task(const TaskConfig&) const = 0;
    virtual uint32_t configure_task(const TaskConfig&, const FunctionOptions&) = 0;
    virtual bool require_warmup_success() const noexcept = 0;
    virtual void reject_frame(uint32_t status, Result& out) noexcept = 0;
};

// Opt-in: receive decoded candidates before the task's confidence filter.
// The plugin must apply its own business threshold/NMS. Existing plugin
// interfaces and their vtables remain unchanged.
struct IUnfilteredDetectionInput {
    virtual ~IUnfilteredDetectionInput() = default;
};

} // namespace evs
