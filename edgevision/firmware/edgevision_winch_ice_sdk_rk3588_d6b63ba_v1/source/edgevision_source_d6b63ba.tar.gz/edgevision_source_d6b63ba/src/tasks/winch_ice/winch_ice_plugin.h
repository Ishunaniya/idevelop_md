#pragma once
#include "evs/function_plugin.h"
#include "evs/function_task_hooks.h"
#include "evs/winch_ice.h"
#include "ice_measurement.h"

namespace evs {
namespace testing { struct IceMaskSnapshot; }
class WinchIcePlugin : public IFunctionPlugin, public IFunctionTaskHooks,
                       public IUnfilteredDetectionInput {
public:
    uint16_t module_id() const override { return 0x0008; }

    uint32_t configure(const TaskConfig&) override;
    void reject_call(uint32_t status, Result& out) noexcept;
    uint32_t decide(const Frame&, const MachineContext&, const std::vector<Target>&,
                    Result&) override;

    const winch_ice::WinchSnowResult* winch_result() const { return &report_; }

    bool copy_ice_masks(std::vector<testing::IceMaskSnapshot>&) const;
    void reset() override;

    uint32_t validate_task(const TaskConfig&) const override;
    uint32_t configure_task(const TaskConfig&, const FunctionOptions&) override;
    bool require_warmup_success() const noexcept override { return true; }
    void reject_frame(uint32_t status, Result& out) noexcept override;


private:
    void summarize() noexcept;
    void publish(Result&, uint32_t status = 0) noexcept;
    TaskConfig cfg_;
    IceConfig ice_;
    winch_ice::WinchSnowResult report_;
    bool configured_ = false;
    uint32_t measurement_timestamp_ms_ = 0;
#if defined(EVS_WITH_OPENCV)
    std::vector<IceMeasurement> measurements_;
#endif
};
} // namespace evs
