# 卷扬冰雪接入说明

正式配置是 `configs/winch_ice.yaml`，模型是仓库根目录的 `winch_model.rknn`，目标板为RK3588 Ubuntu。
库名保持 `libevs_core.so.1`、`libevs_ice.so.1` 及对应静态库。客户方法、参数、结果字段类型与枚举不变，头文件补充临时语义说明；部署时核心和冰雪库须使用本轮配套产物。

## 接口和结果

初始化加载模型一次；每次 `detect(image, result)` 处理当前一帧，包括重复时间戳。
一个实例绑定一路相机，各方法串行调用；使用相同模型的实例共享后端，宿主也须统一串行调度，不保证这些实例并行推理。宿主负责取图、工况、重试和报警保持。

```text
原图 → RKNN模型定位卷扬 → 框还原到原图 → 分别统计框内HSV冰雪候选
ice_ratio = snow_pixels / surface_pixels
surface_pixels = 原图矩形框 width × height
本帧全局报警 = 任一有效卷扬 ice_ratio >= area_ratio（默认0.5）
```

逐对象仅返回 `box`、`ice_ratio`、`valid`；计数与质量检查留在库内。
objects按框中心从左到右排列，索引仅对本帧有效。调用错误清空对象与报警，不使用上一帧结果。
调用返回值为0也须检查对象有效性：无框返回空对象；无效比例为-1，不能当作正常0%。
业务分支保留最多两个对象，筛选后仍超过两个时报错；交叠框、小于3×3的框及极暗/均匀过曝白的HSV计量无效。这些规则不用于截断snow_detections；质量策略仍待现场确认。

```cpp
#include <evs/winch_ice.h>
using namespace evs::winch_ice;
WinchSnowConfig cfg;
auto rc = load_config("configs/winch_ice.yaml", cfg);
Detector detector;
if (!rc) rc = detector.initialize(cfg);
// 初始化成功后，宿主对每帧执行：
ImageData image;
// 填写data、width、height、channels、timestamp_ms。
WinchSnowResult result;
// rc = detector.detect(image, result);
// 检查rc及objects[i].valid，再读取比例和result.alert_level。
```

输入为紧凑RGB24（channels=3）或8位灰度（channels=1），缓冲区至少width×height×channels字节。
没有行填充；BGR/NV12等格式由宿主先转换为RGB。灰度在库内复制为三通道，HSV饱和度恒0，失去颜色信息，不能据此宣称灰度检测精度通过。
客户原字段保留，原六结构只增加camera_channel、area_ratio、objects三项；模型固定为配套的单类YOLOX，不需要客户填写backend/output_format/类别/letterbox等内部参数。
本阶段仅有卷扬模型，尚无冰雪模型。经确认，snow_detections暂返回卷扬候选，名称沿用客户接口，不表示冰雪模型结果。
列表取自同一次推理的解码结果，恢复原图坐标并裁剪后，保留所有合法非零像素面积框，包括置信度为0的框；不做置信度过滤、NMS或Top-K截断，保持模型输出顺序。
业务分支排除零分框，再按confidence_threshold和nms_threshold筛选卷扬，最多两个对象；阈值设为0也不把零分框计为业务对象。result_code=1表示至少一个业务卷扬框，不依赖HSV计量是否有效；计量无效仍通过objects[i].valid=false、ice_ratio=-1表示。
低分候选列表可以非空而result_code=0；影子系统在调用成功时读取列表，不以result_code为读取门槛。Detection.width/height采用宽高，不是右下坐标；confidence是卷扬模型置信度，不是HSV占比。
宿主编译时使用配套include目录，动态链接 `-levs_ice -levs_core`，运行时确保可找到这两个库和RKNN/OpenCV依赖。
调用期间图像内存须有效，库不保存图像指针。updateConfig整体更新置信度、NMS及面积阈值三项，非法参数不生效。HSV固定为内部默认值。更换模型或相机需释放并重新初始化。
warmup=true时预热失败会使冰雪初始化失败并回滚资源；warmup=false跳过预热。
正式路径始终要求模型，无人工框或固定区域回退。旧 `ice_mode:model`、`inference_enabled:true` 可读，其他旧模式/几何配置拒绝。
配置采用平铺Model_path/input_width/input_height等键；不扩展通用模型map解析。冰雪库自行登记配置适配器，所以这份简化YAML也可用于 `VisionTask::initialize(path)` 和 `updateConfig(path)`；补齐模型契约及相对路径处理均由冰雪库完成。
冰雪配置中的类别编号必须为整数，letterbox/warmup必须为有效布尔值；模型参数、通道与阈值的重复键或重复别名会报错，避免静默覆盖。

## 编译

在RK3588 Ubuntu板安装构建依赖，并使用匹配的RKNN头文件与运行库：

```bash
sudo apt-get install build-essential cmake pkg-config python3 libopencv-dev \
  libgstreamer1.0-dev libgstreamer-plugins-base1.0-dev \
  gstreamer1.0-tools gstreamer1.0-plugins-base gstreamer1.0-plugins-good
cmake -S . -B build_ice -DCMAKE_BUILD_TYPE=Release -DEVS_BACKEND=rknn \
  -DEVS_WITH_OPENCV=ON -DEVS_WITH_GSTREAMER=ON \
  -DRKNN_API_INCLUDE_DIR=/path/to/rknn/include -DRKNN_API_LIB=/path/to/librknnrt.so
cmake --build build_ice -j2
ctest --test-dir build_ice --output-on-failure
cmake --install build_ice --prefix "$PWD/package_ice"
```

cmake --install不安装模型。winch_model.rknn单独提供/部署；可将配置中的Model_path改为实际模型绝对路径。
配置中的相对模型路径相对于YAML所在目录解析；若保留示例../winch_model.rknn，模型应手动放在package_ice/share/edgevision/winch_model.rknn。
load_config会返回解析后的模型绝对路径；直接构造ModelConfig时，相对路径仍按进程工作目录解析。
PC的x86_64产物不能在ARM板运行。旧离线/摄像头工具默认不参与构建；需要其原有流程时显式开启EVS_BUILD_LEGACY_TOOLS，其历史SDK路径问题另行处理。
冰雪相机demo通过目标环境的pkg-config查找GStreamer；缺少开发包时会提示并省略该目标。

模型由部署方单独放置，例如保留示例相对路径时：

```bash
cp winch_model.rknn package_ice/share/edgevision/winch_model.rknn
```

## 图片与相机demo

```bash
./package_ice/bin/ice_replay package_ice/share/edgevision/configs/winch_ice.yaml input.ppm /tmp/ice_image/run
./package_ice/bin/winch_ice_demo --task package_ice/share/edgevision/configs/winch_ice.yaml \
  --device /dev/video0 --width 1280 --height 720 --frames 100 --out /tmp/ice_camera/run
```

图片demo目前只读P6 PPM，JPEG/PNG须先转换。相机demo默认逐帧检测，无需PLC工况参数；若要验证宿主门控，可追加 `--simulate-context --angle 0 --working 1` 或 `--context-json live.json`，二者互斥。
终端输出完整候选列表、各卷扬比例和报警JSON，输出目录保存叠加图及掩码。无业务对象显示NO WINCH；有业务对象但HSV计量均无效时显示MEASUREMENT N/A；计量有效时显示ALARM或NO ALARM。该命令行demo自身不创建窗口；实时界面使用下面的可选Qt宿主。
相机采集紧凑NV12，在demo中经OpenCV转换为RGB后调用；首次等待8秒、后续3秒，实际尺寸以协商结果为准。
未指定--channel时沿用任务配置的相机通道；显式指定时必须与任务配置一致。

## 实时 Qt 界面

实时单路宿主位于`tools/winch_ice_ui/`，通过配套`Detector`动态库完成相机到界面的链路。构建选项`EVS_BUILD_ICE_UI`默认OFF，Qt依赖仅属于宿主；只构建算法库不需要Qt。

依赖准备、完整构建命令、安装包部署、设备桌面/SSH启动、通道配置、参数、快照和排障统一见[UI工具README](../tools/winch_ice_ui/README.md)。框上的百分比沿用本文的`ice_ratio`估算定义，不能将接入链路验证当作模型和计量精度验收。

## 测试和限制

无RK3588设备时，可运行内部插件像素和解码回归：

```bash
cmake -S . -B build_test -DEVS_BACKEND=mock -DEVS_WITH_OPENCV=ON -DEVS_WITH_GSTREAMER=OFF
cmake --build build_test -j2
ctest --test-dir build_test --output-on-failure
```

测试覆盖双框独立计数、重复时间戳、20%→60%→20%、错误清理、阈值更新及掩码文件；人工框仅存在于内部测试，不能通过正式Detector注入。
公开只读掩码诊断供demo展示使用。掩码和逐对象结果由任务内唯一的冰雪插件持有，公共插件接口不包含这些专用类型。无模型、错误模型或无RKNN SDK时正式检测明确失败；mock测试不代表真实模型推理。
当前源码按单类YOLOX原始 `[1,8400,6]`解析：tx/ty/tw/th、目标概率、类别概率，按stride8/16/32网格解码，置信度为后两项相乘。架构整改前的RK3588单图记录中，这一解释与独立数学解码核对一致。
HSV默认S≤80、V≥180并执行3×3开闭运算，只是颜色粗估；反光/背景可误计，暗雪/透明冰可漏计，框内支架背景也计入分母。
此前小样本板测曾确认漏检和无雪图误计，不能据此宣称精度通过。2026-10-21 13:41阶段的RK3588真实单图记录得到一框(116,224,513,341)、置信度约0.8669；独立解码与当时正式API差异0像素，框内候选占比17.83%，50%阈值不报警。模型框未覆盖上方部分积雪，HSV又漏计部分灰暗雪面，单图不构成精度验收。
该次上板后，任务、插件和客户API内部进行了架构整改；像素计量实现保持，但早期板测不能替代最新版本验收。当时的架构检查覆盖主机回归、SDK模拟及旧插件兼容验证；该阶段四组构建关闭GStreamer，不覆盖相机demo目标。历史相机模拟也不代表真实取流通过。
架构和主机验证范围见[插件架构说明](plugin_architecture.md)。后续Qt宿主已完成通道0的真实相机链路和短时连续检测验证，范围见[UI工具README](../tools/winch_ice_ui/README.md)；其他物理通道、多场景精度及长期稳定性仍待验收。

## 架构与兼容性

功能仍登记为0x0008，算法及客户适配均在libevs_ice。公共任务不判断冰雪功能号。原IFunctionPlugin虚表及TaskConfig布局恢复到137a845；冰雪HSV配置保存在插件实例内。公共TaskConfig保持历史默认值，客户DetectConfig与冰雪YAML的报警阈值仍为0.5。

原有插件可继续实现configure/decide/reset等原接口。新功能若需要文件专属参数、配置校验或失败清理，可选用独立的配置登记及任务扩展接口；不改原接口布局。具体见[插件架构说明](plugin_architecture.md)。

纯VisionTask动态宿主应确保冰雪库实际加载，例如Linux链接时使用 `-Wl,--no-as-needed -levs_ice -Wl,--as-needed -levs_core`。只在命令中写库名可能被链接器裁掉。客户Detector直接引用冰雪库符号，仍按原方式链接即可。静态宿主继续整库保留所需登记对象。

配置归一化只在加载冰雪库后生效。部署时应使用本轮配套核心和功能库，不能混入整改前工作区按过渡虚表编译的产物；已验证兼容的旧人员/高度插件范围为Git基线137a845、本机同一C++工具链。主机兼容和SDK模拟验证不代替真实RKNN模型上板验收。
