#include "camera_source.h"
#include <QGuiApplication>
#include <QFile>
#include <QJsonArray>
#include <QJsonDocument>
#include <QTemporaryDir>
#include <gst/video/video.h>
#include <cstring>
#include <future>
#include <iostream>
#include <stdexcept>

namespace {
int checks = 0;
void check(bool condition, const char* message) {
    ++checks;
    if (!condition) throw std::runtime_error(message);
}
template <class F> void rejected(F action, const char* message) {
    bool threw = false;
    try { action(); } catch (const std::exception&) { threw = true; }
    check(threw, message);
}
void write(const QString& path, const QJsonArray& array) {
    QFile file(path);
    check(file.open(QIODevice::WriteOnly), "open config fixture");
    check(file.write(QJsonDocument(array).toJson()) > 0, "write config fixture");
}
QJsonObject camera(int channel, bool enabled = true) {
    return {{"device", QStringLiteral("/dev/video%1").arg(channel + 3)},
        {"channel", channel}, {"enable", enabled}, {"width", 1920},
        {"height", 1080}, {"framerate", 25}};
}
void cameraConfiguration() {
    QTemporaryDir temporary;
    const auto path = temporary.filePath("cameras.json");
    write(path, {camera(7), camera(2, false), camera(0)});
    const auto entries = ice_ui::loadCameras(path);
    check(ice_ui::selectCamera(entries, 0).device == "/dev/video3", "select by channel, not array index");
    rejected([&] { ice_ui::selectCamera(entries, 1); }, "missing channel must not fall back");
    rejected([&] { ice_ui::selectCamera(entries, 2); }, "explicit disabled channel must not open");
    write(path, {camera(0), camera(0, false)});
    rejected([&] { ice_ui::loadCameras(path); }, "duplicate channel rejected");
    auto invalid = camera(0);
    invalid["channel"] = .5;
    write(path, {invalid});
    rejected([&] { ice_ui::loadCameras(path); }, "fractional channel rejected");
    invalid = camera(0);
    invalid["enable"] = "true";
    write(path, {invalid});
    rejected([&] { ice_ui::loadCameras(path); }, "string bool rejected");
    invalid = camera(0);
    invalid["framerate"] = 0;
    write(path, {invalid});
    rejected([&] { ice_ui::loadCameras(path); }, "zero frame rate rejected");
    invalid = camera(0);
    invalid["device"] = "video0";
    write(path, {invalid});
    rejected([&] { ice_ui::loadCameras(path); }, "relative device path cannot depend on working directory");
}
void rgbSample(bool videoMetadata) {
    constexpr int width = 3, height = 2;
    const int stride = videoMetadata ? 16 : 12;
    const size_t offset = videoMetadata ? 7 : 0;
    const auto bytes = offset + size_t(stride) * height;
    auto* buffer = gst_buffer_new_allocate(nullptr, bytes, nullptr);
    GstMapInfo memory;
    check(gst_buffer_map(buffer, &memory, GST_MAP_WRITE), "map RGB fixture");
    std::memset(memory.data, 0xfa, memory.size);
    std::vector<uint8_t> expected;
    for (int y = 0; y < height; ++y)
        for (int x = 0; x < width * 3; ++x) {
            const uint8_t value = uint8_t(1 + y * width * 3 + x);
            memory.data[offset + size_t(y) * stride + x] = value;
            expected.push_back(value);
        }
    gst_buffer_unmap(buffer, &memory);
    if (videoMetadata) {
        gsize offsets[GST_VIDEO_MAX_PLANES] = {offset, 0, 0, 0};
        gint strides[GST_VIDEO_MAX_PLANES] = {stride, 0, 0, 0};
        check(gst_buffer_add_video_meta_full(buffer, GST_VIDEO_FRAME_FLAG_NONE,
            GST_VIDEO_FORMAT_RGB, width, height, 1, offsets, strides), "add explicit stride/offset metadata");
    }
    auto* caps = gst_caps_new_simple("video/x-raw", "format", G_TYPE_STRING, "RGB",
        "width", G_TYPE_INT, width, "height", G_TYPE_INT, height,
        "framerate", GST_TYPE_FRACTION, 25, 1, nullptr);
    auto* sample = gst_sample_new(buffer, caps, nullptr, nullptr);
    const auto frame = ice_ui::CameraSource::fromSample(sample);
    gst_sample_unref(sample);
    gst_buffer_unref(buffer);
    gst_caps_unref(caps);
    check(frame->pixels == expected, "RGB rows and offsets packed correctly after sample release");
    check(frame->width == width && frame->height == height, "negotiated dimensions preserved");
    rejected([&] { ice_ui::packRgb(expected.data(), expected.size() - 1, width, height, width * 3); },
        "short RGB buffer rejected");
    rejected([&] { ice_ui::packRgb(expected.data(), expected.size(), width, height, width * 3 - 1); },
        "short RGB row stride rejected");
}
void mailbox() {
    ice_ui::LatestMailbox<int> input;
    input.put(std::make_shared<int>(1));
    input.put(std::make_shared<int>(2));
    check(*input.take() == 2, "latest frame replaces pending old frame");
    check(!input.take(), "reading consumes pending frame; no duplicate sequence");
    auto waiter = std::async(std::launch::async, [&] { return input.take(5000); });
    input.close();
    check(waiter.wait_for(std::chrono::milliseconds(500)) == std::future_status::ready,
          "stop wakes a waiting consumer");
    check(!waiter.get(), "closed empty input has no stale frame");
    check(!input.put(std::make_shared<int>(3)), "closed session rejects late frame");
}
void resultAndSnapshot() {
    using namespace evs::winch_ice;
    ice_ui::Observation frame;
    frame.session = 42;
    frame.sequence = 9007199254740993ULL;
    frame.channel = 7;
    frame.image = QImage(300, 200, QImage::Format_RGB888);
    frame.image.fill(QColor("#203040"));
    check(ice_ui::resultText(frame).contains("NO RESULT"), "empty objects are not normal 0 percent");
    WinchObjectResult object;
    object.box = {0, .8f, 10, 20, 70, 80};
    frame.result.objects.push_back(object);
    check(ice_ui::resultText(frame).contains("N/A"), "invalid object not displayed as normal");
    auto json = ice_ui::observationJson(frame);
    check(json["frame_seq"].toString() == "9007199254740993", "64 bit frame identity does not lose JSON precision");
    check(json["objects"].toArray()[0].toObject()["ice_ratio"].isNull(), "unknown ratio serialized as null");
    frame.result.objects[0].valid = true;
    frame.result.objects[0].ice_ratio = .2f;
    check(ice_ui::objectLabel(1, frame.result.objects[0]) == QStringLiteral("#1  框内冰雪估算 20.0%"),
          "overlay distinguishes estimated ice ratio from localization confidence");
    check(ice_ui::objectLabel(2, object).endsWith("N/A"), "invalid label never invents zero coverage");
    check(ice_ui::resultColor(frame) == "#22C55E", "valid below-threshold frame is green");
    WinchObjectResult other;
    other.box = {0, .9f, 120, 20, 70, 80};
    frame.result.objects.push_back(other);
    check(ice_ui::resultText(frame).contains("部分"), "one valid object does not hide an invalid second object");
    frame.result.objects[1].valid = true;
    frame.result.objects[1].ice_ratio = .6f;
    frame.result.alert_level = AlertLevel::ALERT_WARN;
    check(ice_ui::resultColor(frame) == "#EF4444", "library alarm mapped explicitly");
    json = ice_ui::observationJson(frame);
    check(json["ice_ratio_basis"].toString() == "candidate_pixels / detection_box_pixels",
          "snapshot records the denominator of the estimated coverage");
    check(json["objects"].toArray().size() == 2 &&
          json["objects"].toArray()[1].toObject()["box"].toObject()["x"].toInt() == 120,
          "two objects retain independent original-pixel boxes");
    frame.status = 1;
    check(ice_ui::resultText(frame).contains("错误"), "API error overrides earlier alarm");
    frame.status = 0;
    frame.result.alert_level = AlertLevel::ALERT_NONE;
    frame.result.objects[1].ice_ratio = .1f;
    QTemporaryDir directory;
    const auto prefix = ice_ui::saveSnapshot(directory.path(), frame);
    QFile result(prefix + "_result.json");
    check(result.open(QIODevice::ReadOnly), "snapshot manifest saved");
    json = QJsonDocument::fromJson(result.readAll()).object();
    check(json["camera_channel"].toInt() == 7 && json["frame_seq"].toString() == "9007199254740993",
          "snapshot metadata retains the displayed observation identity");
    check(QImage(prefix + "_original.png").convertToFormat(frame.image.format()) == frame.image,
          "snapshot decoded pixels belong to same frame regardless of PNG decoder storage format");
    check(!QImage(prefix + "_overlay.png").isNull(), "snapshot overlay decodes");
    check(ice_ui::fittedRect(QRectF(0, 0, 800, 600), QSize(1920, 1080)) == QRectF(0, 75, 800, 450),
          "display includes centered letterbox offset");
}
} // namespace

int main(int argc, char** argv) {
    QGuiApplication app(argc, argv);
    gst_init(nullptr, nullptr);
    try {
        cameraConfiguration();
        rgbSample(false);
        rgbSample(true);
        mailbox();
        resultAndSnapshot();
        std::cout << "PASS=" << checks << " FAIL=0\n";
        return 0;
    } catch (const std::exception& ex) {
        std::cerr << "FAIL after " << checks << " checks: " << ex.what() << '\n';
        return 1;
    }
}
