#include "ui_support.h"
#include <QDateTime>
#include <QDir>
#include <QFile>
#include <QJsonArray>
#include <QJsonDocument>
#include <QJsonParseError>
#include <QSaveFile>
#include <QSet>
#include <QUuid>
#include <algorithm>
#include <cmath>
#include <cstring>
#include <limits>
#include <stdexcept>

namespace ice_ui {
namespace {
[[noreturn]] void fail(const QString& message) {
    throw std::runtime_error(message.toStdString());
}
int integer(const QJsonObject& object, const char* key, int minimum, int maximum) {
    const auto value = object.value(QLatin1String(key));
    const auto number = value.toDouble(std::numeric_limits<double>::quiet_NaN());
    if (!value.isDouble() || !std::isfinite(number) || std::floor(number) != number ||
        number < minimum || number > maximum)
        fail(QStringLiteral("相机配置字段 %1 必须是 %2～%3 的整数").arg(key).arg(minimum).arg(maximum));
    return int(number);
}
bool usable(const evs::winch_ice::WinchObjectResult& object) {
    return object.valid && std::isfinite(object.ice_ratio) &&
           object.ice_ratio >= 0 && object.ice_ratio <= 1;
}
bool failed(const Observation& frame) { return frame.status != 0 || !frame.error.isEmpty(); }
void saveImage(const QString& path, const QImage& image) {
    QSaveFile file(path);
    if (!file.open(QIODevice::WriteOnly) || !image.save(&file, "PNG") || !file.commit())
        fail(QStringLiteral("保存图片失败：%1 (%2)").arg(path, file.errorString()));
}
} // namespace

std::vector<CameraConfig> loadCameras(const QString& path) {
    QFile file(path);
    if (!file.open(QIODevice::ReadOnly)) fail(QStringLiteral("无法读取相机配置：%1").arg(path));
    QJsonParseError error;
    const auto doc = QJsonDocument::fromJson(file.readAll(), &error);
    if (error.error != QJsonParseError::NoError || !doc.isArray())
        fail(QStringLiteral("相机配置必须是 JSON 数组：%1").arg(error.errorString()));
    std::vector<CameraConfig> cameras;
    QSet<int> seen;
    for (const auto& value : doc.array()) {
        if (!value.isObject()) fail(QStringLiteral("相机配置条目必须是对象"));
        const auto object = value.toObject();
        CameraConfig camera;
        camera.channel = integer(object, "channel", 0, 254);
        if (seen.contains(camera.channel)) fail(QStringLiteral("相机通道重复：%1").arg(camera.channel));
        seen.insert(camera.channel);
        if (!object.value("device").isString() || !QDir::isAbsolutePath(object.value("device").toString()) ||
            object.value("device").toString().contains(QChar(0)))
            fail(QStringLiteral("相机 device 必须是绝对设备路径"));
        camera.device = object.value("device").toString();
        if (!object.value("enable").isBool()) fail(QStringLiteral("相机 enable 必须是布尔值"));
        camera.enabled = object.value("enable").toBool();
        camera.width = integer(object, "width", 2, 16384);
        camera.height = integer(object, "height", 2, 16384);
        if (uint64_t(camera.width) * camera.height > 100000000)
            fail(QStringLiteral("相机图像尺寸过大"));
        camera.fps = integer(object, "framerate", 1, 240);
        cameras.push_back(std::move(camera));
    }
    if (cameras.empty()) fail(QStringLiteral("相机配置为空"));
    return cameras;
}

const CameraConfig& selectCamera(const std::vector<CameraConfig>& cameras, int channel) {
    for (const auto& camera : cameras) {
        if (camera.channel != channel) continue;
        if (!camera.enabled) fail(QStringLiteral("相机通道 %1 已禁用").arg(channel));
        return camera;
    }
    fail(QStringLiteral("相机通道 %1 不存在，不会回退到其他相机").arg(channel));
}

qint64 monotonicMs() {
    return std::chrono::duration_cast<std::chrono::milliseconds>(
               std::chrono::steady_clock::now().time_since_epoch()).count();
}

std::vector<uint8_t> packRgb(const uint8_t* source, size_t sourceBytes,
                             int width, int height, int stride) {
    if (!source || width < 1 || height < 1 || width > 16384 || height > 16384 ||
        uint64_t(width) * height > 100000000 || stride < int64_t(width) * 3)
        fail(QStringLiteral("无效的 RGB 图像尺寸或行跨度"));
    const auto rowBytes = size_t(width) * 3;
    const auto required = size_t(height - 1) * size_t(stride) + rowBytes;
    if (sourceBytes < required) fail(QStringLiteral("RGB 缓冲长度不足"));
    std::vector<uint8_t> packed(rowBytes * size_t(height));
    for (int y = 0; y < height; ++y)
        std::memcpy(packed.data() + size_t(y) * rowBytes,
                    source + size_t(y) * size_t(stride), rowBytes);
    return packed;
}

QString resultText(const Observation& frame) {
    if (failed(frame)) return frame.error.isEmpty()
        ? QStringLiteral("检测错误 0x%1").arg(frame.status, 8, 16, QLatin1Char('0')) : frame.error;
    if (frame.result.alert_level == evs::winch_ice::AlertLevel::ALERT_WARN)
        return QStringLiteral("冰雪报警");
    if (frame.result.objects.empty()) return QStringLiteral("未检测到卷扬 · NO RESULT");
    size_t valid = 0;
    for (const auto& object : frame.result.objects) valid += usable(object) ? 1 : 0;
    if (!valid) return QStringLiteral("卷扬结果无效 · N/A");
    if (valid != frame.result.objects.size()) return QStringLiteral("部分卷扬结果无效");
    return QStringLiteral("本帧未报警");
}

QString resultColor(const Observation& frame) {
    if (failed(frame)) return QStringLiteral("#EF4444");
    if (frame.result.alert_level == evs::winch_ice::AlertLevel::ALERT_WARN)
        return QStringLiteral("#EF4444");
    if (frame.result.objects.empty() ||
        std::any_of(frame.result.objects.begin(), frame.result.objects.end(),
                    [](const auto& object) { return !usable(object); }))
        return QStringLiteral("#FBBF24");
    return QStringLiteral("#22C55E");
}

QString objectLabel(size_t index, const evs::winch_ice::WinchObjectResult& object) {
    return QStringLiteral("#%1  框内冰雪估算 %2").arg(qulonglong(index)).arg(usable(object)
        ? QString::number(object.ice_ratio * 100, 'f', 1) + "%" : "N/A");
}

QJsonObject observationJson(const Observation& frame) {
    QJsonArray objects;
    for (const auto& object : frame.result.objects) {
        const auto& box = object.box;
        objects.append(QJsonObject{{"valid", usable(object)},
            {"ice_ratio", usable(object) ? QJsonValue(double(object.ice_ratio)) : QJsonValue(QJsonValue::Null)},
            {"box", QJsonObject{{"x", double(box.x)}, {"y", double(box.y)},
                {"width", double(box.width)}, {"height", double(box.height)},
                {"class_id", double(box.class_id)}, {"confidence", double(box.confidence)}}}});
    }
    return {{"session", QString::number(frame.session)}, {"frame_seq", QString::number(frame.sequence)},
        {"camera_channel", frame.channel}, {"width", frame.image.width()}, {"height", frame.image.height()},
        {"captured_monotonic_ms", QString::number(frame.capturedMs)},
        {"completed_monotonic_ms", QString::number(frame.completedMs)},
        {"status", double(frame.status)}, {"error", frame.error}, {"state", resultText(frame)},
        {"result_code", int(frame.result.result_code)}, {"alert_level", int(frame.result.alert_level)},
        {"area_ratio_threshold", double(frame.threshold)},
        {"ice_ratio_basis", "candidate_pixels / detection_box_pixels"},
        {"object_identity", "frame_local_index"}, {"detect_ms", frame.detectMs},
        {"inference_time_ms", double(frame.result.inference_time_ms)}, {"objects", objects}};
}

QRectF fittedRect(const QRectF& area, const QSize& image) {
    if (image.isEmpty() || area.isEmpty()) return {};
    const auto size = QSizeF(image).scaled(area.size(), Qt::KeepAspectRatio);
    return QRectF(area.center() - QPointF(size.width() / 2, size.height() / 2), size);
}

void paintObservation(QPainter& painter, const QRectF& area, const Observation& frame) {
    if (frame.image.isNull()) return;
    painter.save();
    painter.setClipRect(area);
    const auto target = fittedRect(area, frame.image.size());
    painter.drawImage(target, frame.image);
    if (failed(frame)) { painter.restore(); return; }
    const double scale = target.width() / frame.image.width();
    QFont font = painter.font();
    font.setPixelSize(qBound(12, int(target.width() / 65), 24));
    font.setBold(true);
    painter.setFont(font);
    int index = 0;
    for (const auto& object : frame.result.objects) {
        ++index;
        const bool valid = usable(object);
        const QColor color(!valid ? "#FBBF24" : object.ice_ratio >= frame.threshold ? "#EF4444" : "#22C55E");
        const auto& box = object.box;
        QRectF rectangle(target.left() + box.x * scale, target.top() + box.y * scale,
                         box.width * scale, box.height * scale);
        rectangle = rectangle.intersected(target);
        if (rectangle.isEmpty()) continue;
        painter.setBrush(Qt::NoBrush);
        painter.setPen(QPen(color, 3, valid ? Qt::SolidLine : Qt::DashLine));
        painter.drawRect(rectangle);
        const auto label = objectLabel(size_t(index), object);
        auto labelRect = QRectF(painter.fontMetrics().boundingRect(label));
        labelRect.setSize(labelRect.size() + QSizeF(16, 10));
        labelRect.moveTopLeft(QPointF(qBound(target.left(), rectangle.left(),
                                            qMax(target.left(), target.right() - labelRect.width())),
                                     qMax(target.top(), rectangle.top() - labelRect.height())));
        painter.fillRect(labelRect, QColor(0, 0, 0, 200));
        painter.setPen(color);
        painter.drawText(labelRect, Qt::AlignCenter, label);
    }
    painter.restore();
}

QString saveSnapshot(const QString& directory, const Observation& frame) {
    if (frame.image.isNull()) fail(QStringLiteral("没有可保存的图像"));
    if (!QDir().mkpath(directory)) fail(QStringLiteral("无法创建快照目录：%1").arg(directory));
    const auto stem = QDateTime::currentDateTime().toString("yyyyMMdd_HHmmss_zzz") +
        QStringLiteral("_ch%1_frame%2_").arg(frame.channel).arg(qulonglong(frame.sequence)) +
        QUuid::createUuid().toString(QUuid::Id128).left(8);
    const auto prefix = QDir(directory).absoluteFilePath(stem);
    auto overlay = frame.image.copy();
    QPainter painter(&overlay);
    paintObservation(painter, QRectF(overlay.rect()), frame);
    painter.end();
    saveImage(prefix + "_original.png", frame.image);
    saveImage(prefix + "_overlay.png", overlay);
    QSaveFile metadata(prefix + "_result.json");
    const auto json = QJsonDocument(observationJson(frame)).toJson(QJsonDocument::Indented);
    if (!metadata.open(QIODevice::WriteOnly) || metadata.write(json) != json.size() || !metadata.commit())
        fail(QStringLiteral("保存快照 JSON 失败：%1").arg(metadata.errorString()));
    return prefix;
}
} // namespace ice_ui
