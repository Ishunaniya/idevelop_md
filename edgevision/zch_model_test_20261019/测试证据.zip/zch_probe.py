#!/usr/bin/env python3
"""RK3588 model I/O probe and explicit, provisional one-class YOLOX image test.
Calls librknnrt directly; does not depend on the installed old RKNNLite wrapper.
"""
import argparse
import ctypes as C
import hashlib
import json
from pathlib import Path
import time
import numpy as np

class IO(C.Structure):
    _fields_=[('n_input',C.c_uint32),('n_output',C.c_uint32)]
class Attr(C.Structure):
    _fields_=[('index',C.c_uint32),('n_dims',C.c_uint32),('dims',C.c_uint32*16),
              ('name',C.c_char*256),('n_elems',C.c_uint32),('size',C.c_uint32),
              ('fmt',C.c_int),('type',C.c_int),('qnt_type',C.c_int),('fl',C.c_int8),
              ('zp',C.c_int32),('scale',C.c_float),('w_stride',C.c_uint32),
              ('size_with_stride',C.c_uint32),('pass_through',C.c_uint8),('h_stride',C.c_uint32)]
class Version(C.Structure):
    _fields_=[('api_version',C.c_char*256),('drv_version',C.c_char*256)]
class Input(C.Structure):
    _fields_=[('index',C.c_uint32),('buf',C.c_void_p),('size',C.c_uint32),
              ('pass_through',C.c_uint8),('type',C.c_int),('fmt',C.c_int)]
class Output(C.Structure):
    _fields_=[('want_float',C.c_uint8),('is_prealloc',C.c_uint8),('index',C.c_uint32),
              ('buf',C.c_void_p),('size',C.c_uint32)]

def check(code, name):
    if code != 0: raise RuntimeError(f'{name} failed: {code}')

def attr_dict(a):
    return dict(index=a.index,name=a.name.decode(errors='replace'),dims=list(a.dims)[:a.n_dims],
                n_elems=a.n_elems,size=a.size,fmt=a.fmt,type=a.type,qnt_type=a.qnt_type,
                zp=a.zp,scale=a.scale,size_with_stride=a.size_with_stride)

class Model:
    def __init__(self,path):
        self.lib=C.CDLL('/usr/lib/librknnrt.so')
        ctx=C.c_uint64
        specs={'rknn_init':([C.POINTER(ctx),C.c_void_p,C.c_uint32,C.c_uint32,C.c_void_p]),
               'rknn_query':([ctx,C.c_int,C.c_void_p,C.c_uint32]),
               'rknn_inputs_set':([ctx,C.c_uint32,C.POINTER(Input)]),
               'rknn_run':([ctx,C.c_void_p]),
               'rknn_outputs_get':([ctx,C.c_uint32,C.POINTER(Output),C.c_void_p]),
               'rknn_outputs_release':([ctx,C.c_uint32,C.POINTER(Output)]),
               'rknn_destroy':([ctx])}
        for name,args in specs.items():
            fn=getattr(self.lib,name);fn.argtypes=args;fn.restype=C.c_int
        self.ctx=ctx()
        data=Path(path).read_bytes()
        self.model_data=C.create_string_buffer(data)
        check(self.lib.rknn_init(C.byref(self.ctx),self.model_data,len(data),0,None),'rknn_init')
        try:
            io=IO();self.query(0,io)
            if io.n_input!=1 or not 1<=io.n_output<=32:raise RuntimeError(f'Unsupported IO count {io.n_input}/{io.n_output}')
            self.ins=[];self.outs=[]
            for cmd,count,dst in [(1,io.n_input,self.ins),(2,io.n_output,self.outs)]:
                for i in range(count):
                    a=Attr();a.index=i;self.query(cmd,a)
                    if not 1<=a.n_dims<=16 or np.prod(list(a.dims)[:a.n_dims],dtype=np.int64)!=a.n_elems:
                        raise RuntimeError('Unexpected tensor metadata')
                    dst.append(a)
            v=Version();self.query(5,v)
            self.metadata=dict(model=str(Path(path).resolve()),sha256=hashlib.sha256(data).hexdigest(),
                               api_version=v.api_version.decode(),driver_version=v.drv_version.decode(),
                               inputs=[attr_dict(a) for a in self.ins],outputs=[attr_dict(a) for a in self.outs])
        except BaseException:
            self.close();raise
    def query(self,cmd,obj):
        check(self.lib.rknn_query(self.ctx,cmd,C.byref(obj),C.sizeof(obj)),f'rknn_query({cmd})')
    def infer(self,array):
        array=np.ascontiguousarray(array,dtype=np.float32)
        a=self.ins[0]
        if array.size!=a.n_elems:raise ValueError('Input element count differs from model')
        ri=Input(index=0,buf=array.ctypes.data,size=array.nbytes,pass_through=0,type=0,fmt=1)
        check(self.lib.rknn_inputs_set(self.ctx,1,C.byref(ri)),'rknn_inputs_set')
        start=time.perf_counter()
        check(self.lib.rknn_run(self.ctx,None),'rknn_run')
        outputs=(Output*len(self.outs))()
        for i,o in enumerate(outputs):o.index=i;o.want_float=1
        check(self.lib.rknn_outputs_get(self.ctx,len(outputs),outputs,None),'rknn_outputs_get')
        try:
            copied=[]
            for o,a in zip(outputs,self.outs):
                if not o.buf or o.size<a.n_elems*4:raise RuntimeError('Output buffer too short')
                copied.append(np.ctypeslib.as_array(C.cast(o.buf,C.POINTER(C.c_float)),shape=(a.n_elems,)).copy().reshape(tuple(a.dims)[:a.n_dims]))
            return copied,(time.perf_counter()-start)*1000
        finally:check(self.lib.rknn_outputs_release(self.ctx,len(outputs),outputs),'rknn_outputs_release')
    def close(self):
        if self.ctx.value:
            check(self.lib.rknn_destroy(self.ctx),'rknn_destroy');self.ctx.value=0

def decode_one_class(pred,layout,thr,iou):
    rows=np.asarray(pred,dtype=np.float32)
    if rows.shape!=(1,8400,6):raise ValueError(f'Expected (1,8400,6), got {rows.shape}')
    rows=rows[0].copy()
    if not np.isfinite(rows).all():raise ValueError('Non-finite output')
    scores=rows[:,4]*rows[:,5]
    if (rows[:,4:] < -1e-5).any() or (rows[:,4:] > 1.00001).any():
        raise ValueError('Objectness/class are not probabilities; confirm model activation before decoding')
    if layout=='raw':
        grids=[];strides=[]
        for s in (8,16,32):
            y,x=np.meshgrid(np.arange(640//s),np.arange(640//s),indexing='ij')
            grids.append(np.stack((x,y),axis=-1).reshape(-1,2));strides.extend([s]*x.size)
        stride=np.asarray(strides)[:,None]
        rows[:,:2]=(rows[:,:2]+np.concatenate(grids))*stride
        rows[:,2:4]=np.exp(np.clip(rows[:,2:4],-20,20))*stride
    xyxy=np.column_stack((rows[:,:2]-rows[:,2:4]/2,rows[:,:2]+rows[:,2:4]/2))
    valid=(scores>=thr)&(rows[:,2]>0)&(rows[:,3]>0)
    boxes=xyxy[valid];scores=scores[valid]
    order=np.argsort(-scores);keep=[]
    while order.size:
        i=order[0];keep.append(i)
        rest=order[1:]
        tl=np.maximum(boxes[i,:2],boxes[rest,:2]);br=np.minimum(boxes[i,2:],boxes[rest,2:])
        wh=np.maximum(0,br-tl);inter=wh[:,0]*wh[:,1]
        area=np.prod(boxes[:,2:]-boxes[:,:2],axis=1)
        overlap=inter/np.maximum(area[i]+area[rest]-inter,1e-12)
        order=rest[overlap<=iou]
    return boxes[keep],scores[keep]

def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--model',required=True)
    parser.add_argument('--image',help='file or directory; omit to query metadata only')
    parser.add_argument('--out',required=True,help='new output directory, must not already exist')
    parser.add_argument('--color',choices=['rgb','bgr'],default='bgr')
    parser.add_argument('--scale',type=float,choices=[1.0,1.0/255.0],default=1.0)
    parser.add_argument('--layout',choices=['raw','decoded'],default='raw',help='explicit YOLOX output convention; confirm with algorithm author')
    parser.add_argument('--threshold',type=float,default=.25)
    parser.add_argument('--iou',type=float,default=.5)
    parser.add_argument('--limit',type=int,default=5)
    args=parser.parse_args()
    if not 0<=args.threshold<=1 or not 0<args.iou<=1 or args.limit<1:parser.error('Invalid threshold, iou or limit')
    out=Path(args.out);out.mkdir(parents=True,exist_ok=False)
    model=Model(args.model)
    try:
        (out/'metadata.json').write_text(json.dumps(model.metadata,indent=2))
        print(json.dumps(model.metadata,indent=2),flush=True)
        if not args.image:return
        import cv2
        shape=model.metadata['inputs'][0]['dims']
        if shape not in ([1,3,640,640],[1,640,640,3]):raise ValueError(f'Unsupported input shape {shape}')
        src=Path(args.image)
        images=sorted(p for p in src.iterdir() if p.suffix.lower() in ('.jpg','.jpeg','.png','.ppm','.bmp'))[:args.limit] if src.is_dir() else [src]
        if not images:raise ValueError('No images')
        summary=[]
        for index,p in enumerate(images):
            image=cv2.imdecode(np.fromfile(str(p),dtype=np.uint8),cv2.IMREAD_COLOR)
            if image is None:raise ValueError(f'Cannot read {p}')
            h,w=image.shape[:2];r=min(640/w,640/h)
            nw,nh=int(w*r),int(h*r)
            # Provisional YOLOX convention: resize then place at top left; pad 114.
            canvas=np.full((640,640,3),114,dtype=np.uint8)
            canvas[:nh,:nw]=cv2.resize(image,(nw,nh),interpolation=cv2.INTER_LINEAR)
            if args.color=='rgb':canvas=cv2.cvtColor(canvas,cv2.COLOR_BGR2RGB)
            inputs=canvas.astype(np.float32)[None]*args.scale
            tensors,ms=model.infer(inputs)
            if len(tensors)!=1:raise ValueError('Expected one YOLOX output')
            raw=tensors[0];np.save(out/f'{index:03d}_output.npy',raw)
            rows=raw.reshape(-1,6)
            stats=dict(min=rows.min(axis=0).tolist(),max=rows.max(axis=0).tolist(),first=rows[:3].tolist())
            boxes,scores=decode_one_class(raw,args.layout,args.threshold,args.iou)
            boxes/=r
            boxes[:,[0,2]]=np.clip(boxes[:,[0,2]],0,w)
            boxes[:,[1,3]]=np.clip(boxes[:,[1,3]],0,h)
            valid=(boxes[:,2]>boxes[:,0])&(boxes[:,3]>boxes[:,1]);boxes=boxes[valid];scores=scores[valid]
            dets=[]
            for box,score in zip(boxes,scores):
                x1,y1,x2,y2=np.rint(box).astype(int)
                cv2.rectangle(image,(x1,y1),(x2,y2),(0,0,255),2)
                cv2.putText(image,f'class0 {score:.3f}',(x1,max(15,y1-4)),cv2.FONT_HERSHEY_SIMPLEX,.6,(0,0,255),2)
                dets.append(dict(class_id=0,score=float(score),xyxy=box.tolist()))
            ok,encoded=cv2.imencode('.jpg',image)
            if not ok:raise RuntimeError('Image encode failed')
            encoded.tofile(str(out/f'{index:03d}_boxes.jpg'))
            entry=dict(image=str(p),input_color=args.color,input_scale=args.scale,output_layout=args.layout,
                       padding='top-left,114',run_and_output_ms=ms,stats=stats,detections=dets)
            summary.append(entry)
            print(f'{p.name}: shape={raw.shape}, max_obj={rows[:,4].max():.6f}, max_score={(rows[:,4]*rows[:,5]).max():.6f}, boxes={len(dets)}, run+get={ms:.2f}ms',flush=True)
        (out/'results.json').write_text(json.dumps(summary,indent=2))
    finally:model.close()

if __name__=='__main__':main()
