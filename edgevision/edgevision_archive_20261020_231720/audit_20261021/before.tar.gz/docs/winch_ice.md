# 卷扬冰雪接入说明

正式配置是 `configs/winch_ice.yaml`，模型是仓库根目录的 `ice_model.rknn`，目标板为RK3588 Ubuntu。
重锤模型不用于卷扬。库名保持 `libevs_core.so.3`、`libevs_ice.so.3` 及对应静态库；宿主、插件须使用配套头文件重新编译。

## 接口和结果

初始化加载模型一次；每次 `detect(image, result)` 处理当前一帧，包括重复时间戳。
一个实例绑定一路相机，各方法串行调用。宿主负责取图、工况、重试和报警保持。

```text
原图 → RKNN模型定位卷扬 → 框还原到原图 → 分别统计框内HSV冰雪候选
ice_ratio = snow_pixels / surface_pixels
surface_pixels = 原图矩形框 width × height
本帧全局报警 = 任一有效卷扬 ice_ratio >= area_ratio（默认0.5）
```

逐对象返回 `box`、`surface_pixels`、`snow_pixels`、`ice_ratio`、`valid/status/reason`。
按框中心从左到右编号，编号仅对本帧有效。调用错误清空对象与报警，不使用上一帧结果。
调用返回值为0也须检查对象有效性：无框返回空对象；无效比例为-1，不能当作正常0%。
当前保留最多两个候选、交叠框无效、小于3×3的框无效及极暗/均匀过曝白无效规则；这些质量策略仍待现场确认。

```cpp
#include <evs/winch_ice.h>
using namespace evs::winch_ice;
WinchSnowConfig cfg;
auto rc = load_config("configs/winch_ice.yaml", cfg);
Detector detector;
if (!rc) rc = detector.initialize(cfg);
// 初始化成功后，宿主对每帧执行：
ImageData image;
// 填写data、width、height、format、channels、stride、size_bytes。
WinchSnowResult result;
// rc = detector.detect(image, result);
// 检查rc及objects[i].valid，再读取比例和result.alert_level。
```

RGB/BGR为3通道；NV12为1通道，宽高和stride须为偶数，UV紧随Y并使用同一stride。
stride=0表示紧凑布局；size_bytes非零时校验缓冲区长度；灰度不支持。
调用期间图像内存须有效，库不保存图像指针。updateConfig仅热更新面积、HSV、置信度和NMS阈值；更换模型、输入布局或相机需释放并重新初始化。
正式路径始终要求模型，无人工框或固定区域回退。旧 `ice_mode:model`、`inference_enabled:true` 可读，其他旧模式/几何配置拒绝。
配置采用平铺Model_path/input_width/input_height等键；本次不扩展通用模型map解析。

## 编译

在RK3588 Ubuntu板安装构建依赖，并使用匹配的RKNN头文件与运行库：

```bash
sudo apt-get install build-essential cmake pkg-config python3 libopencv-dev \
  libgstreamer1.0-dev libgstreamer-plugins-base1.0-dev \
  gstreamer1.0-tools gstreamer1.0-plugins-base gstreamer1.0-plugins-good
cmake -S . -B build_ice -DCMAKE_BUILD_TYPE=Release -DEVS_BACKEND=rknn \
  -DEVS_WITH_OPENCV=ON -DEVS_WITH_GSTREAMER=ON \
  -DRKNN_API_INCLUDE_DIR=/path/to/rknn/include -DRKNN_API_LIB=/path/to/librknnrt.so
cmake --build build_ice -j2
ctest --test-dir build_ice --output-on-failure
cmake --install build_ice --prefix "$PWD/package_ice"
```

模型不自动复制到安装包。命令在仓库根目录执行，或把配置中的Model_path改为板上绝对路径。
PC的x86_64产物不能在ARM板运行。旧离线/摄像头工具默认不参与构建；需要其原有流程时显式开启EVS_BUILD_LEGACY_TOOLS，其历史SDK路径问题另行处理。
冰雪相机demo通过目标环境的pkg-config查找GStreamer；缺少开发包时会提示并省略该目标。

## 图片与相机demo

```bash
./package_ice/bin/ice_replay configs/winch_ice.yaml input.ppm /tmp/ice_image/run
./package_ice/bin/winch_ice_demo --task configs/winch_ice.yaml \
  --device /dev/video0 --width 1280 --height 720 --frames 100 --out /tmp/ice_camera/run
```

图片demo目前只读P6 PPM，JPEG/PNG须先转换。相机demo默认逐帧检测，无需PLC工况参数；若要验证宿主门控，可追加 `--simulate-context --angle 0 --working 1` 或 `--context-json live.json`，二者互斥。
终端输出各卷扬比例和报警JSON，输出目录保存叠加图及掩码；无有效对象显示NO RESULT。当前没有实时UI窗口。
相机采用紧凑NV12，首次等待8秒、后续3秒，实际尺寸以协商结果为准。

## 测试和限制

无RK3588设备时，可运行内部插件像素和解码回归：

```bash
cmake -S . -B build_test -DEVS_BACKEND=mock -DEVS_WITH_OPENCV=ON -DEVS_WITH_GSTREAMER=OFF
cmake --build build_test -j2
ctest --test-dir build_test --output-on-failure
```

测试覆盖双框独立计数、重复时间戳、20%→60%→20%、错误清理、阈值更新及掩码文件；人工框仅存在于内部测试，不能通过正式Detector注入。
公开只读掩码诊断供demo展示使用。无模型、错误模型或无RKNN SDK时正式检测明确失败；mock测试不代表真实模型推理。
模型输出采用单类YOLOX原始 `[1,8400,6]`：tx/ty/tw/th、目标概率、类别概率，按stride8/16/32网格解码，置信度为后两项相乘。
HSV默认S≤80、V≥180并执行3×3开闭运算，只是颜色粗估；反光/背景可误计，暗雪/透明冰可漏计，框内支架背景也计入分母。
此前小样本板测曾确认漏检和无雪图误计，不能据此宣称精度通过。当前设备断开，本次收缩后仅完成主机验证；恢复连接后须重新实机验收。
当前核验及外部完整备份位置记录在工作区 `heyan/核验结论.md`。
