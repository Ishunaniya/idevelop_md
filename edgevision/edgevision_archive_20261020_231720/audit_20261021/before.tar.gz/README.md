# EdgeVision 边缘视觉框架 —— 使用说明

> 卷扬冰雪以 [winch_ice.md](docs/winch_ice.md) 为当前说明，下文旧冰雪占位内容不作为接入依据：RK3588卷扬模型、逐帧detect和每框比例。当前库版本为.so.3，宿主与插件需使用配套头文件重新编译。

起重机 AI 安全检测算法库（C++17，无第三方依赖）。同一份代码可以构建在
**x86 PC** 上做离线评测，也可以交叉编译后部署到 **RK3576 板子**上跑 NPU 实时检测。

---

## 0. 一句话理解它做什么

```
相机帧(NV12/RGB) → 预处理(letterbox 到模型输入) → 推理后端(mock/x86+ONNX/RKNN)
   → 解码器(flat6 / yolov8) → 人员目标(0..1 归一化框+置信度) → 功能插件(区/规则/告警)
```

**边界**：算法库只做上面这一段。取帧、录像、UI、声光、主控联锁**都不在库里**，
由宿主程序（如 `qt5_qml_c001`、`tools/linux_source`）负责。

`VisionTask` 只调用接口。具体算法按 YAML 在工厂里换成另一份实现。
公共部分在 `libevs_core.so`。人员、高度限位、卷扬冰雪各自一个动态库，宿主按需要链接。

| 插口 | 接口 | 工厂 | YAML 选择 |
|---|---|---|---|
| 功能规则 | `IFunctionPlugin` | `create_function_plugin` | `module_id`：`0x0004`–`0x0006` 人员，`0x0007` 高度限位，`0x0008` 卷扬冰雪 |
| 推理后端 | `IInferBackend` | `create_backend` | `backend`：`mock` / `rknn` / `x86` / `onnx` |
| 模型输出解析 | `IDetectionDecoder` | `create_decoder` | `output_format`：`flat6` / `yolov8` / `yolo11` / `yolox` |
| 地面距离 | `IGroundMapper` | `create_ground_mapper` | 每路相机的 `ground.cameras[].mapper`：`homography` / `crane_pose` |

`initialize` 按配置把这四样创建好。之后每帧只走推理、解码、地面映射、`plugin->decide()`。
功能插件、解码器、地面映射在各自的 `.cpp` 里静态登记，工厂只查注册表。

| 库 | 内容 |
|---|---|
| `libevs_core.so` | `VisionTask`、YAML、推理后端、解码器、地面映射、注册表 |
| `libevs_person.so` | 人员 `0x0004` / `0x0005` / `0x0006` |
| `libevs_height_limit.so` | 高度限位 `0x0007` |
| `libevs_ice.so` | 卷扬冰雪 `0x0008` |

插件库加载时把自己的 `module_id` 写进 `libevs_core.so` 的注册表。宿主要同时链接 `libevs_core.so` 和用到的插件库，只链公共库时对应功能会初始化失败。
加一种功能时：在 `src/tasks/` 实现 `IFunctionPlugin`，用 `FunctionPluginRegistration` 登记 `module_id`，并在 `CMakeLists.txt` 里为它增加一个插件库目标。
解码器和地面映射仍在 `libevs_core.so` 里，按 `output_format`、`mapper` 登记，不用改工厂文件。
链静态库的程序要整库链入 `libevs.a` 和对应插件的 `.a`。推理后端仍由编译选项 `EVS_BACKEND` 选择，不进这张表。
摄像头采集和 RGA 预处理在宿主里，不走这套接口。

---

## 1. 目录结构

| 路径 | 内容 |
|---|---|
| `include/evs/` | 对外头文件：`frame.h` `vision_task.h` `preprocess.h` `iinfer_backend.h` `detection_decoder.h` `backend_factory.h` `status.h` `log.h` `debug.h` `offline_eval.h` |
| `src/core/` | 配置解析、模型注册、解码器、预处理、离线评测引擎、可观测性 |
| `src/backend/` | 推理后端：`mock/`（永远编译）、`x86/`（参考检测器 / ONNXRuntime）、`rknn/`（NPU） |
| `src/backend/yolo_decode.h` | **PC 与板端共用**的 YOLOv5 解码（通道主序 + 激活方式判别 + NMS + 退化框过滤） |
| `src/vision_task.cpp` `src/tasks/` | 功能插件：人员（`person/`）、高度限位骨架（`height_limit/`）、卷扬冰雪骨架（`winch_ice/`） |
| `tools/eval_offline/` | 离线精度评测工具（`eval_offline`）+ 示例数据集生成 |
| `tools/v4l2_detect/` | 现场取景验证工具（实时管线 / MP4 关键帧 / 共享内存 / 裸 NV12） |
| `tools/linux_source/` | Linux 宿主取帧示例说明（**不链进算法库**） |
| `configs/` | 任务 YAML：`eval_demo` / `eval_onnx` / `eval_rknn` / `load_near` / `load_under` / `boom_under` / `height_limit` / `winch_ice` |
| `eval_onnx_demo/` | 自检数据集（`images/bus.ppm` + `annotations.json`） |
| `cmake/` | aarch64 交叉编译工具链文件 |
| `docs/` | `api.md`（给宿主开发的 API）、`capture_test.md`（板端四种取帧测试）、`observability.md`（日志/调试）、`x86_offline_eval.md`（离线评测 + ONNX 模式）、`rknn_backend.md`（NPU 交叉编译与真机验证） |

---

## 2. PC（x86）上怎么用

### 2.1 零依赖先跑通（推荐第一步）

不装任何第三方库，用内置参考检测器验证链路与单测。

```bash
# Linux
cmake -S . -B build -DEVS_BACKEND=x86
cmake --build build -j
./build/evs_tests            # 单测，应输出 PASS=161 FAIL=0

# 生成示例数据集并跑一次离线评测
python3 tools/eval_offline/gen_fixtures.py       # 产出 fixtures/
./build/eval_offline --task configs/eval_demo.yaml --dataset ./fixtures \
                     --iou 0.5 --score 0.45 --dump --out ./out
```

```powershell
# Windows（MSVC 2022）
cmake -S . -B build -DEVS_BACKEND=x86
cmake --build build --config Release
.\build\Release\evs_tests.exe
.\build\Release\eval_offline.exe --task configs\eval_demo.yaml --dataset .\fixtures --out .\out
```

### 2.2 跑真实模型（ONNXRuntime）

```powershell
cmake -S . -B build_onnx -DEVS_BACKEND=onnx -DEVS_WITH_ORT=ON `
      -DONNXRUNTIME_LIB_DIR=<ort>/lib -DONNXRUNTIME_INCLUDE_DIR=<ort>/include
cmake --build build_onnx --config Release
```

**配置里必须出现这两行**，否则说明 ORT 没接上（会静默退回参考检测器）：

```
-- ONNXRuntime enabled: .../onnxruntime.lib
-- ONNXRuntime include: .../include
```

把 `onnxruntime.dll` 放到 `eval_offline.exe` 同目录，然后：

```bash
./build_onnx/Release/eval_offline --task configs/eval_onnx.yaml \
    --dataset ./eval_onnx_demo --iou 0.5 --score 0.25 --out ./out
```

> 怎么把 ONNX 接到 Windows（含 pip 只有 dll 没有 .lib 的自制导入库办法）见
> `docs/x86_offline_eval.md` 的「真实模型（ONNXRuntime）模式」。

---

## 3. RK3576 板子上怎么用

### 3.1 交叉编译

推荐用 Rockchip SDK 自带工具链（138 上路径）：

```bash
SDK=/home/xp/rk3576/rk3576_linux6.1_release
TC=$SDK/prebuilts/gcc/linux-x86/aarch64/gcc-arm-10.3-2021.07-x86_64-aarch64-none-linux-gnu
cat > /home/xp/tc_sdk.cmake <<EOF
set(CMAKE_SYSTEM_NAME Linux)
set(CMAKE_SYSTEM_PROCESSOR aarch64)
set(CMAKE_C_COMPILER   $TC/bin/aarch64-none-linux-gnu-gcc)
set(CMAKE_CXX_COMPILER $TC/bin/aarch64-none-linux-gnu-g++)
set(CMAKE_FIND_ROOT_PATH $TC/aarch64-none-linux-gnu)
EOF

cmake -S . -B build_sdk -DCMAKE_TOOLCHAIN_FILE=/home/xp/tc_sdk.cmake \
      -DEVS_BACKEND=rknn \
      -DRKNN_API_LIB=/home/xp/rknn_sdk/lib/librknnrt.so \
      -DRKNN_API_INCLUDE_DIR=/home/xp/rknn_sdk/include
cmake --build build_sdk -j4
```

`librknnrt.so` 从板子上拉（**不要**用 SDK 里那份，版本比板端旧）：
`cat /usr/lib/librknnrt.so` → 存到编译机；`rknn_api.h` 取自 rknn-toolkit2。

### 3.2 部署与运行

```bash
# 推三个可执行文件到板子
scp build_sdk/{evs_tests,eval_offline,v4l2_detect} root@192.168.11.1:/root/evs/
scp configs/eval_rknn.yaml                   root@192.168.11.1:/root/evs/
scp -r eval_onnx_demo                        root@192.168.11.1:/root/evs/
```

板端三种用法：

```bash
cd /root/evs

# ① 单测（板端 137 项，x86/ONNX 专属段不参与）
./evs_tests                                  # PASS=137 FAIL=0

# ② 离线精度评测（与 PC 同一份数据集，可直接对比）
./eval_offline --task eval_rknn.yaml --dataset ./eval_onnx_demo \
               --iou 0.5 --score 0.25 --out ./out

# ③ 现场摄像头检测
v4l2-ctl -d /dev/video0 --set-fmt-video=width=1280,height=720,pixelformat=NV12
v4l2-ctl -d /dev/video0 --stream-mmap=3 --stream-count=1 --stream-to=/root/evs/cap.nv12
./v4l2_detect --task eval_rknn.yaml --raw /root/evs/cap.nv12 \
              --raw-width 1280 --raw-height 720 --frames 5 --score 0.25 \
              --save /root/evs/shot.ppm
```

> 板端 root 密码为空，请先 `passwd root` 加固。

---

## 4. 在自己的程序里调用

### 4.0 分工：哪些你要写，哪些库已经写了

| 环节 | 谁负责 | 说明 |
|---|---|---|
| 打开相机 / V4L2 / AHD 解码 / RTSP / dma-buf 循环 | **你（宿主）** | 库不链接任何采集库，也不碰 `/dev/video*` |
| 把像素填进 `evs::Frame` | **你（宿主）** | 就 6 行赋值 |
| `camera_id` 与 `video_channel` 对账 | 库 | 不匹配会丢帧并打日志 |
| 预处理（NV12/BGR→RGB、letterbox 到模型输入） | 库 | 输出 packed NHWC uint8 |
| 推理（mock / ONNXRuntime / RKNN） | 库 | 模型文件与 runtime 由库管理 |
| 后处理（NMS、通道主序解码、坐标回映射原图） | 库 | PC 与板端共用同一份代码 |
| 功能规则（区域/连续帧/告警/高度限位状态） | 库 | `person_plugin` |
| 日志、p95 延迟、输入张量落盘取证 | 库 | `docs/observability.md` |
| 把结果接到 UI / 声光 / 录像 / 上位机 | **你（宿主）** | 读 `Result` 即可 |

**为什么这样切**：算法库要能在 x86 上零依赖编译做离线评测（没有摄像头），
也要能在板子上不绑 Qt/GStreamer/mpp 才方便交叉编译。取帧、录像、UI、声光是
产品形态的一部分，留在宿主。

### 4.1 最小宿主骨架（这就是你要写的全部）

```cpp
#include "evs/vision_task.h"
#include "evs/log.h"
#include <chrono>

int main() {
    // ① 初始化一次：读 YAML、加载模型、装配预处理/解码/规则
    evs::VisionTask task;
    if (task.initialize("/root/cameras/eval_rknn.yaml") != 0u) return 1;

    evs::MachineContext ctx{};          // 工况：MCU/PLC 每帧更新
    ctx.context_valid = true;
    ctx.hoist_radius = 55.f;

    // ② 取帧循环（这一段就是"输入层"，由你实现）
    //    板端可用 v4l2-ctl / V4L2 mmap / camera_shm_multi / rtspsrc ...
    while (running) {
        int w = 0, h = 0, stride = 0;
        const uint8_t* data = fetch_next_frame(&w, &h, &stride);   // ← 你的取帧函数
        if (!data) continue;

        // ③ 填 Frame：库只认这一个结构
        evs::Frame frame{};
        frame.camera_id    = 0;
        frame.width        = w;
        frame.height       = h;
        frame.stride       = stride;
        frame.format       = evs::PixelFormat::NV12;   // 或 RGB / BGR
        frame.data         = data;
        frame.timestamp_us = std::chrono::duration_cast<std::chrono::microseconds>(
                                std::chrono::steady_clock::now().time_since_epoch()).count();

        // ④ 一次调用，拿到结果
        evs::Result res{};
        if (task.detect(frame, ctx, res) != 0u) continue;

        // ⑤ 消费结果（接 UI / 声光 / 录像）
        for (const auto& t : res.targets) {
            int x1 = int(t.x * w), y1 = int(t.y * h);
            int x2 = int((t.x + t.w) * w), y2 = int((t.y + t.h) * h);
            draw_box(x1, y1, x2, y2, t.class_id, t.confidence);      // ← 你的绘制
        }
        if (res.alarm != evs::AlarmState::None) trigger_alarm(res);
    }
    task.release();
    return 0;
}
```

`fetch_next_frame()` 就是你要写的全部"输入层"——如果你的系统已经有取帧
（`qt5_qml_c001` 的 `camera_shm_multi`），通常只是把它的缓冲指针赋给 `frame.data`。
可运行的完整示例见 `tools/v4l2_detect/main.cpp`（含 V4L2 取帧 + 画框 + 存图 + 计时）。

### 4.2 方式 A：`VisionTask`（推荐，功能完整）

```cpp
#include "evs/vision_task.h"

evs::VisionTask task;
if (task.initialize("configs/eval_rknn.yaml") != 0u) { /* 处理错误 */ }

evs::Frame frame{};
frame.camera_id = 0;
frame.width = 1280; frame.height = 720; frame.stride = 1280;
frame.format  = evs::PixelFormat::NV12;      // 或 RGB / BGR
frame.data    = nv12_ptr;                    // 宿主自己的缓冲
frame.timestamp_us = now_us();

evs::MachineContext ctx{};                   // 来自 MCU/PLC 的工况
ctx.context_valid = true;
ctx.hoist_radius = 55.f;

evs::Result res{};
const uint32_t rc = task.detect(frame, ctx, res);
// res.targets[i]: class_id / confidence / x,y,w,h（0..1，相对原图）
// res.alarm  : 是否告警；res.limit_state : 高度限位状态
```

`initialize()` 失败会自动回滚，不留半初始化状态；重复调用不会重复加载模型。
`updateConfig()` 只能改阈值/区域/开关，**拒绝**改 backend 与 model。

### 4.3 方式 B：只用三件套（取景验证、单测、自研管线）

```cpp
#include "evs/preprocess.h"
#include "evs/backend_factory.h"
#include "evs/detection_decoder.h"

auto backend = evs::create_backend("rknn");           // mock / x86 / onnx / rknn
backend->load("/root/cameras/yolov5s-640-640_rk3576.rknn", 60);
backend->configure_input(640, 640);                  // 模型输入尺寸

evs::Preprocessor pre;
evs::PreprocessConfig pc{};
pc.input_width = 640; pc.input_height = 640;
pc.letterbox = true; pc.target_format = evs::PixelFormat::RGB;
pre.configure(pc);

auto dec = evs::create_decoder("yolov8", /*person_class_id=*/0, /*num_classes=*/80);

std::vector<uint8_t> input;  evs::PreprocessMap map{};
std::vector<float>   tensor; std::vector<evs::Target> targets;
pre.run(frame, input, map);
backend->infer(input, tensor);
dec->decode(tensor, 0.25f, targets);
for (auto& t : targets) evs::map_target_to_original(map, t, 1280, 720);
```

`tools/v4l2_detect/main.cpp` 就是这个模式的完整可运行样例，直接抄最快。

### 4.4 接入 Qt/QML 宿主（qt5_qml_c001）

- 算法库是**纯 C++ 静态库**（`libevs.a`），不依赖 Qt / GStreamer / mpp；
- 取帧用 `camera_shm_multi` 的 `start_camera` / `CameraManager`，把 NV12 缓冲填进 `Frame`；
- 帧分发按 `video_channel`：0x0004 人形、0x0005 load-under、0x0006 长焦×2、0x0007 高度限位、0x0008 卷扬×2；
- 录像/声光在宿主侧做，不要塞进算法库。

---

## 5. 输入层、取图与配置（换摄像头 / 换模型）

### 5.1 输入层是怎么定义的

算法库的**唯一输入契约**是 `evs::Frame`（`include/evs/frame.h`），库自己不碰任何设备：

| 字段 | 含义 | 谁负责填 |
|---|---|---|
| `camera_id` | 相机编号，用来和 YAML 的 `video_channel` 对账 | 宿主 |
| `width` / `height` | **原始帧真实尺寸**（不是模型输入尺寸） | 宿主 |
| `stride` | 每行字节数；NV12 传 `width`，RGB/BGR 传 `width*3` | 宿主 |
| `format` | `NV12` / `RGB` / `BGR` | 宿主 |
| `data` | 像素缓冲，只保证在 `detect()` 返回前有效 | 宿主 |
| `dma_fd` | 可选，dma-buf fd（`-1` 表示没有） | 宿主 |
| `timestamp_us` | 采集时间戳，用于日志/取证 | 宿主 |

`Preprocessor` 把 `Frame` 转成模型输入，行为由 YAML 推导（`src/vision_task.cpp`）：

```
YAML input_width/input_height/letterbox/input_format
   → PreprocessConfig{ input_width, input_height, letterbox, target_format }
   → 输出 packed uint8 NHWC（input_w*input_h*3）
   → 同时产出 PreprocessMap（scale/pad），用于把框映射回原图坐标
```

要点：**原始分辨率可以任意**（例如 1280×720），预处理会 letterbox 到模型输入
（默认灰边 114），检测框再通过 `map_target_to_original()` 还原回原图 0..1 坐标。
所以换分辨率**不需要改 YAML**，只要 `Frame` 填对即可。

### 5.2 怎么取图（库外，三种实测路径）

| 场景 | 做法 |
|---|---|
| 板端快速验证 | `v4l2-ctl` 抓一帧 → `v4l2_detect --raw cap.nv12` |
| 板端直接取流 | `v4l2_detect --device /dev/video0`（需内核头与目标板一致，见 `docs/rknn_backend.md` §7） |
| 正式产品（Qt/QML） | `camera_shm_multi` 的 `start_camera`/`CameraManager` 取帧 → 填 `Frame` → `detect` |

### 5.3 换摄像头

**换物理摄像头 = 改宿主取图代码，YAML 基本不用动**。YAML 里唯一与相机相关的是 `camera.video_channel`：

```yaml
camera:
  video_channel: [2, 3]   # 这个任务处理哪几路；frame.camera_id 不在列表 → detect 返回
                       # InvalidCameraIndex 并打日志（该帧被丢弃）
```

- 同一个任务实例可以处理多路：每路各调一次 `detect(frame, ...)` 即可
  （`video_channel: [2,3]` 就是长焦 ×2 这种用法）。
- 分辨率/位深变化（1080p→720p、RGB→NV12）只要 `Frame` 填对就自动适配。
- `/dev/videoN` 的设备名、曝光、白平衡**不在 YAML 里**，那是宿主/驱动的职责。

### 5.4 换模型

换模型 = **改 YAML 的这几个字段**（改完需要重新 `initialize()`，`updateConfig()` 会拒绝）：

```yaml
backend: rknn                                  # mock | x86 | onnx | rknn
Model_path: "/root/cameras/yolov5s-640-640_rk3576.rknn"
input_width: 640            # 必须等于模型真实输入宽
input_height: 640
input_format: rgb           # 训练时的通道顺序：rgb / bgr
output_format: yolov8       # 原始检测头=yolov8；单类 6 浮点=flat6
decoder_classes: 80         # 必须等于模型真实类别数（COCO=80）
person_class_id: 0          # 只要这一类；-1 = 全要
confidence_threshold: 0.25
```

**换模型的检查清单**

1. `decoder_classes` = 模型类别数（写错 → 行宽对不上，解码器**静默返回 0 个框**，不报错）；
2. `output_format`：模型输出原始检测头 → `yolov8`；输出已解码好的 `[cls,conf,x,y,w,h]` → `flat6`；
3. `person_class_id` 超出类别范围 → 同样是 0 框（先确认这两个再怀疑模型）；
4. `input_width/height` 与模型一致（不一致会静默拉伸/letterbox，精度下降）；
5. `input_format` 与训练一致（`rgb`/`bgr` 反了 → 框还在但类别乱）；
6. RKNN 模型若把 Detect 后处理烧进了图里 → 用 `EVS_YOLO_HEAD_MODE=2` 或保持自动判别；
7. 换完后跑一次 `eval_offline` 对比 P/R，并用 `EVS_YOLO_DUMP=1` 人工核对几个框。

**自训 2 类（人/安全帽）模型的 YAML 示例**

```yaml
task: person_helmet
module_id: 0x0004
camera:
  video_channel: [0]
backend: rknn
Model_path: "/root/cameras/person_helmet_int8.rknn"
output_format: yolov8
person_class_id: 0            # 0=人；安全帽那一类要用另一个任务或 -1 全要
decoder_classes: 2            # ← 关键：2 类，不是 80
input_width: 640
input_height: 640
input_format: rgb
letterbox: true
thresholds:
  score: 0.4
```

> 注意：自训模型换了输入尺寸/锚框/类别数，解码器的常量也要跟着改
> （`src/backend/yolo_decode.h` 里的 `kClasses`、`kInputSize`、`anchors_for_stride`），
> 这些是**编译期常量，不能靠 YAML 配置**。

### 5.5 YAML 支持的全部键

| 分组 | 键 |
|---|---|
| 标识 | `task` `module_id` `video_channel` |
| 后端/模型 | `backend` `model` `init_timeout_s` `npu_core_mask` `warmup` |
| 输入 | `input_width` `input_height` `input_format` `letterbox` |
| 解码 | `output_format` `person_class_id` `decoder_classes` |
| 阈值/规则 | `confidence_threshold` `nms_threshold` `zone.{type,radius_m,half_angle_deg,consecutive_frames,has_occlusion,occ_axis_deg,occ_half_deg}` |
| 工况联动 | `on_missing_context` `work_motion_epsilon` |
| 性能 | `latency_budget_ms` `min_fps` |
| 高度限位 0x0007 | `start_angle_deg` `stop_angle_deg` `min_frames` `still_timeout_s` `basic_boom_only` |
| 卷扬冰 0x0008 | `area_ratio` `exit_on_alarm` |
| 调试 | `debug.{enabled,dump_input,dump_meta,dump_on_alarm_only,dump_every_n,dump_dir,max_dumps}` |

**不能用 YAML 配的**：摄像头设备名与曝光/白平衡、模型内部结构（类别数、锚框、输入尺寸
是编译期常量）、解码公式细节、letterbox 填充值（固定 114）、NPU 亲和以外的算子调度。

### 5.6 运行时热更新（`updateConfig`）

| 允许热改 | 必须重启（会被拒绝，返回 `NotSupported`） |
|---|---|
| `confidence_threshold` / `nms_threshold` | `backend`、`Model_path` |
| `zone.*` 区域规则 | `output_format`、`decoder_classes`、`person_class_id` |
| `on_missing_context`、`work_motion_epsilon` | `input_width/height`、`input_format`、`letterbox` |
| `latency_budget_ms` | `video_channel`、`module_id` |
| `debug.*`（现场排障开关） | |

---

## 6. 环境变量速查

| 变量 | 作用 |
|---|---|
| `EVS_LOG_LEVEL` | 0=off 1=error 2=warn 3=info 4=debug 5=trace |
| `EVS_LOG_FILE` | 日志落盘路径 |
| `EVS_YOLO_HEAD_MODE` | 0/1/2 强制解码模式（默认自动判别，见下） |
| `EVS_YOLO_DUMP=1` | 打印每个解码框（PC↔NPU 逐框比对用） |
| `EVS_RKNN_INPUT_SCALE` | 仅 float32 模型输入：1.0=0..255，0.00392157=0..1 |
| `EVS_RKNN_DEBUG=1` | 打印每个输出头的 dims 与前 6 个值 |
| `EVS_NPU_CORE_MASK` | NPU 亲和：0=自动 2=core1 4=core2 3=core0+1 7=三核 |
| `EVS_RGA_CSC` | RGA 预处理策略：`0`=纯 RGA（默认，最快）…`8`=CPU 转换+RGA 缩放（最严格）。见第 10 章 |
| `EVS_DUMP_BENCH=/tmp/pp` | `--bench` 时额外导出 `/tmp/pp_rga.ppm` 与 `/tmp/pp_cpu.ppm`，用于逐像素比对 |
| `EVS_RGA_NOPAD=1` | 诊断：强制 letterbox 偏移为 0，验证 `dst_off` 是否被遵守 |

> **为什么需要 `EVS_YOLO_HEAD_MODE`**：部分 RKNN 模型转换时已把 Detect 后处理
> （sigmoid / 框解码）烧进图里，输出不再是原始 logits。解码器按取值分布自动判别
> （原始 logits 仅约 2% 落在 [0,1]，融合后约 100%），必要时可手动强制。

---

## 7. 常见问题

| 现象 | 原因与处理 |
|---|---|
| 配置里没打印 `ONNXRuntime enabled:` 却以为在跑真模型 | `find_library` 的结果变量被预先 `set()` 过 → 跳过搜索。删掉预置变量（**结果变量绝不能预先赋值**） |
| exe 双击闪退、无输出 | Windows 下缺 `onnxruntime.dll`，放到 exe 同目录 |
| 板端 `S_FMT_MPLANE ... Invalid argument` | 编译机 videodev2 头与运行内核 ioctl 号不匹配 → 用 `v4l2-ctl --stream-to` + `v4l2_detect --raw` |
| 检测框大得离谱 / 一堆误检 | 模型已融合后处理但解码器当 logits 算 → 查 `EVS_YOLO_HEAD_MODE`；先跑 `EVS_RKNN_DEBUG=1` 看输出头数值 |
| 摄像头链路 fps 低 | 预处理已优化到 51.7 ms（定点双线性 + 行裁剪 + BT.601 查表），整帧 81 ms ≈ 12.3 fps；再压需要 RGA（要求 dma-buf，见 docs/rknn_backend.md §7） |
| 交叉编译报 `stray '\24' in program` | 上传的源码还是 DRM 密文 → 上传前校验文件头可打印 |

---

## 8. 已验证数据（2026-10-07）

| 场景 | 结果 |
|---|---|
| PC 单测（x86 / onnx 构建） | PASS=161 FAIL=0 |
| PC 真实模型 `yolov5s.onnx`（自检集，IoU 0.5 / score 0.25） | precision 1.000 / recall 1.000 / mAP 1.000 |
| RK3576 单测（rknn 构建） | PASS=137 FAIL=0 |
| RK3576 真实模型 `yolov5s-640-640_rk3576.rknn`（同一自检集） | precision 1.000 / recall 0.667 / mAP 0.667，单帧 ≈31 ms |
| PC↔NPU 逐框比对 | 6 框 IoU 0.77~1.00（均值 0.88），NPU 零误检 |
| 摄像头实时检测（1280×720 NV12） | 正确检出画面中的人；优化后 预处理 51.7 ms + NPU 29.4 ms ≈ 81 ms/帧（12.3 fps） |
| `yolo11.rknn`（YOLOv11 解耦头，9 输出） | bus 帧检出 4 人 + 1 巴士，与参考工程 `yolov5_object_detect` 同一份模型结果一致 |
| YOLOv11 实时检测（1280×720，`--rga`） | 预处理 **3.1 ms**（CPU 52.9 ms，**15~17×**）+ 推理 75.7 ms ≈ 78.8 ms/帧（**12.7 fps**） |
| RGA vs CPU 逐像素比对 | maxdiff=104 / meandiff=2.83（插值差异）；检测框差 ≈7 px，bus 帧目标数一致 |

> 自检集 = 同一模型在 Python 侧的解码结果当基准，证明的是**移植一致性**，不是检测精度。
> 验收数字请换成现场人工标注集后用同一条命令重跑。

---

## 9. YOLOv11 解耦头（`yolo11.rknn`）

板端 `yolo11.rknn` 与参考工程 `X:\apps\yolov5_object_detect` 是同一份模型
（md5 `8df71b48a8888b364689d238c083ca40`）。它和 yolov5s 的关键差别是**头部结构**：

| | yolov5s | yolo11 |
|---|---|---|
| 输出张量 | 3 个 `[1,255,S,S]` | **9 个**：每尺度 reg/cls/obj |
| 通道含义 | `3×(5+80)` 混合 | reg `[1,64,S,S]`（4 边 × 16 DFL bin）、cls `[1,80,S,S]`、obj `[1,1,S,S]` |
| 网格 | 80/40/20 | 80/40/20（stride 8/16/32） |
| 框解码 | anchor + exp() | **DFL-16**（16 个 bin 做 softmax 期望） |
| 分数 | `obj × cls` | `sigmoid(obj) × cls` |

解码实现在 `src/backend/yolo_decode.h`（`collect_v11_scales` / `decode_v11_scale`），
`decode_heads()` 会**按张量形状自动识别**布局，在 YOLOv5 anchor 路径之前分派，
所以同一个二进制可以同时跑 yolov5s 和 yolo11，只由 YAML 的 `output_format` 决定：

```yaml
output_format: yolo11      # yolov5s 用 yolov8（行矩阵语义）
person_class_id: 0         # 只检人；-1 = 全类
```

### 移植时踩到的两个坑

**① 解码层次放错了。** 后端 `rknn_backend` 在返回给上层之前**已经**调用过
`yolo::decode_heads()`，交给 decoder 的是 `[N, 4+80]` 的行矩阵，而不是 9 张原始
张量。在 `detection_decoder.cpp` 里按 `reg/cls/obj` 去切那段内存，只会得到
`targets=0`（连 `--score 0.01` 都是 0，因为每格算出来的分数都一样）。
YOLOv11 的解码必须放在 `yolo_decode.h` 里、和YOLOv5 的解码并列。

**② 该模型的 sigmoid 已被烧进图里。** 实测 `cls` 全部落在 `[0.0018, 0.88]`、
`obj` 落在 `[0.146, 0.69]`，即到达时**已经是概率**。若照参考工程再套一层
sigmoid，所有分数会被压向 `sigmoid(x)≈0.5`，表现为**全图 conf 恒等于 0.2685**、
框满天飞。`v11_fused_activation()` 默认按"已含激活"处理，需要原始 logits 时设
`EVS_YOLO11_SIGMOID=1`。（参考工程读的是 fp16 原始张量，所以那边必须套 sigmoid；
而 `rknn_outputs_get(want_float=1)` 给的是 SDK 反量化后的值，两者不能照抄。）

板端验收（`bus.nv12`，`--score 0.25`）：

```
全类    targets=5 -> class=0 x4 (0.88/0.84/0.82/0.62) + class=5 bus (0.75)
只检人  targets=4 -> 0.882 / 0.836 / 0.816 / 0.622
阈值扫描 0.15→5  0.25→5  0.5→5  0.7→4     （单调不增 = 解码正确）
```

> **快速自查**：若任意阈值下 `targets` 都不变，尤其是 conf 全是同一个数值，
> 基本就是上面第 ② 条（分数被压平），而不是坐标变换或 NPU 的问题。

---

## 10. RGA 硬件预处理（已调通）

`--rga` 把 letterbox + 缩放 + NV12→RGB 交给 RGA，预处理从 52.9 ms 降到 3.1 ms。

```bash
# 实时相机 + RGA（板端 192.168.11.1，root 空密码）
cd /root/evs
./v4l2_detect_evs_rga --task eval_yolo11.yaml --config camera_config.json \
  --channel 0 --frames 20 --score 0.25 --rga
#   [gst] capturing /dev/video0 1280x720 @25fps
#   frame 0: 1280x720 -> model 640x640, targets=1, pre[rga]=3.69ms infer=84.68ms
#   avg over 20 frames: pre=3.06ms infer=75.72ms total=78.79ms (12.7 fps)

# RGA 与 CPU 同帧逐像素比对
./v4l2_detect_evs_rga --task eval_yolo11.yaml --raw cap.nv12 \
  --raw-width 1280 --raw-height 720 --frames 1 --bench
#   [bench] rga=3.46ms cpu=53.33ms speedup=15.4x maxdiff=104 meandiff=2.833
```

### 三个必须知道的坑

**① CMake 默认会链到错的库。** `EVS_WITH_RGA=ON` 时若不显式指定，
`find_library` 会命中 `/home/xp/rknn_sdk/lib/librga.so`（**94 KB 精简版**）：
符号齐全，但 `imresize` 直接返回 `IM_STATUS_FAILED`（该 SDK 里 `0 = FAILED`、
`1 = SUCCESS`），日志表现为

```
[rga] falling back to CPU: imresize failed status=0
```

正确做法是指向 buildroot sysroot 里的真库（201 KB）与配套拆分头：

```bash
cmake -S . -B build_rga -DEVS_BACKEND=rknn -DEVS_WITH_RGA=ON \
  -DRGA_LIB=/home/xp/evs_build_aarch64/third_party/rga/lib/librga.so \
  -DRGA_API_INCLUDE_DIR=<SDK>/ubuntu/sysroots/armv8a-linux/usr/include/rga
```

> 头文件必须与库配套：混用 rknn_sdk 的新版单头会出现
> `dst handle=0x7f` + `Failed to call RockchipRga interface`。

**② `rga_buffer_t::wstride` 的单位是像素，不是字节。** 给 RGB888 传
`out_w*3`（1920）会让库按 1920 像素/行推进 → 三倍行溢出 → 图像撕裂
**并且破坏源帧**（640×640 输入下直接 `munmap_chunk(): invalid pointer` 崩溃）。
正确：传 `out_w`（640）。

**③ `dst_off` 是字节偏移，不能和 wstride 共用同一个变量。**
`dst_off = pady * stride`，若 stride 已是像素(640)，则
`140 × 640 = 89600` 字节 = **第 46 行**，整帧错位 94 行。症状非常有迷惑性：
`meandiff≈44`、颜色整体发暗发绿、检测框位置完全对不上——看起来像色域问题，
其实是几何错位（用 `EVS_RGA_NOPAD=1` 让偏移归零，内容立刻回到第 0 行即验证）。
现在代码里明确分成 `dst_stride_px`（给 librga）和 `dst_row_bytes`（自己寻址）。

> 顺带结论：librga **会忽略** `imcvtcolor` 的 CSC mode 参数（单独传
> `IM_YUV_TO_RGB_BT601_LIMIT` 或只设 `color_space_mode` 都不生效），
> 所以色域差异无法通过 API 调整；修好 ② ③ 之后纯 RGA 就与 CPU 基准一致。

### `EVS_RGA_CSC` 策略（1280×720 → 640×640 实测）

| 值 | 策略 | 预处理 | meandiff | 说明 |
|---|---|---|---|---|
| **0（默认）** | 纯 RGA：imresize + imcvtcolor | **3.5 ms** | 2.83 | 生产默认 |
| 6 | RGA 缩放 NV12，CPU 转 RGB | 11 ms | 1.56 | |
| 7 | CPU 全分辨率 CSC → RGA 缩放 RGB | 8.8 ms | 2.77 | |
| 8 | CPU 全分辨率 CSC + RGA 缩放 RGB | 41 ms | **1.31** | 像素最严格时用 |

### 排查手段

| 手段 | 用途 |
|---|---|
| `--bench` | 同帧跑 RGA + CPU，输出耗时 / maxdiff / meandiff / speedup |
| `EVS_DUMP_BENCH=/tmp/pp` | 导出两路预处理 PPM，PC 侧逐像素与位移分析 |
| `EVS_RGA_CSC=0..8` | 换预处理策略标定 |
| `EVS_RGA_NOPAD=1` | 验证 `dst_off` 是否被遵守 |
| `EVS_RKNN_DEBUG=1` | 打印每个 RKNN 输出的 dims / 类型 / 前 6 个值 |

### 已知限制

- `--rga-fd`（dma-buf 零拷贝）依赖 rkcif 的 DMABUF 输出能力，该板卡为 0，暂不可用；
  且 `EVS_RGA_CSC=8` 需要 CPU 侧帧，fd 路径不支持。
- 当前主项是推理（75.7 ms），相机 25 fps、实际 12.7 fps，仍会丢帧。

---

## 11. 板端验证速查

```bash
cd /root/evs
# 0 前置
ls -l v4l2_detect_evs v4l2_detect_evs_rga /root/cameras/yolo11.rknn bus.nv12

# 1 离线单帧  期望 targets=4（4 个人）
./v4l2_detect_evs --task eval_yolo11.yaml --raw bus.nv12 \
  --raw-width 640 --raw-height 640 --frames 1 --score 0.25

# 2 全类      期望 targets=5（4 人 + 1 巴士）
./v4l2_detect_evs --task eval_yolo11_all.yaml --raw bus.nv12 \
  --raw-width 640 --raw-height 640 --frames 1 --score 0.25

# 3 阈值单调性 期望 5 5 5 4（不变=分数被压平）
for s in 0.15 0.25 0.5 0.7; do
  printf 'score=%s -> ' $s
  ./v4l2_detect_evs --task eval_yolo11_all.yaml --raw bus.nv12 \
    --raw-width 640 --raw-height 640 --frames 1 --score $s 2>&1 | grep -o 'targets=[0-9]*' | head -1
done

# 4 实时相机  期望 1280x720 -> model 640x640
timeout 60 ./v4l2_detect_evs_rga --task eval_yolo11.yaml \
  --config camera_config.json --channel 0 --frames 20 --score 0.25 --rga

# 5 RGA/CPU 等价性  期望 maxdiff<120 meandiff<4
./v4l2_detect_evs_rga --task eval_yolo11.yaml --raw cap.nv12 \
  --raw-width 1280 --raw-height 720 --frames 1 --bench

# 6 yolov5s 回归（注意 output_format 必须是 yolov8，yolov5_raw 是非法名）
./v4l2_detect_evs --task eval_rknn_v8.yaml --raw bus.nv12 \
  --raw-width 640 --raw-height 640 --frames 1 --score 0.25
```

---

## 12. 下一步

1. 现场人工标注集（替换自检集，出真实 P/R）；
2. 推理侧优化（当前 75.7 ms 是主项，RGA 已把预处理压到 3 ms）；
3. `--rga-fd` 零拷贝路径（需 rkcif 支持 DMABUF 输出）；
4. helmet 类模型（当前 yolov5s 是 COCO 80 类，不含安全帽）；
5. int8 模型召回损失评估（必要时换更高精度 rknn 模型或混合量化）。