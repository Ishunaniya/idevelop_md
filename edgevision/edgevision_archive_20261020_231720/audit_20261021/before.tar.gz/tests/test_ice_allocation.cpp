#include "ice_test_support.h"
#include <evs/log.h>
#include <evs/status.h>
#include <evs/testing/ice_replay.h>
#include <evs/winch_ice.h>

#include <atomic>
#include <cstdlib>
#include <iostream>
#include <new>
#include <vector>

namespace {
// 0: normal; 1: fail once; 2: persistent OOM, including result recovery.
std::atomic<int> allocation_failure{0};
std::atomic<int> allocation_countdown{-1};
int passed = 0;
int failed = 0;

void check(bool condition, const char* message) {
    if (condition) {
        ++passed;
    } else {
        ++failed;
        std::cerr << message << '\n';
    }
}
} // namespace

void* operator new(std::size_t size) {
    const int remaining = allocation_countdown.load();
    if (remaining >= 0 && allocation_countdown.fetch_sub(1) == 0) {
        allocation_countdown.store(-1);
        throw std::bad_alloc();
    }
    const int mode = allocation_failure.load();
    if (mode != 0) {
        if (mode == 1) {
            allocation_failure.store(0);
        }
        throw std::bad_alloc();
    }
    if (void* memory = std::malloc(size ? size : 1)) {
        return memory;
    }
    throw std::bad_alloc();
}

void* operator new[](std::size_t size) {
    return ::operator new(size);
}

void operator delete(void* memory) noexcept {
    std::free(memory);
}

void operator delete(void* memory, std::size_t) noexcept {
    std::free(memory);
}

void operator delete[](void* memory) noexcept {
    std::free(memory);
}

void operator delete[](void* memory, std::size_t) noexcept {
    std::free(memory);
}

int main() {
    using namespace evs::winch_ice;
    auto& logger = evs::Logger::instance();
    logger.set_file("");
    logger.set_level(evs::LogLevel::Info);
    logger.set_sink([](evs::LogLevel, const std::string&) {});
    std::vector<uint8_t> pixels(100 * 100 * 3, 230);
    ImageData image;
    image.data = pixels.data();
    image.width = image.height = 100;
    image.size_bytes = pixels.size();
    const std::vector<ice_test::Box> boxes{{0, 0, 0, 100, 100}};

    {
        ice_test::PixelDetector detector;
        WinchSnowConfig config;
        check(detector.initialize(config) == 0, "initialize pixel fixture");
        auto detect = [&](WinchSnowResult& result) {
            return detector.detectWithBoxes(image, boxes, result);
        };
        WinchSnowResult initial;
        check(detect(initial) == 0 && initial.processed &&
                  initial.alert_level == AlertLevel::ALERT_WARN,
              "establish a frame alarm");
        for (int failure : {1, 2}) {
            WinchSnowResult result;
            allocation_failure.store(failure);
            const auto status = detect(result);
            allocation_failure.store(0);
            check(status == evs::with_module(8, uint32_t(evs::EvsStatus::MemoryAllocation)),
                  "report OOM");
            check(result.status == status && !result.processed, "report rejected call");
            check(result.alert_level == AlertLevel::ALERT_NONE && result.objects.empty(),
                  "OOM must not retain a previous alarm");
            std::vector<evs::testing::IceMaskSnapshot> masks;
            check(detector.copyMasks(masks) && masks.empty(), "OOM clears masks");
            WinchSnowResult recovered;
            check(detect(recovered) == 0 && recovered.objects.size() == 1 &&
                      recovered.alert_level == AlertLevel::ALERT_WARN,
                  "recover by processing the image again");
        }
    }
    for (int y = 0; y < 100; ++y)
        for (int x = 0; x < 100; ++x)
            for (int channel = 0; channel < 3; ++channel)
                pixels[(y * 100 + x) * 3 + channel] = x < 70 ? 230 : 60;
    // Plugin policy updates remain transactional under allocation failures.
    int rejected_pixel_updates = 0, applied_pixel_updates = 0;
    for (int fail_at = 0; fail_at < 20; ++fail_at) {
        ice_test::PixelDetector detector;
        WinchSnowConfig config;
        check(detector.initialize(config) == 0, "initialize pixel update sweep");
        auto update = config.detect_config;
        update.area_ratio = .8f;
        allocation_countdown.store(fail_at);
        const auto status = detector.updateConfig(update);
        allocation_countdown.store(-1);
        WinchSnowResult result;
        check(detector.detectWithBoxes(image, boxes, result) == 0 && result.objects.size() == 1,
              "pixel update recovery");
        check(result.alert_level == (status == 0 ? AlertLevel::ALERT_NONE : AlertLevel::ALERT_WARN),
              "pixel update uses the policy reported by its status");
        if (status == 0)
            ++applied_pixel_updates;
        else
            ++rejected_pixel_updates;
    }
    check(rejected_pixel_updates && applied_pixel_updates, "pixel update exercises both outcomes");

    std::cout << "ALLOCATION PASS=" << passed << " FAIL=" << failed << '\n';
    return failed ? 1 : 0;
}
